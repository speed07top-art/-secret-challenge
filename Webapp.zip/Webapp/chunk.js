(function () {
      'use strict';

      /* ── GLOBAL EVENT DELEGATION ── */
      document.addEventListener('click', function (e) {
        var el = e.target;
        // Walk up to find a [data-action] element
        while (el && el !== document) {
          var action = el.getAttribute('data-action');
          if (action) { handleAction(action, el, e); return; }
          el = el.parentElement;
        }
      });

      function handleAction(action, el, e) {
        var arg = el.getAttribute('data-arg') || '';
        var arg2 = el.getAttribute('data-arg2') || '';
        switch (action) {
          case 'pick-user': selU = arg; render(); break;
          case 'go-admin': session = 'admin'; render(); break;
          case 'do-login': doLogin(); break;
          case 'do-adm-login': doAdmLogin(); break;
          case 'logout': if (session && session !== 'admin') db.ref('sc_presence/' + session).remove(); clearSession(); session = null; quizSess = null; render(); break;
          case 'adm-logout': session = null; adminAuthed = false; sessionStorage.removeItem('adm_ok'); render(); break;
          case 'set-tab': tab = arg; render(); break;
          case 'set-subtab': window.executeSubTab = arg; render(); break;
          case 'set-adm-tab': adminTab = arg; render(); break;
          case 'toggle-history': showHistory = !showHistory; render(); break;

          case 'open-claim': openClaim(arg, arg2); break;
          case 'set-mode': claimMode = arg; render(); break;
          case 'close-overlay': if (e.target === el) { overlay = null; render(); } break;
          case 'cancel-overlay': overlay = null; render(); break;
          case 'prepare-claim': prepareClaim(); break;
          case 'finalize-claim': finalizeClaim(); break;
          case 'close-success': overlay = null; render(); break;
          case 'mark-done': markDone(arg); break;
          case 'confirm-done': confirmDone(arg, arg2 === 'yes'); break;
          case 'declare-unfulfilled': declareUnfulfilled(arg); break;
          case 'report-late': reportLate(arg); break;
          case 'view-order': overlay = { type: 'order_detail', id: arg, isExec: arg2 === '1' }; render(); break;
          case 'open-activity': overlay = { type: 'activity' }; render(); break;
          case 'fq-claim': overlay = null; tab = 'shop'; render(); break;
          case 'fq-skip-claim': overlay = null; render(); break;
          case 'toggle-acc': toggleAcc(+arg, el); break;
          case 'ob-next': obStep++; render(); break;
          case 'ob-back': obStep--; render(); break;
          case 'ob-close': showOB = false; render(); break;
          case 'add-q': addQ(); break;
          case 'del-q': delQ(arg); break;
          case 'add-r': addR(); break;
          case 'del-r': delR(arg); break;
          case 'adj-pts': adjPts(arg, +arg2); break;
          case 'do-reset': doReset(); break;
          case 'copy-topic': copyToClipboard(arg); break;
          case 'fq-answer': answerFlashQ(+arg); break;
          case 'fq-dismiss': dismissFlashQ(); break;
          case 'fq-claim': flashQ = null; miniGame = null; tab = 'shop'; render(); break;
          case 'fq-skip-claim': flashQ = null; miniGame = null; render(); break;
          case 'mg-dismiss': dismissMiniGame(); break;
          case 'mg-wheel-spin': doWheelSpin(); break;
          case 'mg-scratch': doScratchReveal(+arg); break;
          case 'mg-scratch-finish': doScratchFinish(arg === '1'); break;
          case 'mg-slots-spin': doSlotsSpin(); break;
          case 'mg-dice-roll': doDiceRoll(); break;
        }
      }

      /* ── MINI-GAME INTERACTIONS ── */
      function doWheelSpin() {
        if (!miniGame || miniGame.played || miniGame.gameState.spinning) return;
        var gs = miniGame.gameState;
        gs.spinning = true;
        var segments = [10, 50, 0, 100, 25, 250, 75, 150];
        var prize = calcWeightedPrize(250);
        // Find closest segment
        var segAngle = 360 / segments.length;
        var closestIdx = 0, closestDiff = 999;
        segments.forEach(function (v, i) {
          if (Math.abs(v - prize) < closestDiff) { closestDiff = Math.abs(v - prize); closestIdx = i; }
        });
        prize = segments[closestIdx]; // snap to actual segment value
        // Calculate target angle: spin several full rotations + land on segment
        var targetSegAngle = 360 - (closestIdx * segAngle + segAngle / 2);
        var totalAngle = 360 * (5 + Math.floor(Math.random() * 3)) + targetSegAngle;
        gs.angle = totalAngle;
        render();
        setTimeout(function () {
          gs.spinning = false;
          finishMiniGame(prize);
        }, 3200);
      }

      function doScratchReveal(idx) {
        if (!miniGame || miniGame.played) return;
        var gs = miniGame.gameState;
        if (gs.done || gs.cells[idx].revealed) return;
        gs.cells[idx].revealed = true;
        gs.reveals++;
        if (gs.reveals >= gs.maxReveals) gs.done = true;}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}