import re
import sys

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Update `updateClaimTotal` with styling logic
new_ucl = """      function updateClaimTotal() {
        if (!overlay || overlay.type !== 'claim') return;
        var r = overlay.reward;
        var base = parseInt(r.cost, 10);
        var extra = 0;
        var claimDL = document.getElementById('claimDL');
        var dlMode = claimDL ? claimDL.value : '';
        if (dlMode === 'subito') extra += 100;
        else if (dlMode === '1') extra += 50;

        var cbVieni = document.getElementById('cbVieni');
        var boxVieni = document.getElementById('boxVieni');
        if (cbVieni && boxVieni) boxVieni.style.display = cbVieni.checked ? 'block' : 'none';

        var allCbx = document.querySelectorAll('#premiumOptions input[type="checkbox"]');
        allCbx.forEach(function(cb) {
          if (cb.checked) extra += parseInt(cb.value, 10);
          var lbl = cb.parentElement;
          var ptDiv = lbl.querySelector('.pt-text');
          if (cb.checked) {
            lbl.style.background = '#f0f4fb';
            lbl.style.borderColor = '#1a2a5e';
            if (ptDiv) ptDiv.style.color = '#1a2a5e';
          } else {
            lbl.style.background = '#ffffff';
            lbl.style.borderColor = '#d0d4e0';
            if (ptDiv) ptDiv.style.color = '#378add';
          }
        });
        document.getElementById('claimTotal').innerHTML = '<span style="color:#378add">🔷</span> ' + (base + extra) + ' pt';
      };"""

content = re.sub(r'function\s+updateClaimTotal\s*\(\)\s*\{.*?\n\s*\};', lambda m: new_ucl, content, flags=re.DOTALL)

# 2. Update `renderOverlay` order configuration popup
new_overlay = """if (overlay.type !== 'claim') return '';
        var r = overlay.reward;
        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);padding-top:10vh" data-action="close-overlay">';
        h += '<div class="sheet" style="background:#ffffff;padding:24px 20px 32px;"><div class="sheet-handle" style="background:#d0d4e0;width:40px;height:4px;border-radius:2px;margin:0 auto 20px"></div>';
        h += '<h2 style="font-family:\\'Inter\\',sans-serif;font-size:1.6rem;color:#1a1f36;font-weight:800;margin-bottom:8px">Piazza un ordine</h2>';
        h += '<p style="font-size:.85rem;color:#8a8f9e;margin-bottom:24px;display:flex;align-items:center;gap:6px">' + (r.emoji || '👀') + ' <strong style="color:#1a1f36">' + esc(r.name) + '</strong> &nbsp;<span style="color:#d0d4e0">|</span>&nbsp; Base: <span style="color:#378add">🔷</span> <strong style="color:#1a1f36">' + r.cost + ' pt</strong></p>';
        h += '<div class="field"><label style="display:block;font-size:.7rem;font-weight:800;color:#378add;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">DETTAGLI DI CONSEGNA</label>';
        h += '<select id="claimDL" onchange="updateClaimTotal()" style="width:100%;padding:14px;border-radius:12px;border:1px solid #d0d4e0;background:#ffffff;color:#1a1f36;font-family:inherit;font-size:.95rem;outline:none;-webkit-appearance:none;appearance:none;background-image:url(\\'data:image/svg+xml;charset=US-ASCII,%3Csvg%20width%3D%2212%22%20height%3D%228%22%20viewBox%3D%220%200%2012%208%22%20fill%3D%22none%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cpath%20d%3D%22M1%201.5L6%206.5L11%201.5%22%20stroke%3D%22%238a8f9e%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22/%3E%3C/svg%3E\\');background-repeat:no-repeat;background-position:right 14px center;cursor:pointer">';
        h += '<option value="" disabled selected>Seleziona ora di consegna</option>';
        h += '<option value="subito">Subito (Ord. Prioritario, +100 pt)</option>';
        h += '<option value="1">Entro 1 ora (Ord. Prioritario, +50 pt)</option>';
        h += '<option value="2">Entro 2 ore</option>';
        h += '<option value="3">Entro 3 ore</option>';
        h += '<option value="4">Entro 4 ore</option>';
        h += '<option value="5">Entro 5 ore</option>';
        h += '</select></div>';
        
        h += '<div class="field" style="margin-top:24px"><label style="display:block;font-size:.7rem;font-weight:800;color:#378add;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">OPZIONI PREMIUM</label><div style="display:flex;flex-direction:column;gap:10px" id="premiumOptions">';
        
        var usrName = pname(session);
        var lblStyle = 'display:flex;align-items:center;justify-content:flex-start;gap:12px;font-size:.95rem;background:#ffffff;border:1px solid #d0d4e0;border-radius:12px;padding:16px 14px;cursor:pointer;color:#1a1f36;font-weight:500;transition:all .2s ease;margin:0';
        var cbStyle = 'width:20px;height:20px;margin:0;accent-color:#1a2a5e;cursor:pointer;border:1px solid #d0d4e0;border-radius:4px';
        var subBoxWrapper = 'display:none;margin-top:4px;margin-bottom:12px;padding:14px;background:#f0f4fb;border:1px solid #d0d4e0;border-radius:12px';
        var subTitleStyle = 'font-size:.75rem;color:#8a8f9e;text-transform:uppercase;letter-spacing:.05em;font-weight:800;margin-bottom:10px';
        var subRowStyle = 'display:flex;align-items:center;gap:12px;font-size:.9rem;cursor:pointer;font-weight:600;color:#1a1f36;padding:6px 0';

        var mkOpt = function(id, val, text, dataOpt) {
          var s = '<label style="' + lblStyle + '"><input id="'+id+'" name="'+id+'" type="checkbox" value="'+val+'" data-opt="'+dataOpt+'" onchange="updateClaimTotal()" style="' + cbStyle + '"><span style="flex:1">'+text+'</span><span class="pt-text" style="color:#378add;font-size:.9rem;font-weight:700">+'+val+' pt</span></label>';
          return s;
        };

        h += mkOpt('cbBenda', 50, 'Utilizzo benda', 'Utilizzo benda');
        h += '<div id="boxBenda" style="' + subBoxWrapper + '">';
        h += '<div style="' + subTitleStyle + '">Chi indossa la benda?</div>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optBenda" value="Tu" checked style="' + cbStyle + '"> Tu</label>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optBenda" value="Il partner" style="' + cbStyle + '"> Il partner</label>';
        h += '</div>';

        h += mkOpt('cbManette', 50, 'Utilizzo manette', 'Utilizzo manette');
        h += '<div id="boxManette" style="' + subBoxWrapper + '">';
        h += '<div style="' + subTitleStyle + '">Chi indossa le manette?</div>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optManette" value="Tu" checked style="' + cbStyle + '"> Tu</label>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optManette" value="Il partner" style="' + cbStyle + '"> Il partner</label>';
        h += '</div>';

        h += mkOpt('cbPosizione', 50, 'Posizione a tua scelta', 'Posizione a tua scelta');
        h += mkOpt('cbInsieme', 100, 'Fai venire il partner insieme a te', 'Fai venire il partner insieme a te');

        if (usrName === 'Stefano') {
          h += mkOpt('cbVieni', 50, 'Vieni dove vuoi tu', 'Vieni');
          h += '<div id="boxVieni" style="display:none;margin-top:4px;margin-bottom:12px">';
          h += '<input type="text" id="txtVieni" placeholder="Specifica dove..." style="width:100%;padding:14px;border-radius:12px;border:1px solid #d0d4e0;font-size:.95rem;font-family:inherit;background:#ffffff;color:#1a1f36;outline:none">';
          h += '</div>';
        }
        h += '</div></div>';

        h += '<div style="background:#f0f4fb;padding:16px;border-radius:12px;margin-top:24px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center;border:1px dashed #b0bcd8">';
        h += '<span style="font-size:.95rem;font-weight:700;color:#1a2a5e">Totale ordine</span>';
        h += '<span id="claimTotal" style="font-size:1.3rem;font-weight:800;color:#1a2a5e"><span style="color:#378add">🔷</span> ' + r.cost + ' pt</span>';
        h += '</div>';
        h += '<div style="display:flex;gap:12px">';
        h += '<button style="flex:1;background:#ffffff;color:#1a1f36;border:1px solid #d0d4e0;padding:14px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="cancel-overlay">Indietro</button>';
        h += '<button style="flex:2;background:#1a2a5e;color:#ffffff;border:none;padding:14px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="prepare-claim">Conferma ordine <span style="font-size:1.1em;vertical-align:bottom">→</span></button>';
        h += '</div></div></div>';
        setTimeout(window.updateClaimTotal, 10);
        return h;
      }"""

content = re.sub(r'if\s*\(\s*overlay\.type\s*!==\s*[\'"]claim[\'"]\s*\)\s*return\s*[\'"][\'"];.*?return\s*h;\s*\}', lambda m: new_overlay, content, flags=re.DOTALL)


# 3. Update `renderClaimConfirmOverlay` order summary popup
new_confirm = """function renderClaimConfirmOverlay() {
        var o = overlay;
        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);display:flex;align-items:center;justify-content:center;padding:24px" data-action="close-overlay">';
        h += '<div class="sheet" style="background:#ffffff;padding:32px 24px;border-radius:24px;text-align:center;width:100%;max-width:380px;box-shadow:0 10px 30px rgba(15,20,45,0.15)">';
        h += '<div style="font-size:2.8rem;margin-bottom:12px;line-height:1">👀</div>';
        h += '<h2 style="color:#1a1f36;font-size:1.4rem;font-weight:800;margin-bottom:8px">Riepilogo ordine</h2>';
        h += '<p style="font-size:.9rem;color:#8a8f9e;margin-bottom:24px;font-weight:500">Stai per acquistare <strong style="color:#1a1f36;font-weight:700">' + esc(o.reward.name) + '</strong></p>';

        h += '<div style="background:#f0f4fb;border-radius:16px;padding:20px;text-align:left;margin-bottom:24px">';
        h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem"><span style="color:#8a8f9e;font-weight:500">Costo base</span><span style="font-weight:700;color:#1a1f36"><span style="color:#378add">🔷</span> ' + o.reward.cost + ' pt</span></div>';
        if (o.premiumArr && o.premiumArr.length > 0) {
          o.premiumArr.forEach(function (p) { 
            var ptMatch = p.match(/\\(\\+([0-9]+)\\s*pt\\)/i);
            var cleanText = p.replace(/\\(\\+([0-9]+)\\s*pt\\)/i, '').trim();
            if (ptMatch) {
                h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem"><span style="color:#8a8f9e;font-weight:500">' + esc(cleanText) + '</span><span style="font-weight:700;color:#1a1f36"><span style="color:#378add">🔷</span> +' + ptMatch[1].replace(/\\D/g,'') + ' pt</span></div>';
            } else {
                h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem"><span style="color:#8a8f9e;font-weight:500">' + esc(p) + '</span></div>';
            }
          });
        }
        h += '<div style="border-top:1px dashed #b0bcd8;margin:16px 0"></div>';
        h += '<div style="display:flex;justify-content:space-between;align-items:center"><span style="font-size:1rem;font-weight:700;color:#1a2a5e">Totale finale</span><span style="font-size:1.3rem;font-weight:800;color:#1a2a5e"><span style="color:#378add">🔷</span> ' + o.totalCost + ' pt</span></div>';
        h += '</div>';

        var finalBal = myPts() - o.totalCost;
        h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding:0 8px">';
        h += '<span style="font-size:.85rem;color:#8a8f9e;font-weight:500">Saldo disponibile</span>';
        h += '<span style="font-size:.85rem;font-weight:700;color:#8a8f9e"><span style="color:#378add">🔷</span> ' + myPts() + ' pt <span style="margin:0 4px">→</span> <strong style="color:#1a7a4a">' + finalBal + ' pt</strong></span>';
        h += '</div>';

        h += '<div style="display:flex;gap:12px">';
        h += '<button style="flex:1;background:#ffffff;color:#1a1f36;border:1px solid #d0d4e0;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="cancel-overlay">Annulla</button>';
        h += '<button style="flex:1.5;background:#1a2a5e;color:#ffffff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="finalize-claim">Acquista ora <span style="font-size:1.1em;vertical-align:bottom">→</span></button>';
        h += '</div></div></div>';
        return h;
      }"""

content = re.sub(r'function\s+renderClaimConfirmOverlay\s*\(\)\s*\{.*?return\s*h;\s*\}', lambda m: new_confirm, content, flags=re.DOTALL)


# 4. Update `renderClaimSuccessOverlay`
new_success = """function renderClaimSuccessOverlay() {
        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);display:flex;align-items:center;justify-content:center;padding:24px">';
        h += '<div class="sheet" style="background:#ffffff;padding:40px 24px 32px;border-radius:24px;text-align:center;width:100%;max-width:340px;box-shadow:0 14px 40px rgba(15,20,45,0.2)">';
        h += '<div style="font-size:4rem;margin-bottom:20px;line-height:1">✅</div>';
        h += '<h2 style="color:#1a1f36;font-size:1.6rem;font-weight:800;margin-bottom:12px">Ordine Acquisito!</h2>';
        h += '<p style="font-size:.95rem;color:#8a8f9e;margin-bottom:32px;line-height:1.5;font-weight:500">Il tuo ordine per <strong style="color:#1a1f36">' + esc(overlay.reward.name) + '</strong> è andato a buon fine. Il partner riceverà la notifica!</p>';
        h += '<button style="width:100%;background:#1a2a5e;color:#ffffff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="close-success">Chiudi questa finestra</button>';
        h += '</div></div>';
        return h;
      }"""

content = re.sub(r'function\s+renderClaimSuccessOverlay\s*\(\)\s*\{.*?return\s*h;\s*\}', lambda m: new_success, content, flags=re.DOTALL)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Updated all modals successfully!")
