import sys

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

content = content.replace(
    'onclick="window.executeSubTab=\\\'ricevuti\\\';render()"',
    'data-action="set-subtab" data-arg="ricevuti"'
)
content = content.replace(
    'onclick="window.executeSubTab=\\\'inviati\\\';render()"',
    'data-action="set-subtab" data-arg="inviati"'
)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Click handlers fixed.")
