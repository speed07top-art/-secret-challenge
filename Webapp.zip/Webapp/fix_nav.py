import sys

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# Replace the broken string:
# `</button>'<button class="ni' + (tab === 'execute' ? ' on' : '') + '" data-action="set-tab" data-arg="execute" style="position:relative">`
# with:
# `</button>';\n        h += '<button class="ni' + (tab === 'execute' ? ' on' : '') + '" data-action="set-tab" data-arg="execute" style="position:relative">`

bad_str = "</button>'<button class=\"ni' + (tab === 'execute' ? ' on' : '') + '\" data-action=\"set-tab\" data-arg=\"execute\" style=\"position:relative\">"
fixed_str = "</button>';\n        h += '<button class=\"ni' + (tab === 'execute' ? ' on' : '') + '\" data-action=\"set-tab\" data-arg=\"execute\" style=\"position:relative\">"

content = content.replace(bad_str, fixed_str)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Navigation bar quote syntax error fixed.")
