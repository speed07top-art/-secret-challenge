import sys

def fix_file(filepath):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        print("Error reading:", e)
        return
    
    start_token = "function renderHomeHeader(me, pts, u) {"
    end_token = "function getActivityCountToday() {"
    
    s_idx = content.find(start_token)
    e_idx = content.find(end_token)
    
    if s_idx == -1 or e_idx == -1:
        print("Cannot find section to replace", s_idx, e_idx)
        return
        
    replacement = """function renderHomeHeader(me, pts, u) {
  var hr = new Date().getHours();
  var greeting = (hr >= 5 && hr < 17) ? 'Buongiorno' : 'Buonasera';
  var dAgo = u.lastRewardClaim ? daysAgo(u.lastRewardClaim) : 0;
  
  var h = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
  h += '<div><div style="font-size:.85rem;color:var(--muted);font-weight:600;margin-bottom:2px">'+greeting+'</div>';
  h += '<div style="font-size:1.5rem;font-weight:800;color:var(--b1);">'+esc(pname(me))+'</div></div>';
  h += '<div style="display:flex;gap:12px;align-items:center;">';
  h += '<div class="pts-badge" style="background:#1e293b;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:4px"><span>🔷</span> '+pts+' pt</div>';
  h += '<button style="width:36px;height:36px;border-radius:50%;background:#e2e8f0;border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--b3)" data-action="logout"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button>';
  h += '</div></div>';

  if (!u.lastRewardClaim) {
    h += '<div style="margin-bottom:16px;background:#fff;border:1px solid #e0eaf8;border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.03)" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '<div style="font-size:2rem;line-height:1">🛍️</div>';
    h += '<div><div style="font-size:.9rem;font-weight:800;color:var(--b2);margin-bottom:4px">Benvenuto nello Shop!</div><div style="font-size:.75rem;color:var(--b3);line-height:1.4">Fai il tuo <strong>primo acquisto</strong> per sbloccare l\\'analisi clinica.</div></div>';
    h += '</div>';
  } else if (dAgo >= 3) {
    h += '<div style="margin-bottom:16px;background:rgba(231,76,60,0.1);border:1px solid rgba(231,76,60,0.3);border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '<div style="font-size:2rem;line-height:1">🚨</div>';
    h += '<div><div style="font-size:.9rem;font-weight:800;color:#c0392b;margin-bottom:4px">Penalità Imminente!</div><div style="font-size:.75rem;color:#e74c3c;line-height:1.4">Sfogli lo <strong>Shop</strong> e acquista qualcosa per disinnescare la penalità!</div></div>';
    h += '</div>';
  } else if (dAgo === 2) {
    h += '<div style="margin-bottom:16px;background:rgba(243,156,18,0.1);border:1px dashed rgba(243,156,18,0.4);border-radius:16px;padding:12px;text-align:center;cursor:pointer;font-size:.8rem;color:#d68910;font-weight:700" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '⏳ Sei a quota 2 giorni senza acquisti. Rimedia prima della penalità!';
    h += '</div>';
  }
  return h;
}

function renderFlashSaleWidget() {
  var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
  var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
  var fSales = [];
  if (myRewards.length > 0) {
    var a = myRewards.slice();
    var seed = epoch;
    for (var i = a.length - 1; i > 0; i--) {
      var x = Math.sin(seed++) * 10000;
      var rNum = x - Math.floor(x);
      var j = Math.floor(rNum * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    fSales = a.slice(0, 3);
  }
  if (!fSales.length) return '';

  var hrsLeft = 5 - (Math.floor(Date.now() / 3600000) % 5);
  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:var(--b1);font-size:.9rem">Flash Sale</div>';
  h += '<div style="font-size:.7rem;color:#f36c53;background:#ffece8;font-weight:800;padding:4px 10px;border-radius:12px">Scade tra '+hrsLeft+'h</div>';
  h += '</div>';

  h += '<div style="display:flex;gap:12px;overflow-x:auto;padding-bottom:15px;margin:0 -20px 16px;padding-left:20px;padding-right:20px;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;">';
  var fSeed = epoch;
  fSales.forEach(function(fs) {
    var fx = Math.sin(fSeed++) * 10000;
    var dscPct = (fx - Math.floor(fx)) > 0.5 ? 0.10 : 0.05;
    var dscCost = Math.floor(fs.cost * (1 - dscPct));
    var descText = fs.desc || 'Premio in sconto da non perdere!';
    
    h += '<div style="flex:0 0 160px;scroll-snap-align:start;background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;position:relative;box-shadow:0 6px 12px rgba(0,0,0,0.03);display:flex;flex-direction:column;min-height:220px;" data-action="open-claim" data-arg="'+fs.id+'" data-arg2="'+dscCost+'">';
    h += '<div style="position:absolute;top:12px;right:12px;background:#c0392b;color:#fff;font-size:.75rem;font-weight:800;padding:3px 8px;border-radius:8px">-'+(dscPct*100)+'%</div>';
    h += '<div style="font-size:2rem;margin-bottom:10px">'+(fs.emoji||'🎁')+'</div>';
    h += '<div style="font-size:.85rem;font-weight:800;color:var(--b1);margin-bottom:4px;line-height:1.2;flex-shrink:0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">'+esc(fs.name)+'</div>';
    h += '<div style="font-size:.7rem;color:var(--muted);line-height:1.3;margin-bottom:10px;flex:1;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical">'+esc(descText)+'</div>';
    h += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px">';
    h += '<div style="font-size:1.1rem;font-weight:900;color:var(--b2)">🔷 '+dscCost+'</div>';
    h += '<div style="font-size:.7rem;color:#94a3b8;text-decoration:line-through">'+fs.cost+'</div>';
    h += '</div>';
    h += '<button style="width:100%;background:#1e293b;color:white;border:none;padding:10px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;pointer-events:none">Acquista ora</button>';
    h += '</div>';
  });
  h += '</div>';
  return h;
}

function renderLastOrderWidget(myReqs) {
  var allMe = myReqs.slice().reverse();
  if (allMe.length === 0) return '';
  var lr = allMe[0];

  var s = lr.status;
  var bc = s==='pending'?'badge-wait':s==='done'?'badge-ok':s==='done_confirm'?'badge-conf':'badge-exp';
  var bt = s==='pending'?'⏳ Lavorazione':s==='done'?'✅ Consegnato':s==='done_confirm'?'🔔 Conferma':'⏰ Scaduto';

  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:var(--b1);font-size:.9rem">Ultimo ordine</div>';
  h += '<button style="background:none;border:none;color:#60a5fa;font-size:.75rem;font-weight:700;cursor:pointer" data-action="toggle-history">Storico →</button>';
  h += '</div>';

  h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
  h += '<div style="display:flex;gap:14px;align-items:center;margin-bottom:16px">';
  h += '<div style="width:48px;height:48px;background:#f1f5f9;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">'+(lr.emoji||'🎁')+'</div>';
  h += '<div style="flex:1;overflow:hidden">';
  h += '<div style="font-size:.85rem;font-weight:800;color:var(--b1);margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(lr.name)+'</div>';
  h += '<div style="font-size:.7rem;color:var(--muted);margin-bottom:6px">'+fmtDt(lr.requestedAt)+'</div>';
  h += '<span class="ar-badge '+bc+'" style="font-size:.65rem;padding:3px 8px">'+bt+'</span>';
  h += '</div>';
  h += '</div>';
  h += '<button style="width:100%;background:#f8fafc;color:#334155;border:1px solid #e2e8f0;padding:12px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;cursor:pointer" data-action="view-order" data-arg="'+esc(lr.id)+'" data-arg2="0">Vedi dettaglio ordine →</button>';
  h += '</div>';
  return h;
}

function renderGamesCTA() {
  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:var(--b1);font-size:.9rem">Giochi e quiz</div>';
  h += '<div style="font-size:.7rem;color:#8b5cf6;background:#f5f3ff;font-weight:800;padding:4px 10px;border-radius:12px">Novità</div>';
  h += '</div>';

  h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:20px;position:relative;overflow:hidden;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
  h += '<div style="position:absolute;top:-40px;right:-40px;width:150px;height:150px;background:#f5f3ff;border-radius:50%;z-index:0"></div>';
  h += '<div style="position:relative;z-index:1">';
  h += '<div style="font-size:1.8rem;margin-bottom:12px">🎮</div>';
  h += '<div style="font-size:.95rem;font-weight:800;color:var(--b1);margin-bottom:6px">Sfide e quiz di coppia</div>';
  h += '<div style="font-size:.75rem;color:var(--muted);line-height:1.4;margin-bottom:16px">Gioca insieme, rispondi ai quiz e accumula punti extra da spendere nello shop.</div>';
  h += '<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">';
  h += '<button style="background:#1e293b;color:white;border:none;padding:10px 16px;border-radius:12px;font-size:.8rem;font-weight:700;cursor:pointer" onclick="showToast(\\'In arrivo prossimamente!\\')">Scopri i giochi →</button>';
  h += '<div style="font-size:.75rem;color:#8b5cf6;font-weight:800;background:#f5f3ff;padding:6px 10px;border-radius:10px">✦ +pt bonus</div>';
  h += '</div></div></div>';
  return h;
}
"""

    new_content = content[:s_idx] + replacement + "\n" + content[e_idx:]
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(new_content)
    print("Done")

fix_file("/Users/lavoro/Downloads/Webapp/index.html")
