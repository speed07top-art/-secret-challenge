import re
import sys

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Remove auto popup from checkFlashQuestion
# Lines: "          // Auto-open as overlay popup\n          overlay = { type: 'activity' };\n          render();"
content = re.sub(
    r'// Auto-open as overlay popup\s+overlay\s*=\s*\{\s*type:\s*[\'"]activity[\'"]\s*\};\s*render\(\);',
    '',
    content
)

# 2. Remove home banners showing active games in renderApp
# Lines 2911: `if (flashQ && !overlay) { ... } else if (miniGame && !overlay) { ... }`
content = re.sub(
    r'if\s*\(\s*flashQ\s*&&\s*!overlay\s*\)\s*\{.*?\}\s*else\s*if\s*\(\s*miniGame\s*&&\s*!overlay\s*\)\s*\{.*?\}',
    '',
    content,
    flags=re.DOTALL
)

# 3. Add `else if (tab === 'giochi')` branch logic
# I will attach it right after `else if (tab === 'shop') { ... }`
# Wait, actually it's easier to find `else if (tab === 'execute')` and insert it BEFORE that.
giochi_tab = """else if (tab === 'giochi') {
          var hr = new Date().getHours();
          var hTop = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
          hTop += '<div style="font-size:1.6rem;font-weight:800;color:#1a1f36;font-family:\\'Playfair Display\\',serif">Giochi</div>';
          hTop += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:6px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
          hTop += '</div>';
          page += hTop;

          var activeHours = [];
          var futureHours = [];
          var pastHours = [];

          ALL_ACTIVITY_HOURS.forEach(function(h) {
            var slotK = new Date().getFullYear() + '-' + new Date().getMonth() + '-' + new Date().getDate() + '-' + h;
            var doneK = 'fq_done_' + session + '_' + slotK;
            var isDone = !!localStorage.getItem(doneK);

            var isQuiz = QUIZ_HOURS.indexOf(h)>=0;
            var sch = GAME_SCHEDULE[h];
            
            var item = { h: h, isDone: isDone, isQuiz: isQuiz, slotK: slotK };
            item.icon = isQuiz ? '⚡' : (sch ? sch.icon : '🎮');
            item.name = isQuiz ? 'Domanda Flash' : (sch ? sch.name : 'Mini-gioco');
            item.desc = isQuiz ? 'Rispondi alla domanda a tempo' : 'Gioca e raddoppia i punti';

            if (h === hr) activeHours.push(item);
            else if (h > hr) futureHours.push(item);
            else pastHours.push(item);
          });

          var renderActiveGameCard = function(ico, title, desc, btnTxt, action, arg) {
            var h = '<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:20px;padding:20px;box-shadow:0 8px 24px rgba(0,0,0,0.06);margin-bottom:20px;display:flex;flex-direction:column;gap:12px">';
            h += '<div style="display:flex;align-items:center;gap:14px">';
            h += '<div style="width:60px;height:60px;background:#eef3fb;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:2.2rem;flex-shrink:0">'+ico+'</div>';
            h += '<div><div style="font-size:1.1rem;font-weight:800;color:#1a1f36;margin-bottom:4px">'+title+'</div>';
            h += '<div style="font-size:.8rem;color:#8a8f9e">'+desc+'</div></div></div>';
            h += '<button style="width:100%;background:#1a2a5e;color:#ffffff;border:none;padding:14px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="'+action+'" data-arg="'+arg+'">'+btnTxt+'</button>';
            h += '</div>';
            return h;
          };

          var renderDisabledGameCard = function(ico, title, statusTxt, isPast) {
            var op = isPast ? '0.6' : '0.8';
            var bg = isPast ? '#f8f9fc' : '#ffffff';
            var h = '<div style="background:'+bg+';border:1px solid #e2e8f0;border-radius:16px;padding:14px;margin-bottom:12px;display:flex;align-items:center;gap:14px;opacity:'+op+'">';
            h += '<div style="width:48px;height:48px;background:#eef3fb;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">'+ico+'</div>';
            h += '<div style="flex:1"><div style="font-size:.95rem;font-weight:700;color:#1a1f36;margin-bottom:4px">'+title+'</div>';
            h += '<div style="font-size:.75rem;color:#8a8f9e;font-weight:600">'+statusTxt+'</div></div>';
            h += '<div style="color:#b0bcd8">' + (isPast ? (statusTxt.indexOf('Completato')>=0?'✅':'⏰') : '🔒') + '</div>';
            h += '</div>';
            return h;
          };

          var hasActive = false;
          if (flashQ && !flashQ.answered && !localStorage.getItem('fq_done_' + session + '_' + flashQ.slotKey)) {
             hasActive = true;
             page += renderActiveGameCard('⚡', 'Domanda Flash', 'Rispondi prima che scada il tempo!', 'Gioca Subito →', 'open-activity', 'flash');
          } else if (miniGame && !miniGame.played && !localStorage.getItem('fq_done_' + session + '_' + miniGame.slotKey)) {
             hasActive = true;
             page += renderActiveGameCard(miniGame.icon, miniGame.name, 'Gioca subito per vincere punti extra!', 'Gioca Subito 🎮', 'open-activity', 'game');
          }

          if (!hasActive && activeHours.length > 0 && !activeHours[0].isDone) {
             // Fallback active item
             var act = activeHours[0];
             page += renderActiveGameCard(act.icon, act.name, act.desc, 'Gioca Subito →', 'open-activity', 'fallback');
          }

          page += '<div style="font-size:.75rem;font-weight:800;color:#6b7080;text-transform:uppercase;margin-top:24px;margin-bottom:12px;letter-spacing:.05em">Prossimi Eventi</div>';
          if (futureHours.length === 0) page += '<div style="font-size:.8rem;color:#8a8f9e;margin-bottom:16px">Nessun evento in programma per oggi.</div>';
          futureHours.forEach(function(item) {
             var diffH = item.h - hr;
             var diffLabel = 'Tra ' + diffH + ' ora/e';
             page += renderDisabledGameCard(item.icon, item.name, diffLabel, false);
          });

          page += '<div style="font-size:.75rem;font-weight:800;color:#6b7080;text-transform:uppercase;margin-top:24px;margin-bottom:12px;letter-spacing:.05em">Storico Oggi</div>';
          var allPast = pastHours.concat();
          if (activeHours.length > 0 && activeHours[0].isDone) allPast.push(activeHours[0]);
          
          if (allPast.length === 0) {
             page += '<div style="font-size:.8rem;color:#8a8f9e;margin-bottom:16px;padding-bottom:20px">Non hai ancora giocato oggi.</div>';
          } else {
             allPast.forEach(function(item) {
                var statusLabel = item.isDone ? 'Completato' : 'Scaduto';
                page += renderDisabledGameCard(item.icon, item.name, statusLabel, true);
             });
             page += '<div style="height:20px"></div>';
          }
        }
        else if (tab === 'execute')"""

content = re.sub(
    r'else\s+if\s*\(\s*tab\s*===\s*[\'"]execute[\'"]', 
    lambda m: giochi_tab, 
    content, 
    count=1
)


# 4. Modify Bottom Navigation Bar (bnav)
# Need to inject the Giochi button before Ordini (execute):
giochi_btn = '<button class="ni\' + (tab === \'giochi\' ? \' on\' : \'\') + \'" data-action="set-tab" data-arg="giochi"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2" ry="2"></rect><line x1="6" y1="12" x2="10" y2="12"></line><line x1="8" y1="10" x2="8" y2="14"></line><circle cx="15" cy="12" r="1"></circle><circle cx="17" cy="10" r="1"></circle></svg><span>Giochi</span></button>'
# I will match `<button class="ni' + (tab === 'execute'` and insert `giochi_btn` right before it.
content = content.replace(
    '\'<button class="ni\' + (tab === \'execute\'',
    '\'' + giochi_btn + '\'<button class="ni\' + (tab === \'execute\''
)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Games tab and layout modifications deployed successfully.")
