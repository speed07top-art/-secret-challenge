import sys

with open("index.html", "r", encoding="utf-8") as f:
    c = f.read()

target = "if (tab !== 'home') {"
replacement = "if (tab !== 'home' && tab !== 'shop') {"
c = c.replace(target, replacement)

target2 = "h += '<div class=\"page'+(tab==='home'?' home-page':'')+'\" '+(tab==='home'?'style=\"padding-top:0;display:block\"':'')+'>'+page+'</div>';"
replacement2 = "var cssMod = (tab==='home'||tab==='shop') ? 'style=\"padding-top:0;display:block\"' : '';\\n  h += '<div class=\"page'+((tab==='home'||tab==='shop')?' home-page':'')+'\" '+cssMod+'>'+page+'</div>';"
c = c.replace(target2, replacement2.replace('\\n', '\n'))

with open("index.html", "w", encoding="utf-8") as f:
    f.write(c)

print("Fixed topbar and page wrapper.")
