import sys

with open("index.html", "r", encoding="utf-8") as f:
    content = f.read()

# 1. Insert getFlashSaleInfo
if "function getFlashSaleInfo" not in content:
    idx = content.find("function getActivityCountToday")
    helper = """function getFlashSaleInfo(itemId) {
  var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
  var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
  var fSales = [];
  if (myRewards.length > 0) {
    var a = myRewards.slice();
    var seed = epoch;
    for (var i = a.length - 1; i > 0; i--) {
      var x = Math.sin(seed++) * 10000;
      var rNum = x - Math.floor(x);
      var j = Math.floor(rNum * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    fSales = a.slice(0, 3);
  }
  var idx = fSales.findIndex(function(fs){ return fs.id === itemId; });
  if (idx === -1) return null;
  var fSeed = epoch + idx;
  var fx = Math.sin(fSeed) * 10000;
  var dscPct = (fx - Math.floor(fx)) > 0.5 ? 0.10 : 0.05;
  return dscPct;
}

"""
    content = content[:idx] + helper + content[idx:]

# 2. Update renderApp `else if (tab === 'shop')`
s_shop = content.find("else if (tab === 'shop') {")
e_shop = content.find("else if (tab === 'execute') {", s_shop)

new_shop_tab = """else if (tab === 'shop') {
    var hTop = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
    hTop += '<div style="font-size:1.6rem;font-weight:800;color:#1a1f36;font-family:\\'Playfair Display\\',serif">Shop</div>';
    hTop += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:6px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
    hTop += '</div>';
    page += hTop;

    var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
    var fSalesCount = 0;
    var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
    if (myRewards.length > 0) {
      fSalesCount = Math.min(3, myRewards.length);
    }

    if (fSalesCount > 0) {
      var hrsLeft = 5 - (Math.floor(Date.now() / 3600000) % 5);
      var hBanner = '<div style="background:#1a2a5e;border-radius:16px;padding:20px;display:flex;justify-content:space-between;align-items:center;margin-bottom:24px">';
      hBanner += '<div><div style="font-size:.7rem;font-weight:800;color:#8fa8d8;text-transform:uppercase;margin-bottom:4px">FLASH SALE ATTIVA</div>';
      hBanner += '<div style="font-size:1.05rem;font-weight:800;color:#ffffff;margin-bottom:4px">Sconti fino al -10%</div>';
      hBanner += '<div style="font-size:.7rem;color:#8fa8d8">Scade tra '+hrsLeft+'h — non perdere l\\'offerta</div></div>';
      hBanner += '<div style="background:#c04020;border-radius:12px;padding:8px 12px;text-align:center;min-width:70px">';
      hBanner += '<div style="font-size:.65rem;color:#ffd0c0;font-weight:800;text-transform:uppercase;margin-bottom:2px">SCADE TRA</div>';
      hBanner += '<div style="font-size:1.2rem;font-weight:800;color:#ffffff;line-height:1">'+hrsLeft+'h</div></div></div>';
      page += hBanner;
    }

    page += '<div style="font-size:.75rem;font-weight:800;color:#6b7080;text-transform:uppercase;margin-bottom:12px;letter-spacing:.05em">VETRINA PRODOTTI</div>';
    
    if (!myRws.length) {
      page += '<div class="empty"><span class="empty-ico">🛍️</span><p>Nessun prodotto in inventario.<br>Il fornitore li aggiungerà presto!</p></div>';
    } else {
      myRws.forEach(function(r) { page += renderShopItem(r, pts); });
      page += '<div style="text-align:center;font-size:.8rem;color:#b0b4c0;margin-top:24px;margin-bottom:20px">Hai visto tutti i prodotti disponibili</div>';
    }
    
    var dAgo = u.lastRewardClaim ? daysAgo(u.lastRewardClaim) : 0;
    if (dAgo >= 3) page += renderMandatoryAlert();
  }
  """
content = content[:s_shop] + new_shop_tab + content[e_shop:]

# 3. Update renderShopItem
s_item = content.find("function renderShopItem(r, pts) {")
e_item = content.find("return h;\n}", s_item) + len("return h;\n}")
new_item = """function renderShopItem(r, pts) {
  var dscPct = typeof getFlashSaleInfo === "function" ? getFlashSaleInfo(r.id) : null;
  var finalCost = dscPct ? Math.floor(r.cost * (1 - dscPct)) : r.cost;
  var canAfford = pts >= finalCost;
  
  var borderCol = dscPct ? '#f0c8be' : '#e2e8f0';
  var iconBg = dscPct ? '#fff0ec' : '#eef3fb';
  
  var h = '<div style="background:#ffffff;border:1px solid '+borderCol+';border-radius:16px;padding:16px;margin-bottom:12px;display:flex;gap:14px;align-items:center;position:relative">';
  if (dscPct) {
    h += '<div style="position:absolute;top:12px;right:12px;background:#c04020;color:#ffffff;font-size:.7rem;font-weight:800;padding:3px 8px;border-radius:8px">-'+(dscPct*100)+'%</div>';
  }
  h += '<div style="width:54px;height:54px;background:'+iconBg+';border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.8rem;flex-shrink:0">'+(r.emoji||'🛍️')+'</div>';
  h += '<div style="flex:1">';
  h += '<div style="font-size:1.05rem;font-weight:800;color:#1a1f36;margin-bottom:4px">'+esc(r.name)+'</div>';
  if (r.desc) h += '<div style="font-size:.75rem;color:#8a8f9e;line-height:1.4;margin-bottom:10px">'+esc(r.desc)+'</div>';
  
  h += '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px">';
  h += '<div style="display:flex;align-items:center;gap:6px">';
  h += '<div style="font-size:1.05rem;font-weight:900;color:#1a1f36"><span style="color:#378add">🔷</span> '+finalCost+' pt</div>';
  if (dscPct) {
    h += '<div style="font-size:.7rem;color:#b0b4c0;text-decoration:line-through">'+r.cost+'</div>';
  }
  h += '</div>';
  
  if (canAfford) {
    h += '<button style="background:#1a2a5e;color:#ffffff;border:none;padding:8px 16px;border-radius:10px;font-size:.8rem;font-weight:700;cursor:pointer" data-action="open-claim" data-arg="'+esc(r.id)+'" '+(dscPct?'data-arg2="'+finalCost+'"':'')+'>Acquista</button>';
  } else {
    h += '<button style="background:#f0f2f8;color:#a0a8be;border:none;padding:8px 16px;border-radius:10px;font-size:.8rem;font-weight:700;cursor:not-allowed" disabled>Fondi errati</button>';
  }
  h += '</div>';
  h += '</div>';
  h += '</div>';
  return h;
}"""
content = content[:s_item] + new_item + content[e_item:]

with open("index.html", "w", encoding="utf-8") as f:
    f.write(content)
print("Shop updated successfully.")
