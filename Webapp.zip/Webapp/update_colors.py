import os
import sys

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Update background CSS variable
content = content.replace("--surface:#f0f5ff", "--surface:#f0f2f8")

# 2. Remove Premium Options block in renderMyReqCard
s_prem = content.find("if (premiumList2.length > 0) {")
if s_prem != -1:
    e_prem = content.find("if (plainNote2) h +=", s_prem)
    if e_prem != -1:
        content = content[:s_prem] + content[e_prem:]

# 3. Add styling to the bottom nav inside the head styles
style_insert = "\n.bnav .ni { color: #a0a8be; }\n.bnav .ni.on { color: #1a2a5e; }\n.bnav .ni svg { stroke: currentColor; }\n"
content = content.replace("</style>", style_insert + "</style>")

# 4. Re-declare the Home components completely to guarantee exact matches
start_token = "function renderHomeHeader(me, pts, u) {"
end_token = "function getActivityCountToday() {"

s_idx = content.find(start_token)
e_idx = content.find(end_token)

if s_idx != -1 and e_idx != -1:
    replacement = """function renderHomeHeader(me, pts, u) {
  var hr = new Date().getHours();
  var greeting = (hr >= 5 && hr < 17) ? 'Buongiorno' : 'Buonasera';
  var dAgo = u.lastRewardClaim ? daysAgo(u.lastRewardClaim) : 0;
  
  var h = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
  h += '<div><div style="font-size:.85rem;color:#6b7080;font-weight:600;margin-bottom:2px">'+greeting+'</div>';
  h += '<div style="font-size:1.5rem;font-weight:800;color:#1a1f36;">'+esc(pname(me))+'</div></div>';
  h += '<div style="display:flex;gap:12px;align-items:center;">';
  h += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:4px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
  h += '<button style="width:36px;height:36px;border-radius:50%;background:#e2e8f0;border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--b3)" data-action="logout"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button>';
  h += '</div></div>';

  if (!u.lastRewardClaim) {
    h += '<div style="margin-bottom:16px;background:#fff;border:1px solid #e0eaf8;border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.03)" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '<div style="font-size:2rem;line-height:1">🛍️</div>';
    h += '<div><div style="font-size:.9rem;font-weight:800;color:#1a2a5e;margin-bottom:4px">Benvenuto nello Shop!</div><div style="font-size:.75rem;color:var(--b3);line-height:1.4">Fai il tuo <strong>primo acquisto</strong> per sbloccare l\\'analisi clinica.</div></div>';
    h += '</div>';
  } else if (dAgo >= 3) {
    h += '<div style="margin-bottom:16px;background:rgba(231,76,60,0.1);border:1px solid rgba(231,76,60,0.3);border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '<div style="font-size:2rem;line-height:1">🚨</div>';
    h += '<div><div style="font-size:.9rem;font-weight:800;color:#c0392b;margin-bottom:4px">Penalità Imminente!</div><div style="font-size:.75rem;color:#e74c3c;line-height:1.4">Sfogli lo <strong>Shop</strong> e acquista qualcosa per disinnescare la penalità!</div></div>';
    h += '</div>';
  } else if (dAgo === 2) {
    h += '<div style="margin-bottom:16px;background:rgba(243,156,18,0.1);border:1px dashed rgba(243,156,18,0.4);border-radius:16px;padding:12px;text-align:center;cursor:pointer;font-size:.8rem;color:#d68910;font-weight:700" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '⏳ Sei a quota 2 giorni senza acquisti. Rimedia prima della penalità!';
    h += '</div>';
  }
  return h;
}

function renderFlashSaleWidget() {
  var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
  var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
  var fSales = [];
  if (myRewards.length > 0) {
    var a = myRewards.slice();
    var seed = epoch;
    for (var i = a.length - 1; i > 0; i--) {
      var x = Math.sin(seed++) * 10000;
      var rNum = x - Math.floor(x);
      var j = Math.floor(rNum * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    fSales = a.slice(0, 3);
  }
  if (!fSales.length) return '';

  var hrsLeft = 5 - (Math.floor(Date.now() / 3600000) % 5);
  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:#1a1f36;font-size:.9rem">Flash Sale</div>';
  h += '<div style="font-size:.7rem;color:#c04020;background:#ffe8e0;font-weight:800;padding:4px 10px;border-radius:12px">Scade tra '+hrsLeft+'h</div>';
  h += '</div>';

  h += '<div style="display:flex;gap:12px;overflow-x:auto;padding-bottom:15px;margin-bottom:16px;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;">';
  var fSeed = epoch;
  fSales.forEach(function(fs) {
    var fx = Math.sin(fSeed++) * 10000;
    var dscPct = (fx - Math.floor(fx)) > 0.5 ? 0.10 : 0.05;
    var dscCost = Math.floor(fs.cost * (1 - dscPct));
    var descText = fs.desc || 'Premio in sconto da non perdere!';
    
    h += '<div style="flex:0 0 160px;scroll-snap-align:start;background:#ffffff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;position:relative;box-shadow:0 6px 12px rgba(0,0,0,0.03);display:flex;flex-direction:column;min-height:220px;" data-action="open-claim" data-arg="'+fs.id+'" data-arg2="'+dscCost+'">';
    h += '<div style="position:absolute;top:12px;right:12px;background:#c04020;color:#fff;font-size:.75rem;font-weight:800;padding:3px 8px;border-radius:8px">-'+(dscPct*100)+'%</div>';
    h += '<div style="font-size:2rem;margin-bottom:10px">'+(fs.emoji||'🎁')+'</div>';
    h += '<div style="font-size:.85rem;font-weight:800;color:#1a1f36;margin-bottom:4px;line-height:1.2;flex-shrink:0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">'+esc(fs.name)+'</div>';
    h += '<div style="font-size:.7rem;color:#b0b4c0;line-height:1.3;margin-bottom:10px;flex:1;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical">'+esc(descText)+'</div>';
    h += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px">';
    h += '<div style="font-size:1.1rem;font-weight:900;color:#1a1f36"><span style="color:#378add">🔷</span> '+dscCost+'</div>';
    h += '<div style="font-size:.7rem;color:#b0b4c0;text-decoration:line-through">'+fs.cost+'</div>';
    h += '</div>';
    h += '<button style="width:100%;background:#1a2a5e;color:white;border:none;padding:10px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;pointer-events:none">Acquista ora</button>';
    h += '</div>';
  });
  h += '</div>';
  return h;
}

function renderLastOrderWidget(myReqs) {
  var allMe = myReqs.slice().reverse();
  if (allMe.length === 0) return '';
  var lr = allMe[0];

  var s = lr.status;
  var bc = s==='pending'?'badge-wait':s==='done'?'badge-ok':s==='done_confirm'?'badge-conf':'badge-exp';
  
  var bt = s==='pending'?'⏳ Lavorazione':s==='done'?'✅ Consegnato':s==='done_confirm'?'🔔 Conferma':'⏰ Scaduto';
  var badgeStyleText = '';
  if(s==='done') {
    badgeStyleText = 'background:#e6f7ee;color:#1a7a4a;border:none;padding:4px 10px;border-radius:12px;font-size:.65rem;font-weight:700;';
  } else {
    badgeStyleText = 'font-size:.65rem;padding:3px 8px;';
  }

  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:#1a1f36;font-size:.9rem">Ultimo ordine</div>';
  h += '<button style="background:none;border:none;color:#378add;font-size:.75rem;font-weight:700;cursor:pointer" data-action="set-tab" data-arg="execute">Storico →</button>';
  h += '</div>';

  h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
  h += '<div style="display:flex;gap:14px;align-items:center;margin-bottom:16px">';
  h += '<div style="width:48px;height:48px;background:#eef3fb;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">'+(lr.emoji||'🎁')+'</div>';
  h += '<div style="flex:1;overflow:hidden">';
  h += '<div style="font-size:.85rem;font-weight:800;color:#1a1f36;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(lr.name)+'</div>';
  h += '<div style="font-size:.7rem;color:var(--muted);margin-bottom:6px">'+fmtDt(lr.requestedAt)+'</div>';
  h += '<span class="ar-badge '+bc+'" style="'+badgeStyleText+'">'+bt+'</span>';
  h += '</div>';
  h += '</div>';
  h += '<button style="width:100%;background:#f4f6fc;color:#1a2a5e;border:none;padding:12px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;cursor:pointer" data-action="view-order" data-arg="'+esc(lr.id)+'" data-arg2="0">Vedi dettaglio ordine →</button>';
  h += '</div>';
  return h;
}

function renderGamesCTA() {
  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:#1a1f36;font-size:.9rem">Mini-giochi e quiz</div>';
  h += '<div style="font-size:.7rem;color:#6c3fc4;background:#f0eaff;font-weight:800;padding:4px 10px;border-radius:12px">Novità</div>';
  h += '</div>';

  h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:20px;position:relative;overflow:hidden;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
  h += '<div style="position:absolute;top:-40px;right:-40px;width:150px;height:150px;background:#f4f0ff;border-radius:50%;z-index:0"></div>';
  h += '<div style="position:relative;z-index:1">';
  h += '<div style="font-size:1.8rem;margin-bottom:12px">🎮</div>';
  h += '<div style="font-size:.95rem;font-weight:800;color:#1a1f36;margin-bottom:6px">Mini-giochi e quiz</div>';
  h += '<div style="font-size:.75rem;color:var(--muted);line-height:1.4;margin-bottom:16px">Gioca ai divertenti mini-giochi, rispondi ai quiz e accumula punti extra da spendere nello shop.</div>';
  h += '<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">';
  h += '<button style="background:#1a2a5e;color:white;border:none;padding:10px 16px;border-radius:12px;font-size:.8rem;font-weight:700;cursor:pointer" onclick="showToast(\\'In arrivo prossimamente!\\')">Scopri i giochi →</button>';
  h += '<div style="font-size:.75rem;color:#6c3fc4;font-weight:800;background:#f4f0ff;padding:6px 10px;border-radius:10px">✦ +pt bonus</div>';
  h += '</div></div></div>';
  return h;
}
\n"""
    content = content[:s_idx] + replacement + content[e_idx:]

s_w = content.find("function renderWellnessWidget(me) {")
if s_w != -1:
    e_w = content.find("return h;\n}", s_w) + len("return h;\n}")
    new_well = """function renderWellnessWidget(me) {
  var xStats = getExtendedBenessereStats(me);
  var streak = xStats.streak;
  var mCount = xStats.m;
  
  var thresholds = [0, 3, 5, 7, 10, 14];
  var lvls = ['Esplorazione','Germoglio','Scintilla','Fiamma','Cristallo','Leggenda'];
  var myW = xStats.w;
  var lvlId = 0;
  for (var i=5; i>=0; i--) if(myW >= thresholds[i]) { lvlId = i; break; }
  
  var nextLvlText = lvlId < 5 ? lvls[lvlId+1] : 'Max';
  var progVal = lvlId < 5 ? (myW - thresholds[lvlId]) : 1;
  var progMax = lvlId < 5 ? (thresholds[lvlId+1] - thresholds[lvlId]) : 1;
  if(lvlId===0) { progVal = myW; progMax = 3; }
  var pct = Math.floor((progVal/progMax)*100);

  var subText = lvlId === 0 ? 'Ottimo Inizio, continuate così!' : (lvlId > 2 ? 'Siete in perfetta sintonia! 🔥' : 'Avete un bel ritmo, continuate così!');

  var h = '<div style="background:#1a2a5e;border-radius:20px;padding:20px;color:white;margin-bottom:24px;box-shadow:0 12px 24px rgba(26,42,94,0.2)">';
  h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">';
  h += '<span style="font-size:.7rem;font-weight:700;color:#8fa8d8;letter-spacing:.05em">IL TUO PROGRESSO</span>';
  h += '<span style="font-size:.7rem;background:rgba(255,255,255,0.10);padding:4px 10px;border-radius:12px;font-weight:600;color:white">'+xStats.w+'/sett.</span>';
  h += '</div>';
  h += '<div style="font-size:1.05rem;font-weight:800;color:#e8edf8;font-family:\\'Playfair Display\\',serif;margin-bottom:20px">'+subText+'</div>';
  
  h += '<div style="display:flex;gap:10px;margin-bottom:20px">';
  h += '<div style="flex:1;background:rgba(255,255,255,0.07);border-radius:12px;padding:12px;text-align:center">';
  h += '<div style="font-size:1.2rem;font-weight:800;color:white;margin-bottom:4px">'+streak+'</div>';
  h += '<div style="font-size:.65rem;color:#8fa8d8;line-height:1.2">Streak<br>sett.</div>';
  h += '</div>';
  h += '<div style="flex:1;background:rgba(255,255,255,0.07);border-radius:12px;padding:12px;text-align:center">';
  h += '<div style="font-size:1.2rem;font-weight:800;color:#7ee8b0;margin-bottom:4px">'+mCount+'</div>';
  h += '<div style="font-size:.65rem;color:#8fa8d8;line-height:1.2">Ordini<br>30G</div>';
  h += '</div>';
  h += '<div style="flex:1;background:rgba(255,255,255,0.07);border-radius:12px;padding:12px;text-align:center">';
  h += '<div style="font-size:1.2rem;font-weight:800;color:#f8c97a;margin-bottom:4px">Lv '+lvlId+'</div>';
  h += '<div style="font-size:.65rem;color:#8fa8d8;line-height:1.2">Livello<br>attuale</div>';
  h += '</div>';
  h += '</div>';

  h += '<div style="display:flex;justify-content:space-between;align-items:center;font-size:.75rem;color:#8fa8d8;margin-bottom:8px">';
  h += '<span>Prossimo livello: <strong style="color:white">'+nextLvlText+'</strong></span>';
  h += '<span>'+progVal+'/'+progMax+'</span>';
  h += '</div>';
  h += '<div style="height:6px;background:rgba(255,255,255,0.15);border-radius:3px;margin-bottom:16px;overflow:hidden"><div style="height:100%;width:'+pct+'%;background:#7eb3f5;border-radius:3px"></div></div>';
  h += '<div style="text-align:right"><button style="background:none;border:none;color:#7eb3f5;font-size:.75rem;font-weight:700;font-family:sans-serif;cursor:pointer" data-action="set-tab" data-arg="benessere">Analisi completa →</button></div>';

  h += '</div>';
  return h;
}"""
    content = content[:s_w] + new_well + content[e_w:]

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Updated successfully")
