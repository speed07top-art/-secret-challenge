import re

with open("/Users/lavoro/Downloads/Webapp/index.html", "r", encoding="utf-8") as f:
    c = f.read()

m = re.search(r"<script>\s*(.*?)\s*</script>", c, re.DOTALL)
if not m:
    print("No script")
    exit()

code = m.group(1)
lines = code.split("\n")

def strip_quotes_and_comments(text):
    text = re.sub(r'//.*', '', text)
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    # Strip string literals avoiding escaping issues
    text = re.sub(r"'([^'\\]|\\.)*'", "''", text)
    text = re.sub(r'"([^"\\]|\\.)*"', '""', text)
    # Regex literals not perfect but let's just do brackets
    return text

depth = 0
for i, line in enumerate(lines):
    clean = strip_quotes_and_comments(line)
    for char in clean:
        if char == '{': depth += 1
        elif char == '}': depth -= 1
    if depth < 0:
        print(f"Depth became negative at line {i+1}: {line}")
        break

print(f"Final depth: {depth}")

if depth > 0:
    print("Tracing missing close braces backwards...")
    d = 0
    recent_starts = []
    for i in range(len(lines)-1, -1, -1):
        clean = strip_quotes_and_comments(lines[i])
        for char in reversed(clean):
            if char == '}': d += 1
            elif char == '{':
                d -= 1
                if d < 0:
                    recent_starts.append(i+1)
                    d = 0
    print("Possible unclosed { on lines:", recent_starts[:5])

