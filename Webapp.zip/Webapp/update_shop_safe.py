import os
import re
import sys

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Ensure getFlashSaleInfo exists
if "function getFlashSaleInfo(" not in content:
    helper = """function getFlashSaleInfo(itemId) {
  var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
  var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
  var fSales = [];
  if (myRewards.length > 0) {
    var a = myRewards.slice();
    var seed = epoch;
    for (var i = a.length - 1; i > 0; i--) {
      var x = Math.sin(seed++) * 10000;
      var rNum = x - Math.floor(x);
      var j = Math.floor(rNum * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    fSales = a.slice(0, 3);
  }
  var idx = fSales.findIndex(function(fs){ return fs.id === itemId; });
  if (idx === -1) return null;
  var fSeed = epoch + idx;
  var fx = Math.sin(fSeed) * 10000;
  return (fx - Math.floor(fx)) > 0.5 ? 0.10 : 0.05;
}
"""
    # Insert before renderShopItem to be safe
    content = re.sub(r'(function\s+renderShopItem\s*\()', helper + r'\n\1', content, count=1)

# 2. Update renderApp `tab === 'shop'`
new_shop_tab = """else if (tab === 'shop') {
    var hTop = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
    hTop += '<div style="font-size:1.6rem;font-weight:800;color:#1a1f36;font-family:\\'Playfair Display\\',serif">Shop</div>';
    hTop += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:6px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
    hTop += '</div>';
    page += hTop;

    var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
    var fSalesCount = 0;
    var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
    if (myRewards.length > 0) {
      fSalesCount = Math.min(3, myRewards.length);
    }

    if (fSalesCount > 0) {
      var hrsLeft = 5 - (Math.floor(Date.now() / 3600000) % 5);
      var hBanner = '<div style="background:#1a2a5e;border-radius:16px;padding:20px;display:flex;justify-content:space-between;align-items:center;margin-bottom:24px">';
      hBanner += '<div><div style="font-size:.7rem;font-weight:800;color:#8fa8d8;text-transform:uppercase;margin-bottom:4px">FLASH SALE ATTIVA</div>';
      hBanner += '<div style="font-size:1.05rem;font-weight:800;color:#ffffff;margin-bottom:4px">Sconti fino al -10%</div>';
      hBanner += '<div style="font-size:.7rem;color:#8fa8d8">Scade tra '+hrsLeft+'h — non perdere l\\'offerta</div></div>';
      hBanner += '<div style="background:#c04020;border-radius:12px;padding:8px 12px;text-align:center;min-width:70px">';
      hBanner += '<div style="font-size:.65rem;color:#ffd0c0;font-weight:800;text-transform:uppercase;margin-bottom:2px">SCADE TRA</div>';
      hBanner += '<div style="font-size:1.2rem;font-weight:800;color:#ffffff;line-height:1">'+hrsLeft+'h</div></div></div>';
      page += hBanner;
    }

    page += '<div style="font-size:.75rem;font-weight:800;color:#6b7080;text-transform:uppercase;margin-bottom:12px;letter-spacing:.05em">VETRINA PRODOTTI</div>';
    
    if (!myRws.length) {
      page += '<div class="empty"><span class="empty-ico">🛍️</span><p>Nessun prodotto in inventario.<br>Il fornitore li aggiungerà presto!</p></div>';
    } else {
      myRws.forEach(function(r) { page += renderShopItem(r, pts); });
      page += '<div style="text-align:center;font-size:.8rem;color:#b0b4c0;margin-top:24px;margin-bottom:20px">Hai visto tutti i prodotti disponibili</div>';
    }
  }"""

# Use regex to replace the shop tab safely
content = re.sub(r'else\s+if\s*\(\s*tab\s*===\s*[\'"]shop[\'"]\s*\)\s*\{.*?\}\s*else\s+if\s*\(\s*tab\s*===\s*[\'"]execute[\'"]', new_shop_tab + r'\n        else if (tab === \'execute\'', content, flags=re.DOTALL)

# 3. Update renderShopItem
new_item = """function renderShopItem(r, pts) {
  var dscPct = typeof getFlashSaleInfo === "function" ? getFlashSaleInfo(r.id) : null;
  var finalCost = dscPct ? Math.floor(r.cost * (1 - dscPct)) : r.cost;
  var canAfford = pts >= finalCost;
  
  var borderCol = dscPct ? '#f0c8be' : '#e2e8f0';
  var iconBg = dscPct ? '#fff0ec' : '#eef3fb';
  
  var h = '<div style="background:#ffffff;border:1px solid '+borderCol+';border-radius:16px;padding:16px;margin-bottom:12px;display:flex;gap:14px;align-items:center;position:relative">';
  if (dscPct) {
    h += '<div style="position:absolute;top:12px;right:12px;background:#c04020;color:#ffffff;font-size:.7rem;font-weight:800;padding:3px 8px;border-radius:8px">-'+(dscPct*100)+'%</div>';
  }
  h += '<div style="width:54px;height:54px;background:'+iconBg+';border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.8rem;flex-shrink:0">'+(r.emoji||'🛍️')+'</div>';
  h += '<div style="flex:1">';
  h += '<div style="font-size:1.05rem;font-weight:800;color:#1a1f36;margin-bottom:4px">'+esc(r.name)+'</div>';
  if (r.desc) h += '<div style="font-size:.75rem;color:#8a8f9e;line-height:1.4;margin-bottom:10px">'+esc(r.desc)+'</div>';
  
  h += '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px">';
  h += '<div style="display:flex;align-items:center;gap:6px">';
  h += '<div style="font-size:1.05rem;font-weight:900;color:#1a1f36"><span style="color:#378add">🔷</span> '+finalCost+' pt</div>';
  if (dscPct) {
    h += '<div style="font-size:.7rem;color:#b0b4c0;text-decoration:line-through">'+r.cost+'</div>';
  }
  h += '</div>';
  
  if (canAfford) {
    h += '<button style="background:#1a2a5e;color:#ffffff;border:none;padding:8px 16px;border-radius:10px;font-size:.8rem;font-weight:700;cursor:pointer" data-action="open-claim" data-arg="'+esc(r.id)+'" '+(dscPct?'data-arg2="'+finalCost+'"':'')+'>Acquista</button>';
  } else {
    h += '<button style="background:#f0f2f8;color:#a0a8be;border:none;padding:8px 16px;border-radius:10px;font-size:.8rem;font-weight:700;cursor:not-allowed" disabled>Fondi errati</button>';
  }
  h += '</div>';
  h += '</div>';
  h += '</div>';
  return h;
}"""

content = re.sub(r'function\s+renderShopItem\s*\([^)]*\)\s*\{.*?\n\s*\}\s*(?=\n\s*function|\n\s*window|\Z|\n\s*var|\n\s*let|\n\s*const|\n\s*//)', new_item + '\n', content, flags=re.DOTALL)

# 4. Hide original topbar for shop and apply cssMod block display
content = re.sub(r'if\s*\(\s*tab\s*!==\s*[\'"]home[\'"]\s*\)\s*\{', r'if (tab !== \'home\' && tab !== \'shop\') {', content)
content = re.sub(r'(h\s*\+=\s*[\'"]<div\s+class=[\'"]page[\'"]\'\s*\+\s*\(tab\s*===\s*[\'"]home[\'"]\s*\?\s*[\'"]\s*home-page[\'"]\s*:\s*[\'"][\'"]\)\s*\+\s*[\'"][\'"]\s*[\'"]\s*\+\s*\(tab\s*===\s*[\'"]home[\'"]\s*\?\s*[\'"]style=[\'"]padding-top:0;?display:block[\'"][\'"]\s*:\s*[\'"][\'"]\)\s*\+\s*[\'"]>[\'"]\s*\+\s*page\s*\+\s*[\'"]</div>[\'"];)', r'var cssMod = (tab===\'home\' || tab===\'shop\') ? \'style="padding-top:0;display:block"\' : \'\';\n  h += \'<div class="page\'+((tab===\'home\' || tab===\'shop\')?\' home-page\':\'\')+\'" \'+cssMod+\'>\'+page+\'</div>\';', content)

# 5. Fix possible fallback
content = re.sub(r'(h\s*\+=\s*[\'"]<div\s+class=[\'"]page[\'"]\'\s*\+\s*\(tab\s*===\s*[\'"]home[\'"]\s*\?\s*[\'"]\s*home-page[\'"]\s*:\s*[\'"][\'"]\)\s*\+\s*[\'"][\'"]\s*[\'"]\s*\+\s*\(tab\s*===\s*[\'"]home[\'"]\s*\?\s*[\'"]style=[\'"]padding-top:0[\'"][\'"]\s*:\s*[\'"][\'"]\)\s*\+\s*[\'"]>[\'"]\s*\+\s*page\s*\+\s*[\'"]</div>[\'"];)', r'var cssMod = (tab===\'home\' || tab===\'shop\') ? \'style="padding-top:0;display:block"\' : \'\';\n  h += \'<div class="page\'+((tab===\'home\' || tab===\'shop\')?\' home-page\':\'\')+\'" \'+cssMod+\'>\'+page+\'</div>\';', content)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Finished safe regex update")
