(function () {
      'use strict';

      /* ── GLOBAL EVENT DELEGATION ── */
      document.addEventListener('click', function (e) {
        var el = e.target;
        // Walk up to find a [data-action] element
        while (el && el !== document) {
          var action = el.getAttribute('data-action');
          if (action) { handleAction(action, el, e); return; }
          el = el.parentElement;
        }
      });

      function handleAction(action, el, e) {
        var arg = el.getAttribute('data-arg') || '';
        var arg2 = el.getAttribute('data-arg2') || '';
        switch (action) {
          case 'pick-user': selU = arg; render(); break;
          case 'go-admin': session = 'admin'; render(); break;
          case 'do-login': doLogin(); break;
          case 'do-adm-login': doAdmLogin(); break;
          case 'logout': if (session && session !== 'admin') db.ref('sc_presence/' + session).remove(); clearSession(); session = null; quizSess = null; render(); break;
          case 'adm-logout': session = null; adminAuthed = false; sessionStorage.removeItem('adm_ok'); render(); break;
          case 'set-tab': tab = arg; render(); break;
          case 'set-subtab': window.executeSubTab = arg; render(); break;
          case 'set-adm-tab': adminTab = arg; render(); break;
          case 'toggle-history': showHistory = !showHistory; render(); break;

          case 'open-claim': openClaim(arg, arg2); break;
          case 'set-mode': claimMode = arg; render(); break;
          case 'close-overlay': if (e.target === el) { overlay = null; render(); } break;
          case 'cancel-overlay': overlay = null; render(); break;
          case 'prepare-claim': prepareClaim(); break;
          case 'finalize-claim': finalizeClaim(); break;
          case 'close-success': overlay = null; render(); break;
          case 'mark-done': markDone(arg); break;
          case 'confirm-done': confirmDone(arg, arg2 === 'yes'); break;
          case 'declare-unfulfilled': declareUnfulfilled(arg); break;
          case 'report-late': reportLate(arg); break;
          case 'view-order': overlay = { type: 'order_detail', id: arg, isExec: arg2 === '1' }; render(); break;
          case 'open-activity': overlay = { type: 'activity' }; render(); break;
          case 'fq-claim': overlay = null; tab = 'shop'; render(); break;
          case 'fq-skip-claim': overlay = null; render(); break;
          case 'toggle-acc': toggleAcc(+arg, el); break;
          case 'ob-next': obStep++; render(); break;
          case 'ob-back': obStep--; render(); break;
          case 'ob-close': showOB = false; render(); break;
          case 'add-q': addQ(); break;
          case 'del-q': delQ(arg); break;
          case 'add-r': addR(); break;
          case 'del-r': delR(arg); break;
          case 'adj-pts': adjPts(arg, +arg2); break;
          case 'do-reset': doReset(); break;
          case 'copy-topic': copyToClipboard(arg); break;
          case 'fq-answer': answerFlashQ(+arg); break;
          case 'fq-dismiss': dismissFlashQ(); break;
          case 'fq-claim': flashQ = null; miniGame = null; tab = 'shop'; render(); break;
          case 'fq-skip-claim': flashQ = null; miniGame = null; render(); break;
          case 'mg-dismiss': dismissMiniGame(); break;
          case 'mg-wheel-spin': doWheelSpin(); break;
          case 'mg-scratch': doScratchReveal(+arg); break;
          case 'mg-scratch-finish': doScratchFinish(arg === '1'); break;
          case 'mg-slots-spin': doSlotsSpin(); break;
          case 'mg-dice-roll': doDiceRoll(); break;
        }
      }

      /* ── MINI-GAME INTERACTIONS ── */
      function doWheelSpin() {
        if (!miniGame || miniGame.played || miniGame.gameState.spinning) return;
        var gs = miniGame.gameState;
        gs.spinning = true;
        var segments = [10, 50, 0, 100, 25, 250, 75, 150];
        var prize = calcWeightedPrize(250);
        // Find closest segment
        var segAngle = 360 / segments.length;
        var closestIdx = 0, closestDiff = 999;
        segments.forEach(function (v, i) {
          if (Math.abs(v - prize) < closestDiff) { closestDiff = Math.abs(v - prize); closestIdx = i; }
        });
        prize = segments[closestIdx]; // snap to actual segment value
        // Calculate target angle: spin several full rotations + land on segment
        var targetSegAngle = 360 - (closestIdx * segAngle + segAngle / 2);
        var totalAngle = 360 * (5 + Math.floor(Math.random() * 3)) + targetSegAngle;
        gs.angle = totalAngle;
        render();
        setTimeout(function () {
          gs.spinning = false;
          finishMiniGame(prize);
        }, 3200);
      }

      function doScratchReveal(idx) {
        if (!miniGame || miniGame.played) return;
        var gs = miniGame.gameState;
        if (gs.done || gs.cells[idx].revealed) return;
        gs.cells[idx].revealed = true;
        gs.reveals++;
        if (gs.reveals >= gs.maxReveals) gs.done = true;
        // Check for early win: 3 matching revealed symbols
        var counts = {};
        gs.cells.forEach(function (c) { if (c.revealed) { counts[c.symbol] = (counts[c.symbol] || 0) + 1; } });
        var earlyWin = false;
        Object.keys(counts).forEach(function (k) { if (counts[k] >= 3) earlyWin = true; });
        if (earlyWin) gs.done = true;
        render();
      }

      function doScratchFinish(won) {
        if (!miniGame || miniGame.played) return;
        var prize = won ? calcWeightedPrize(250) : 0;
        if (won && prize === 0) prize = 20; // minimum win if matched
        // Reveal all
        miniGame.gameState.cells.forEach(function (c) { c.revealed = true; });
        finishMiniGame(prize);
      }

      function doSlotsSpin() {
        if (!miniGame || miniGame.played || miniGame.gameState.spinning) return;
        var gs = miniGame.gameState;
        gs.spinning = true;
        render();
        // Animate reel changes
        var ticks = 0, maxTicks = 20;
        var interval = setInterval(function () {
          ticks++;
          for (var i = 0; i < 3; i++) {
            if (ticks < maxTicks - i * 3) {
              gs.reels[i] = gs.emojis[Math.floor(Math.random() * gs.emojis.length)];
            }
          }
          // Update reels display directly for animation
          for (var j = 0; j < 3; j++) {
            var rel = document.getElementById('reel-' + j);
            if (rel) rel.textContent = gs.reels[j];
          }
          if (ticks >= maxTicks) {
            clearInterval(interval);
            gs.spinning = false;
            // Determine prize based on matches
            var prize = 0;
            if (gs.reels[0] === gs.reels[1] && gs.reels[1] === gs.reels[2]) {
              prize = 250; // jackpot
            } else if (gs.reels[0] === gs.reels[1] || gs.reels[1] === gs.reels[2] || gs.reels[0] === gs.reels[2]) {
              prize = calcWeightedPrize(120);
              if (prize === 0) prize = 30;
            }
            // 40% chance of random small win even with no matches
            if (prize === 0 && Math.random() < 0.4) {
              prize = Math.floor(Math.random() * 40) + 10;
            }
            finishMiniGame(prize);
          }
        }, 100);
      }

      function doDiceRoll() {
        if (!miniGame || miniGame.played || miniGame.gameState.rolling) return;
        var gs = miniGame.gameState;
        gs.rolling = true;
        render();
        var ticks = 0;
        var interval = setInterval(function () {
          ticks++;
          gs.d1 = Math.floor(Math.random() * 6) + 1;
          gs.d2 = Math.floor(Math.random() * 6) + 1;
          // Update dice display directly
          var diceEmojis = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
          var diceEls = document.querySelectorAll('.dice');
          if (diceEls[0]) diceEls[0].textContent = diceEmojis[gs.d1];
          if (diceEls[1]) diceEls[1].textContent = diceEmojis[gs.d2];
          if (ticks >= 15) {
            clearInterval(interval);
            gs.rolling = false;
            var sum = gs.d1 + gs.d2;
            var prize = sum * 20; // 2-12 × 20 = 40-240 pt
            finishMiniGame(prize);
          }
        }, 100);
      }

      /* ── FIREBASE SETUP ── */
      var firebaseConfig = {
        apiKey: "AIzaSyB9iufetY1k5ScWdI5fiOPNK567kPNw6ug",
        authDomain: "secretchallenge-7aabf.firebaseapp.com",
        databaseURL: "https://secretchallenge-7aabf-default-rtdb.europe-west1.firebasedatabase.app",
        projectId: "secretchallenge-7aabf",
        storageBucket: "secretchallenge-7aabf.firebasestorage.app",
        messagingSenderId: "877944784958",
        appId: "1:877944784958:web:f62468f13fa5a23365696f"
      };
      firebase.initializeApp(firebaseConfig);
      var db = firebase.database();
      var DB_REF = 'sc_app';

      /* ── DATA ── */
      function freshUser() { return { pwd: '', pwdSet: false, pts: 1000, quizToday: null, lastRewardClaim: null, penaltyChecked: null }; }
      var BLANK = { users: { giulia: freshUser(), stefano: freshUser() }, questions: [], rewards: [], requests: [] };

      /* ── EMBEDDED QUESTION BANK (from CSV) ── */
      var QUESTION_BANK = [{ "id": "1", "text": "Qual è la capitale d'Italia?", "opts": ["Roma", "Milano", "Napoli", "Torino"], "correct": 0, "diff": 1, "ambito": "Geografia" }, { "id": "2", "text": "Qual è la capitale della Francia?", "opts": ["Parigi", "Lione", "Marsiglia", "Nizza"], "correct": 0, "diff": 1, "ambito": "Geografia" }, { "id": "3", "text": "Qual è il pianeta più vicino al Sole?", "opts": ["Venere", "Mercurio", "Marte", "Giove"], "correct": 1, "diff": 1, "ambito": "Scienza" }, { "id": "4", "text": "Chi ha scritto \"Romeo e Giulietta\"?", "opts": ["Dante", "Shakespeare", "Boccaccio", "Manzoni"], "correct": 1, "diff": 2, "ambito": "Letteratura" }, { "id": "5", "text": "Quanto fa 2+2?", "opts": ["3", "4", "5", "6"], "correct": 1, "diff": 1, "ambito": "Matematica" }, { "id": "6", "text": "Qual è il colore del cielo sereno?", "opts": ["Blu", "Verde", "Rosso", "Giallo"], "correct": 0, "diff": 1, "ambito": "Scienza" }, { "id": "7", "text": "Chi era il primo presidente USA?", "opts": ["Lincoln", "Washington", "Jefferson", "Adams"], "correct": 1, "diff": 2, "ambito": "Storia" }, { "id": "8", "text": "Qual è l’oceano più grande?", "opts": ["Atlantico", "Indiano", "Pacifico", "Artico"], "correct": 2, "diff": 2, "ambito": "Geografia" }, { "id": "9", "text": "Quanti giorni ha una settimana?", "opts": ["5", "6", "7", "8"], "correct": 2, "diff": 1, "ambito": "Varie" }, { "id": "10", "text": "Simbolo chimico dell’acqua?", "opts": ["H2O", "O2", "CO2", "NaCl"], "correct": 0, "diff": 1, "ambito": "Scienza" }, { "id": "11", "text": "Chi ha dipinto la Gioconda?", "opts": ["Van Gogh", "Leonardo", "Picasso", "Raffaello"], "correct": 1, "diff": 2, "ambito": "Arte" }, { "id": "12", "text": "Quanto fa 10x10?", "opts": ["50", "100", "10", "20"], "correct": 1, "diff": 1, "ambito": "Matematica" }, { "id": "13", "text": "Chi ha scoperto l’America?", "opts": ["Colombo", "Magellano", "Cook", "Vespucci"], "correct": 0, "diff": 2, "ambito": "Storia" }, { "id": "14", "text": "Continente più grande?", "opts": ["Africa", "Asia", "Europa", "America"], "correct": 1, "diff": 2, "ambito": "Geografia" }, { "id": "15", "text": "Numero lati triangolo?", "opts": ["2", "3", "4", "5"], "correct": 1, "diff": 1, "ambito": "Matematica" }, { "id": "16", "text": "Chi ha teorizzato la relatività?", "opts": ["Newton", "Einstein", "Galileo", "Bohr"], "correct": 1, "diff": 4, "ambito": "Scienza" }, { "id": "17", "text": "Capitale Germania?", "opts": ["Berlino", "Monaco", "Amburgo", "Colonia"], "correct": 0, "diff": 2, "ambito": "Geografia" }, { "id": "18", "text": "Pianeta più grande?", "opts": ["Saturno", "Terra", "Giove", "Urano"], "correct": 2, "diff": 2, "ambito": "Scienza" }, { "id": "19", "text": "Radice quadrata di 16?", "opts": ["2", "4", "6", "8"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "20", "text": "Gas principale atmosfera?", "opts": ["Ossigeno", "Azoto", "CO2", "Idrogeno"], "correct": 1, "diff": 3, "ambito": "Scienza" }, { "id": "21", "text": "Capitale Spagna?", "opts": ["Madrid", "Barcellona", "Valencia", "Siviglia"], "correct": 0, "diff": 2, "ambito": "Geografia" }, { "id": "22", "text": "Simbolo oro?", "opts": ["Ag", "Au", "Fe", "O"], "correct": 1, "diff": 3, "ambito": "Scienza" }, { "id": "23", "text": "Autore \"I Promessi Sposi\"?", "opts": ["Manzoni", "Dante", "Pirandello", "Leopardi"], "correct": 0, "diff": 2, "ambito": "Letteratura" }, { "id": "24", "text": "5x6=?", "opts": ["11", "30", "25", "20"], "correct": 1, "diff": 1, "ambito": "Matematica" }, { "id": "25", "text": "Paese più popoloso?", "opts": ["India", "Cina", "USA", "Indonesia"], "correct": 1, "diff": 3, "ambito": "Geografia" }, { "id": "26", "text": "Chi era Galileo?", "opts": ["Artista", "Scienziato", "Re", "Poeta"], "correct": 1, "diff": 3, "ambito": "Scienza" }, { "id": "27", "text": "Capitale Cina?", "opts": ["Pechino", "Shanghai", "Hong Kong", "Nanchino"], "correct": 0, "diff": 2, "ambito": "Geografia" }, { "id": "28", "text": "Pianeta con anelli?", "opts": ["Marte", "Giove", "Saturno", "Venere"], "correct": 2, "diff": 2, "ambito": "Scienza" }, { "id": "29", "text": "12/3=?", "opts": ["2", "3", "4", "5"], "correct": 2, "diff": 1, "ambito": "Matematica" }, { "id": "30", "text": "Vulcano famoso Italia?", "opts": ["Etna", "Vesuvio", "Stromboli", "Fuji"], "correct": 1, "diff": 2, "ambito": "Geografia" }, { "id": "31", "text": "Teoria evoluzione?", "opts": ["Darwin", "Newton", "Einstein", "Curie"], "correct": 0, "diff": 4, "ambito": "Scienza" }, { "id": "32", "text": "Capitale Russia?", "opts": ["Mosca", "San Pietroburgo", "Kiev", "Minsk"], "correct": 0, "diff": 2, "ambito": "Geografia" }, { "id": "33", "text": "Numero pianeti sistema solare?", "opts": ["7", "8", "9", "10"], "correct": 1, "diff": 3, "ambito": "Scienza" }, { "id": "34", "text": "7x8=?", "opts": ["54", "56", "58", "60"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "35", "text": "Capitale India?", "opts": ["Delhi", "Mumbai", "Kolkata", "Chennai"], "correct": 0, "diff": 3, "ambito": "Geografia" }, { "id": "36", "text": "Gas che respiriamo?", "opts": ["Ossigeno", "Azoto", "CO2", "Elio"], "correct": 0, "diff": 1, "ambito": "Scienza" }, { "id": "37", "text": "100-45=?", "opts": ["45", "55", "65", "35"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "38", "text": "Capitale Messico?", "opts": ["Monterrey", "Cancun", "Città del Messico", "Guadalajara"], "correct": 2, "diff": 3, "ambito": "Geografia" }, { "id": "39", "text": "Simbolo sodio?", "opts": ["So", "Na", "Sn", "Sd"], "correct": 1, "diff": 4, "ambito": "Scienza" }, { "id": "40", "text": "6^2=?", "opts": ["12", "18", "36", "24"], "correct": 2, "diff": 3, "ambito": "Matematica" }, { "id": "41", "text": "Capitale Egitto?", "opts": ["Il Cairo", "Alessandria", "Giza", "Luxor"], "correct": 0, "diff": 3, "ambito": "Geografia" }, { "id": "42", "text": "Nome galassia?", "opts": ["Andromeda", "Via Lattea", "Orione", "Centauro"], "correct": 1, "diff": 3, "ambito": "Scienza" }, { "id": "43", "text": "50/5=?", "opts": ["5", "10", "15", "20"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "44", "text": "Capitale Grecia?", "opts": ["Atene", "Sparta", "Salonicco", "Creta"], "correct": 0, "diff": 3, "ambito": "Geografia" }, { "id": "45", "text": "Scoperta gravità?", "opts": ["Newton", "Einstein", "Galileo", "Tesla"], "correct": 0, "diff": 3, "ambito": "Scienza" }, { "id": "46", "text": "3x9=?", "opts": ["18", "21", "27", "24"], "correct": 2, "diff": 1, "ambito": "Matematica" }, { "id": "47", "text": "144/12=?", "opts": ["10", "11", "12", "13"], "correct": 2, "diff": 2, "ambito": "Matematica" }, { "id": "48", "text": "11x11=?", "opts": ["111", "121", "131", "141"], "correct": 1, "diff": 3, "ambito": "Matematica" }, { "id": "49", "text": "81/9=?", "opts": ["7", "8", "9", "10"], "correct": 2, "diff": 2, "ambito": "Matematica" }, { "id": "50", "text": "8^2=?", "opts": ["16", "32", "64", "48"], "correct": 2, "diff": 3, "ambito": "Matematica" }, { "id": "51", "text": "20x5=?", "opts": ["50", "75", "100", "120"], "correct": 2, "diff": 2, "ambito": "Matematica" }, { "id": "52", "text": "18+27=?", "opts": ["35", "45", "55", "40"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "53", "text": "100/4=?", "opts": ["20", "25", "30", "35"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "54", "text": "14x3=?", "opts": ["42", "36", "48", "40"], "correct": 0, "diff": 2, "ambito": "Matematica" }, { "id": "55", "text": "60/3=?", "opts": ["15", "20", "25", "30"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "56", "text": "13+19=?", "opts": ["30", "31", "32", "33"], "correct": 2, "diff": 2, "ambito": "Matematica" }, { "id": "57", "text": "25x4=?", "opts": ["80", "90", "100", "110"], "correct": 2, "diff": 2, "ambito": "Matematica" }, { "id": "58", "text": "90/10=?", "opts": ["8", "9", "10", "11"], "correct": 1, "diff": 2, "ambito": "Matematica" }, { "id": "59", "text": "7^3=?", "opts": ["343", "49", "21", "512"], "correct": 0, "diff": 4, "ambito": "Matematica" }, { "id": "60", "text": "121/11=?", "opts": ["9", "10", "11", "12"], "correct": 2, "diff": 3, "ambito": "Matematica" }, { "id": "61", "text": "19+23=?", "opts": ["40", "41", "42", "43"], "correct": 2, "diff": 2, "ambito": "Matematica" }, { "id": "62", "text": "200/5=?", "opts": ["20", "30", "40", "50"], "correct": 2, "diff": 3, "ambito": "Matematica" }, { "id": "63", "text": "15x7=?", "opts": ["95", "100", "105", "110"], "correct": 2, "diff": 3, "ambito": "Matematica" }, { "id": "64", "text": "256/16=?", "opts": ["14", "15", "16", "18"], "correct": 2, "diff": 3, "ambito": "Matematica" }, { "id": "65", "text": "3^4=?", "opts": ["27", "64", "81", "12"], "correct": 2, "diff": 4, "ambito": "Matematica" }, { "id": "66", "text": "Chi ha scritto \"1984\"?", "opts": ["Orwell", "Huxley", "Tolkien", "Rowling"], "correct": 0, "diff": 3, "ambito": "Letteratura" }, { "id": "67", "text": "Autore \"Divina Commedia\"?", "opts": ["Dante", "Petrarca", "Boccaccio", "Leopardi"], "correct": 0, "diff": 2, "ambito": "Letteratura" }, { "id": "68", "text": "Autore \"Odissea\"?", "opts": ["Omero", "Virgilio", "Ovidio", "Platone"], "correct": 0, "diff": 3, "ambito": "Letteratura" }, { "id": "69", "text": "Autore \"Don Chisciotte\"?", "opts": ["Cervantes", "Borges", "Neruda", "Allende"], "correct": 0, "diff": 4, "ambito": "Letteratura" }, { "id": "70", "text": "Autore \"Guerra e Pace\"?", "opts": ["Tolstoj", "Dostoevskij", "Pushkin", "Gogol"], "correct": 0, "diff": 5, "ambito": "Letteratura" }, { "id": "71", "text": "Autore \"Moby Dick\"?", "opts": ["Melville", "Twain", "Hemingway", "Fitzgerald"], "correct": 0, "diff": 5, "ambito": "Letteratura" }, { "id": "72", "text": "Autore \"Dracula\"?", "opts": ["Stoker", "Shelley", "Poe", "Wilde"], "correct": 0, "diff": 5, "ambito": "Letteratura" }, { "id": "73", "text": "Autore \"Frankenstein\"?", "opts": ["Shelley", "Austen", "Brontë", "Stoker"], "correct": 0, "diff": 5, "ambito": "Letteratura" }, { "id": "74", "text": "Autore \"Ulisse\"?", "opts": ["Joyce", "Beckett", "Eliot", "Yeats"], "correct": 0, "diff": 6, "ambito": "Letteratura" }, { "id": "75", "text": "Autore \"Il Processo\"?", "opts": ["Kafka", "Goethe", "Mann", "Hesse"], "correct": 0, "diff": 6, "ambito": "Letteratura" }, { "id": "76", "text": "Autore \"Lolita\"?", "opts": ["Nabokov", "Bulgakov", "Pasternak", "Solzenicyn"], "correct": 0, "diff": 6, "ambito": "Letteratura" }, { "id": "77", "text": "Autore \"Il Gattopardo\"?", "opts": ["Tomasi di Lampedusa", "Calvino", "Eco", "Pavese"], "correct": 0, "diff": 5, "ambito": "Letteratura" }, { "id": "78", "text": "Autore \"Se questo è un uomo\"?", "opts": ["Levi", "Sciascia", "Fenoglio", "Moravia"], "correct": 0, "diff": 5, "ambito": "Letteratura" }, { "id": "79", "text": "Autore \"La coscienza di Zeno\"?", "opts": ["Svevo", "Pirandello", "Verga", "Deledda"], "correct": 0, "diff": 5, "ambito": "Letteratura" }, { "id": "80", "text": "Autore \"Madame Bovary\"?", "opts": ["Flaubert", "Balzac", "Zola", "Hugo"], "correct": 0, "diff": 6, "ambito": "Letteratura" }, { "id": "81", "text": "Autore \"Dorian Gray\"?", "opts": ["Wilde", "Shaw", "Dickens", "Austen"], "correct": 0, "diff": 6, "ambito": "Letteratura" }, { "id": "82", "text": "Autore \"Il deserto dei Tartari\"?", "opts": ["Buzzati", "Calvino", "Primo Levi", "Saba"], "correct": 0, "diff": 6, "ambito": "Letteratura" }, { "id": "83", "text": "Autore \"La nausea\"?", "opts": ["Sartre", "Camus", "Beauvoir", "Merleau-Ponty"], "correct": 0, "diff": 7, "ambito": "Letteratura" }, { "id": "84", "text": "Autore \"Cent’anni di solitudine\"?", "opts": ["Marquez", "Borges", "Cortazar", "Neruda"], "correct": 0, "diff": 6, "ambito": "Letteratura" }, { "id": "85", "text": "Autore \"Orgoglio e pregiudizio\"?", "opts": ["Austen", "Brontë", "Eliot", "Alcott"], "correct": 0, "diff": 5, "ambito": "Letteratura" }];

      /* Select 10 questions balanced by difficulty.
         Strategy: divide bank into LOW (1-3), MED (4-6), HIGH (7-10),
         pick ~4 LOW + 4 MED + 2 HIGH (adjusting if a bucket is small),
         then shuffle the final 10. */
      function selectDailyQuestions() {
        var low = QUESTION_BANK.filter(function (q) { return q.diff <= 3; });
        var med = QUESTION_BANK.filter(function (q) { return q.diff >= 4 && q.diff <= 6; });
        var high = QUESTION_BANK.filter(function (q) { return q.diff >= 7; });

        function pick(arr, n) {
          var shuffled = arr.slice().sort(function () { return Math.random() - 0.5; });
          return shuffled.slice(0, Math.min(n, shuffled.length));
        }

        // Targets: 4 low, 4 med, 2 high — fill gaps from other buckets
        var targets = [4, 4, 2];
        var buckets = [low, med, high];
        var chosen = [];
        var remaining = 10;

        for (var i = 0; i < 3; i++) {
          var got = pick(buckets[i], targets[i]);
          chosen = chosen.concat(got);
          remaining -= got.length;
        }

        // If we still need more (e.g. high bucket small), fill from any remaining
        if (remaining > 0) {
          var usedIds = {};
          chosen.forEach(function (q) { usedIds[q.id] = true; });
          var leftover = QUESTION_BANK.filter(function (q) { return !usedIds[q.id]; });
          leftover.sort(function () { return Math.random() - 0.5; });
          chosen = chosen.concat(leftover.slice(0, remaining));
        }

        // Final shuffle
        chosen.sort(function () { return Math.random() - 0.5; });
        return chosen.slice(0, 10);
      }
      function clone(o) { return JSON.parse(JSON.stringify(o)); }

      /* ── STATE ── */
      var S = clone(BLANK);
      var fbReady = false; // true once first Firebase snapshot received
      var session = null, tab = 'home', overlay = null;
      var toast = null, toastT = null;
      var adminAuthed = sessionStorage.getItem('adm_ok') === '1';
      var adminTab = 'quiz', adminUser = '', adminPwd = '';
      var selU = null, showOB = false, obStep = 0;
      var quizSess = null; // kept for compatibility, unused
      var claimMode = 'deadline';
      var expandedInfo = {};
      var onlineUsers = {};
      var showHistory = false;

      /* ── FLASH QUESTION STATE ── */
      var flashQ = null;
      /* flashQ shape: {
           q: {question object},
           slotKey: 'YYYY-M-D-H' (hour slot),
           answered: false,
           ansIdx: null,
           showNudge: false,   // show reward nudge after answer
           timerLeft: 3600     // seconds remaining in this hour
         } */
      var flashTimer = null;

      /* ── FIREBASE SAVE / SYNC ── */
      /* Write guard: suppress self-triggered Firebase echoes */
      var _writing = false;
      var _writeTimer = null;

      function save(s) {
        var payload = {
          users: s.users,
          questions: arrToObj(s.questions),
          rewards: arrToObj(s.rewards),
          requests: arrToObj(s.requests)
        };
        _writing = true;
        if (_writeTimer) clearTimeout(_writeTimer);
        _writeTimer = setTimeout(function () { _writing = false; }, 3000);
        db.ref(DB_REF).set(payload);
      }

      /* Returns true if user is focused on an input field */
      function userIsTyping() {
        var el = document.activeElement;
        if (!el) return false;
        var t = el.tagName;
        return t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT';
      }

      /* Debounced remote render — waits until safe to update */
      var _remoteTimer = null;
      function scheduleRemoteRender() {
        if (_remoteTimer) clearTimeout(_remoteTimer);
        _remoteTimer = setTimeout(function () {
          if (!overlay && !userIsTyping()) {
            render();
          } else {
            scheduleRemoteRender(); // retry in 1.5s
          }
        }, 1500);
      }

      function arrToObj(arr) {
        if (!arr || !arr.length) return {};
        var obj = {};
        arr.forEach(function (item) { if (item && item.id) obj[item.id] = item; });
        return obj;
      }

      function objToArr(obj) {
        if (!obj) return [];
        return Object.values(obj);
      }

      /* ── PRESENCE (online users) ── */
      function announcePresence() {
        if (!session || session === 'admin') return;
        var presRef = db.ref('sc_presence/' + session);
        presRef.set({ online: true, t: Date.now() });
        presRef.onDisconnect().remove();
      }

      /* ── HELPERS ── */
      function todayKey() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
      function daysAgo(iso) { if (!iso) return 0; return Math.round((Date.now() - new Date(iso)) / 86400000); }
      function fmtDt(s) { if (!s) return ''; try { return new Date(s).toLocaleString('it-IT', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); } catch (e) { return s; } }
      function fmtTime(s) { if (!s) return ''; try { return new Date(s).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }); } catch (e) { return s; } }

      /* ── NTFY NOTIFICATIONS ── */
      var APP_URL = 'https://speed07top-art.github.io/-secret-challenge/';
      var SESSION_KEY = 'sc_session_v1'; // {user, expires}
      var SESSION_HOURS = 48;

      function saveSession(user) {
        var expires = Date.now() + SESSION_HOURS * 3600 * 1000;
        try { localStorage.setItem(SESSION_KEY, JSON.stringify({ user: user, expires: expires })); } catch (e) { }
      }

      function loadSession() {
        try {
          var raw = localStorage.getItem(SESSION_KEY);
          if (!raw) return null;
          var s = JSON.parse(raw);
          if (!s || !s.user || !s.expires) return null;
          if (Date.now() > s.expires) { localStorage.removeItem(SESSION_KEY); return null; }
          return s.user;
        } catch (e) { return null; }
      }

      function clearSession() {
        try { localStorage.removeItem(SESSION_KEY); } catch (e) { }
      }
      var NTFY_BASE = 'https://ntfy.sh/';

      function genTopic(user) {
        var rand = Math.random().toString(36).slice(2, 10);
        return 'secretchallenge-' + user + '-' + rand;
      }

      function ensureTopic(user) {
        if (!S.users[user].ntfyTopic) {
          S.users[user].ntfyTopic = genTopic(user);
          save(S);
        }
        return S.users[user].ntfyTopic;
      }

      function ntfySend(topic, title, message, tags) {
        if (!topic) return;
        var payload = { topic: topic, title: title, message: message, click: APP_URL };
        if (tags) payload.tags = tags;
        fetch(NTFY_BASE, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }).catch(function (e) { console.warn('ntfy error:', e); });
      }

      function notifyPartnerNewReward(rewardName, deadline) {
        var pt = session === 'giulia' ? 'stefano' : 'giulia';
        var topic = S.users[pt] && S.users[pt].ntfyTopic;
        if (!topic) return;
        var myName = session === 'giulia' ? '🌸 Giulia' : '⚡ Stefano';
        var msg = myName + ' ha effettuato un nuovo ordine: ' + rewardName;
        if (deadline) msg += '\nConsegna entro: ' + fmtDt(deadline);
        ntfySend(topic, '📦 Nuovo ordine ricevuto!', msg, ['package']);
      }

      /* ── ACTIVITY ENGINE (Flash Questions + Mini-Games) ── */

      var ALL_ACTIVITY_HOURS = [15, 16, 17, 18, 19, 20, 21];
      var QUIZ_HOURS = [15, 18, 20]; // hours with flash questions
      var GAME_SCHEDULE = {
        16: { type: 'wheel', icon: '🎰', name: 'Gira la Ruota' },
        17: { type: 'scratch', icon: '🎫', name: 'Gratta e Vinci' },
        19: { type: 'slots', icon: '🎰', name: 'Slot Machine' },
        21: { type: 'dice', icon: '🎲', name: 'Dado Fortunato' }
      };
      var GAME_HOURS = [16, 17, 19, 21];

      function flashSlotKey() {
        var d = new Date();
        return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate() + '-' + d.getHours();
      }

      function isActivityHour() {
        var h = new Date().getHours();
        return ALL_ACTIVITY_HOURS.indexOf(h) >= 0;
      }
      function isQuizHour() {
        return QUIZ_HOURS.indexOf(new Date().getHours()) >= 0;
      }
      function isGameHour() {
        return GAME_HOURS.indexOf(new Date().getHours()) >= 0;
      }
      function currentGameType() {
        var h = new Date().getHours();
        return GAME_SCHEDULE[h] || null;
      }

      function secondsUntilNextHour() {
        var now = new Date();
        return 3600 - now.getMinutes() * 60 - now.getSeconds();
      }

      function pickFlashQuestion() {
        if (!QUESTION_BANK || !QUESTION_BANK.length) return null;
        // Pick a random question, prefer ones not seen today
        var today = todayKey();
        var seenKey = 'fq_seen_' + today;
        var seen = [];
        try { seen = JSON.parse(sessionStorage.getItem(seenKey) || '[]'); } catch (e) { }
        var pool = QUESTION_BANK.filter(function (q) { return seen.indexOf(q.id) < 0; });
        if (!pool.length) pool = QUESTION_BANK; // all seen — reset
        return pool[Math.floor(Math.random() * pool.length)];
      }

      function markFlashQuestionSeen(qid) {
        var today = todayKey();
        var seenKey = 'fq_seen_' + today;
        var seen = [];
        try { seen = JSON.parse(sessionStorage.getItem(seenKey) || '[]'); } catch (e) { }
        if (seen.indexOf(qid) < 0) seen.push(qid);
        try { sessionStorage.setItem(seenKey, JSON.stringify(seen)); } catch (e) { }
      }

      /* ── MINI-GAME STATE ── */
      var miniGame = null;
      /* miniGame shape: {
           type: 'wheel'|'scratch'|'slots'|'dice',
           slotKey: string,
           played: false,
           prize: 0,
           gameState: {} // type-specific state
         } */

      function checkFlashQuestion() {
        if (!session || session === 'admin') return;
        if (!isActivityHour()) { flashQ = null; miniGame = null; return; }

        var slotKey = flashSlotKey();
        var doneKey = 'fq_done_' + session + '_' + slotKey;

        // Already answered or dismissed this hour slot
        if (localStorage.getItem(doneKey)) return;
        // Already active
        if (flashQ && flashQ.slotKey === slotKey) return;
        if (miniGame && miniGame.slotKey === slotKey) return;

        if (isQuizHour()) {
          // Flash question
          var q = pickFlashQuestion();
          if (!q) return;

          flashQ = {
            q: q,
            slotKey: slotKey,
            answered: false,
            ansIdx: null,
            showNudge: false,
            timerLeft: secondsUntilNextHour()
          };

          // Start countdown timer
          if (flashTimer) clearInterval(flashTimer);
          flashTimer = setInterval(function () {
            if (!flashQ) { clearInterval(flashTimer); return; }
            flashQ.timerLeft--;
            if (flashQ.timerLeft <= 0) {
              clearInterval(flashTimer);
              localStorage.setItem('fq_done_' + session + '_' + flashQ.slotKey, 'skip');
              flashQ = null;
              render();
            } else {
              var el = document.getElementById('fq-timer');
              if (el) {
                var m = Math.floor(flashQ.timerLeft / 60);
                var s = flashQ.timerLeft % 60;
                el.textContent = m + ':' + (s < 10 ? '0' : '') + s;
                if (flashQ.timerLeft < 120) el.classList.add('urgent');
              }
            }
          }, 1000);
          

        } else if (isGameHour()) {
          // Mini-game
          var gt = currentGameType();
          if (!gt) return;
          miniGame = {
            type: gt.type,
            icon: gt.icon,
            name: gt.name,
            slotKey: slotKey,
            played: false,
            prize: 0,
            gameState: initGameState(gt.type)
          };

          
        }
      }



      function answerFlashQ(optIdx) {
        if (!flashQ || flashQ.answered) return;
        var ok = optIdx === flashQ.q.correct;
        flashQ.answered = true;
        flashQ.ansIdx = optIdx;
        flashQ.ok = ok;

        // Award/deduct points
        var pts = ok ? 100 : -50;
        S.users[session].pts = Math.max(0, (S.users[session].pts || 0) + pts);
        save(S);

        // Mark slot as done
        localStorage.setItem('fq_done_' + session + '_' + flashQ.slotKey, 'answered');
        markFlashQuestionSeen(flashQ.q.id);
        if (flashTimer) clearInterval(flashTimer);

        render();

        // After short delay, show the shop popup — only if correct answer earned points
        if (ok) showShopNudgeAfterDelay();
      }

      function dismissFlashQ() {
        if (!flashQ) return;
        if (!flashQ.answered) {
          localStorage.setItem('fq_done_' + session + '_' + flashQ.slotKey, 'skip');
        }
        if (flashTimer) clearInterval(flashTimer);
        flashQ = null;
        render();
      }

      function showShopNudgeAfterDelay() {
        setTimeout(function () {
          var myPtsNow = S.users[session] ? S.users[session].pts || 0 : 0;
          var affordableRws = (S.rewards || []).filter(function (r) {
            return (r.partner === session || r.partner === 'both') && r.cost <= myPtsNow;
          });
          if (affordableRws.length > 0) {
            overlay = { type: 'reward_nudge', pts: myPtsNow, count: affordableRws.length };
            render();
          }
        }, 1200);
      }

      /* ── MINI-GAME LOGIC ── */
      function initGameState(type) {
        if (type === 'wheel') return { angle: 0, spinning: false };
        if (type === 'scratch') {
          var symbols = ['💎', '🌟', '🍀', '🔥', '👑', '💰'];
          var winSym = symbols[Math.floor(Math.random() * symbols.length)];
          var cells = [];
          // Place 3 winning symbols
          var winPositions = shuffle9()[0];
          for (var i = 0; i < 9; i++) cells.push({ symbol: symbols[Math.floor(Math.random() * symbols.length)], revealed: false });
          // Decide win (30% chance)
          if (Math.random() < 0.3) {
            var positions = shuffle9().slice(0, 3);
            positions.forEach(function (p) { cells[p].symbol = winSym; });
          }
          return { cells: cells, reveals: 0, maxReveals: 5, done: false };
        }
        if (type === 'slots') {
          var emojis = ['🍒', '🍋', '🔔', '💎', '⭐', '🍀'];
          return { reels: [emojis[0], emojis[1], emojis[2]], spinning: false, emojis: emojis };
        }
        if (type === 'dice') return { d1: 1, d2: 1, rolling: false };
        return {};
      }

      function shuffle9() {
        var a = [0, 1, 2, 3, 4, 5, 6, 7, 8];
        for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
        return a;
      }

      function calcWeightedPrize(max) {
        // Weighted: most prizes are low, few are high
        var r = Math.random();
        if (r < 0.15) return 0;         // 15% chance of 0
        if (r < 0.45) return Math.floor(Math.random() * 30) + 10;   // 30% → 10-40
        if (r < 0.70) return Math.floor(Math.random() * 50) + 40;   // 25% → 40-90
        if (r < 0.88) return Math.floor(Math.random() * 60) + 90;   // 18% → 90-150
        if (r < 0.97) return Math.floor(Math.random() * 50) + 150;  // 9% → 150-200
        return Math.floor(Math.random() * 50) + 200;                // 3% → 200-250
      }

      function finishMiniGame(prize) {
        if (!miniGame || miniGame.played) return;
        miniGame.played = true;
        miniGame.prize = prize;
        S.users[session].pts = Math.max(0, (S.users[session].pts || 0) + prize);
        save(S);
        localStorage.setItem('fq_done_' + session + '_' + miniGame.slotKey, 'answered');
        render();
        showShopNudgeAfterDelay();
      }

      function dismissMiniGame() {
        if (!miniGame) return;
        if (!miniGame.played) {
          localStorage.setItem('fq_done_' + session + '_' + miniGame.slotKey, 'skip');
        }
        miniGame = null;
        render();
      }

      function renderFlashQuestion() {
        if (!flashQ) return '';
        var fq = flashQ, q = fq.q;
        var m = Math.floor(fq.timerLeft / 60);
        var s = fq.timerLeft % 60;
        var timerStr = m + ':' + (s < 10 ? '0' : '') + s;
        var urgent = fq.timerLeft < 120;

        var h = '<div class="fq-wrap">';
        h += '<div class="fq-label">⚡ Domanda Flash</div>';
        if (!fq.answered) {
          h += '<div class="fq-timer' + (urgent ? ' urgent' : '') + '" id="fq-timer">' + timerStr + '</div>';
        }
        h += '<div class="fq-question">' + esc(q.text) + '</div>';

        if (!fq.answered) {
          h += '<div class="fq-opts">';
          q.opts.forEach(function (o, i) {
            h += '<button class="fq-opt" data-action="fq-answer" data-arg="' + i + '">' + esc(o) + '</button>';
          });
          h += '</div>';
          h += '<div style="margin-top:12px;text-align:right">';
          h += '<button data-action="fq-dismiss" style="background:none;border:none;font-size:.72rem;color:rgba(255,255,255,.4);cursor:pointer;font-family:sans-serif">Salta</button>';
          h += '</div>';
        } else {
          h += '<div class="fq-opts">';
          q.opts.forEach(function (o, i) {
            var cls = 'fq-opt';
            if (i === q.correct) cls += ' fq-ok';
            else if (i === fq.ansIdx && !fq.ok) cls += ' fq-ko';
            h += '<button class="' + cls + '" disabled>' + esc(o) + '</button>';
          });
          h += '</div>';
          h += '<div style="margin-top:10px">';
          h += '<div class="fq-result-pill ' + (fq.ok ? 'fq-pos' : 'fq-neg') + '">';
          h += fq.ok ? '✅ Corretto! +100 pt' : '❌ Sbagliato! -50 pt';
          h += '</div></div>';
          h += '<div style="margin-top:10px;text-align:right">';
          h += '<button data-action="fq-dismiss" style="background:none;border:none;font-size:.75rem;color:rgba(255,255,255,.5);cursor:pointer;font-family:sans-serif">Chiudi</button>';
          h += '</div>';
        }
        h += '</div>';
        return h;
      }

      /* ── MINI-GAME RENDERERS ── */
      function renderMiniGame() {
        if (!miniGame) return '';
        var mg = miniGame;
        var h = '<div class="mg-wrap">';
        h += '<div class="mg-label">' + mg.icon + ' Mini-Gioco</div>';
        h += '<div class="mg-title">' + esc(mg.name) + '</div>';

        if (!mg.played) {
          if (mg.type === 'wheel') h += renderWheelGame();
          else if (mg.type === 'scratch') h += renderScratchGame();
          else if (mg.type === 'slots') h += renderSlotsGame();
          else if (mg.type === 'dice') h += renderDiceGame();
          h += '<div style="margin-top:12px;text-align:right">';
          h += '<button data-action="mg-dismiss" style="background:none;border:none;font-size:.72rem;color:rgba(255,255,255,.4);cursor:pointer;font-family:sans-serif">Salta</button>';
          h += '</div>';
        } else {
          h += '<div class="mg-result">';
          if (mg.prize > 0) {
            h += '<div class="mg-result-pill mg-pos">🎉 Hai vinto +' + mg.prize + ' pt!</div>';
          } else {
            h += '<div class="mg-result-pill mg-zero">😅 Nessun premio questa volta</div>';
          }
          h += '</div>';
          h += '<div style="margin-top:12px;text-align:right">';
          h += '<button data-action="mg-dismiss" style="background:none;border:none;font-size:.75rem;color:rgba(255,255,255,.5);cursor:pointer;font-family:sans-serif">Chiudi</button>';
          h += '</div>';
        }
        h += '</div>';
        return h;
      }

      /* WHEEL */
      function renderWheelGame() {
        var gs = miniGame.gameState;
        var segments = [
          { label: '10', color: '#e74c3c', val: 10 },
          { label: '50', color: '#3498db', val: 50 },
          { label: '0', color: '#95a5a6', val: 0 },
          { label: '100', color: '#2ecc71', val: 100 },
          { label: '25', color: '#e67e22', val: 25 },
          { label: '250', color: '#f1c40f', val: 250 },
          { label: '75', color: '#9b59b6', val: 75 },
          { label: '150', color: '#1abc9c', val: 150 }
        ];
        var n = segments.length, anglePerSeg = 360 / n;
        var h = '<div class="wheel-container">';
        h += '<div class="wheel-pointer">▼</div>';
        h += '<svg class="wheel-svg" id="wheel-svg" viewBox="0 0 200 200" style="transform:rotate(' + (gs.angle || 0) + 'deg)">';
        for (var i = 0; i < n; i++) {
          var startA = i * anglePerSeg - 90;
          var endA = startA + anglePerSeg;
          var sr = startA * Math.PI / 180, er = endA * Math.PI / 180;
          var x1 = 100 + 95 * Math.cos(sr), y1 = 100 + 95 * Math.sin(sr);
          var x2 = 100 + 95 * Math.cos(er), y2 = 100 + 95 * Math.sin(er);
          var large = anglePerSeg > 180 ? 1 : 0;
          h += '<path d="M100,100 L' + x1 + ',' + y1 + ' A95,95 0 ' + large + ',1 ' + x2 + ',' + y2 + ' Z" fill="' + segments[i].color + '"/>';
          var midA = (startA + anglePerSeg / 2) * Math.PI / 180;
          var tx = 100 + 60 * Math.cos(midA), ty = 100 + 60 * Math.sin(midA);
          h += '<text x="' + tx + '" y="' + ty + '" text-anchor="middle" dominant-baseline="central" fill="white" font-size="12" font-weight="700" font-family="sans-serif">' + segments[i].label + '</text>';
        }
        h += '</svg></div>';
        if (!gs.spinning) {
          h += '<button class="wheel-spin-btn" data-action="mg-wheel-spin">Gira! 🎰</button>';
        } else {
          h += '<div style="text-align:center;color:rgba(255,255,255,.6);font-size:.82rem">La ruota sta girando...</div>';
        }
        return h;
      }

      /* SCRATCH CARD */
      function renderScratchGame() {
        var gs = miniGame.gameState;
        var h = '<p style="font-size:.78rem;color:rgba(255,255,255,.6);margin-bottom:12px;text-align:center">Tocca fino a 5 celle. 3 simboli uguali = premio!</p>';
        h += '<div class="scratch-grid">';
        gs.cells.forEach(function (cell, i) {
          if (cell.revealed || gs.done) {
            h += '<div class="scratch-cell revealed">' + cell.symbol + '</div>';
          } else {
            h += '<button class="scratch-cell covered" data-action="mg-scratch" data-arg="' + i + '"></button>';
          }
        });
        h += '</div>';
        if (gs.done && !miniGame.played) {
          // Check for win
          var counts = {};
          gs.cells.forEach(function (c) { if (c.revealed) { counts[c.symbol] = (counts[c.symbol] || 0) + 1; } });
          var won = false;
          Object.keys(counts).forEach(function (k) { if (counts[k] >= 3) won = true; });
          h += '<div style="text-align:center;margin-top:8px">';
          h += '<button class="wheel-spin-btn" data-action="mg-scratch-finish" data-arg="' + (won ? '1' : '0') + '">' + (won ? '🎉 Scopri il premio!' : 'Scopri il risultato') + '</button>';
          h += '</div>';
        }
        return h;
      }

      /* SLOT MACHINE */
      function renderSlotsGame() {
        var gs = miniGame.gameState;
        var h = '<div class="slot-container">';
        for (var i = 0; i < 3; i++) {
          h += '<div class="slot-reel' + (gs.spinning ? ' spinning' : '') + '" id="reel-' + i + '">' + gs.reels[i] + '</div>';
        }
        h += '</div>';
        if (!gs.spinning) {
          h += '<button class="slot-spin-btn" data-action="mg-slots-spin">Tira la leva! 🎰</button>';
        } else {
          h += '<div style="text-align:center;color:rgba(255,255,255,.6);font-size:.82rem">I rulli girano...</div>';
        }
        return h;
      }

      /* LUCKY DICE */
      function renderDiceGame() {
        var gs = miniGame.gameState;
        var diceEmojis = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
        var h = '<p style="font-size:.78rem;color:rgba(255,255,255,.6);margin-bottom:12px;text-align:center">Lancia i dadi! Somma × 20 = punti vinti</p>';
        h += '<div class="dice-container">';
        h += '<div class="dice' + (gs.rolling ? ' rolling' : '') + '">' + diceEmojis[gs.d1] + '</div>';
        h += '<div class="dice' + (gs.rolling ? ' rolling' : '') + '">' + diceEmojis[gs.d2] + '</div>';
        h += '</div>';
        if (!gs.rolling) {
          h += '<button class="dice-roll-btn" data-action="mg-dice-roll">Lancia! 🎲</button>';
        } else {
          h += '<div style="text-align:center;color:rgba(255,255,255,.6);font-size:.82rem">I dadi rotolano...</div>';
        }
        return h;
      }

      function notifyRewardDone(req) {
        var topic = S.users[req.by] && S.users[req.by].ntfyTopic;
        if (!topic) return;
        var executor = req.by === 'giulia' ? '⚡ Stefano' : '🌸 Giulia';
        ntfySend(topic, '✅ Ordine consegnato — conferma!', executor + " ha segnato come consegnato l'ordine: " + req.name + "\nConfermi la ricezione?", ['ballot_box_with_check']);
      }

      function checkPenaltyWarning() {
        if (!session || session === 'admin') return;
        var u = S.users[session];
        if (!u) return;

        // ── Premio inactivity warning (2 days) ──
        if (u.lastRewardClaim) {
          var days = daysAgo(u.lastRewardClaim);
          var warnKey = 'pw_warned_' + todayKey();
          if (days >= 2 && days < 3 && !sessionStorage.getItem(warnKey)) {
            sessionStorage.setItem(warnKey, '1');
            var topic = u.ntfyTopic;
            if (topic) {
              ntfySend(topic, '⚠️ Penalità in arrivo!', 'Sono ' + days + ' giorni senza effettuare nuovi ordini. Entro domani perdi 500 pt!', ['warning']);
            }
          }
        }
      }
      function pname(u) { return u === 'giulia' ? 'Giulia' : 'Stefano'; }
      function partner() { return session === 'giulia' ? 'stefano' : 'giulia'; }
      function myPts() { return S.users[session] ? (S.users[session].pts || 0) : 0; }
      function ptOf(u) { return S.users[u] ? (S.users[u].pts || 0) : 0; }
      function countdown(dl) {
        var diff = new Date(dl) - Date.now();
        if (diff <= 0) return 'Scaduto';
        var h = Math.floor(diff / 3600000), m = Math.floor((diff % 3600000) / 60000);
        if (h >= 24) { var d = Math.floor(h / 24); return d + 'g ' + (h % 24) + 'h'; }
        return h > 0 ? h + 'h ' + m + 'm' : m + ' min';
      }
      function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
      function copyToClipboard(text) {
        if (navigator.clipboard) {
          navigator.clipboard.writeText(text).then(function () { showToast('✅ Copiato!'); }).catch(function () { showToast('Copia: ' + text, 5000); });
        } else {
          showToast('Topic: ' + text, 6000);
        }
      }
      function showToast(msg, dur) {
        if (toastT) clearTimeout(toastT);
        toast = msg; render();
        toastT = setTimeout(function () { toast = null; render(); }, dur || 3200);
      }

      /* ── TICK ── */
      function checkTick() {
        if (!session || session === 'admin') return;
        var u = S.users[session], today = todayKey(), changed = false;

        // ── Premio inactivity penalty (3 days) ──
        if (u.penaltyChecked !== today && u.lastRewardClaim) {
          if (daysAgo(u.lastRewardClaim) >= 3) {
            S.users[session].pts = Math.max(0, (u.pts || 0) - 500);
            S.users[session].penaltyChecked = today;
            S.users[session].lastRewardClaim = new Date().toISOString();
            changed = true;
            showToast('Penalità: -500 pt per inattività premi!', 5000);
          }
        }


        // ── Expire overdue reward requests ──
        S.requests.forEach(function (rr, i) {
          if (rr.status === 'pending' && rr.mode === 'deadline' && rr.deadline && new Date(rr.deadline) < new Date()) {
            S.requests[i].status = 'expired'; changed = true;
          }
        });

        if (changed) save(S);
      }

      /* ── ACTIONS ── */
      function doLogin() {
        var u = selU; if (!u) return;
        var pw = (document.getElementById('ipwd') || {}).value || '';
        var pw2 = (document.getElementById('ipwd2') || {}).value || '';
        var err = document.getElementById('aerr');
        if (!pw) { if (err) err.textContent = 'Inserisci la password'; return; }
        if (!S.users[u].pwdSet) {
          if (pw.length < 4) { if (err) err.textContent = 'Minimo 4 caratteri'; return; }
          if (pw !== pw2) { if (err) err.textContent = 'Le password non corrispondono'; return; }
          S.users[u].pwd = pw; S.users[u].pwdSet = true;
          S.users[u].pts = 1000; S.users[u].lastRewardClaim = new Date().toISOString();
          save(S); session = u; saveSession(u); tab = 'home'; selU = null; showOB = true; obStep = 0;
          ensureTopic(u);
          checkTick(); checkFlashQuestion(); announcePresence(); render();
        } else {
          if (pw === S.users[u].pwd) { session = u; saveSession(u); tab = 'home'; selU = null; ensureTopic(u); checkTick(); checkPenaltyWarning(); checkFlashQuestion(); announcePresence(); render(); }
          else { if (err) err.textContent = 'Password errata'; }
        }
      }

      function openClaim(rid, overrideCost) {
        var r = S.rewards.filter(function (x) { return x.id === rid; })[0];
        if (!r) return;
        var claimR = Object.assign({}, r);
        if (overrideCost) claimR.cost = parseInt(overrideCost, 10);
        claimMode = 'deadline';
        overlay = { type: 'claim', reward: claimR };
        render();
        setTimeout(window.updateClaimTotal, 10);
      }

      function prepareClaim() {
        if (!overlay || !overlay.reward) return;
        var r = overlay.reward;
        var sel = document.getElementById('claimDL');
        var dlMode = sel ? sel.value : '0';
        if (r.cost >= 50 && !dlMode) { showToast('Seleziona le tempistiche di consegna'); return; }

        var extraCost = 0;
        var premiumArr = [];
        if (dlMode === 'subito') { extraCost += 100; premiumArr.push('Consegna Subito (Priorità Massima)'); }
        else if (dlMode === '1') { extraCost += 50; premiumArr.push('Consegna Entro 1 ora (Priorità Alta)'); }

        var cbs = document.querySelectorAll('#premiumOptions input[type="checkbox"]');
        cbs.forEach(function (cb) {
          if (cb.checked) {
            extraCost += parseInt(cb.value, 10);
            var pText = cb.getAttribute('data-opt');
            var name = cb.getAttribute('name') || cb.id;
            if (name === 'cbBenda') {
              var who = document.querySelector('input[name="optBenda"]:checked');
              if (who) pText += ' (' + who.value + ')';
            } else if (name === 'cbManette') {
              var whoM = document.querySelector('input[name="optManette"]:checked');
              if (whoM) pText += ' (' + whoM.value + ')';
            } else if (name === 'cbVieni') {
              var txt = document.getElementById('txtVieni').value.trim();
              pText += ' (' + (txt || 'Dove voglio io') + ')';
            }
            premiumArr.push(pText);
          }
        });

        var totalCost = r.cost + extraCost;
        var pts = myPts();
        if (pts < totalCost) { showToast('Punti insufficienti! Te ne servono ' + totalCost); return; }

        var actualDl = '';
        if (dlMode !== '0') {
          var d = new Date();
          if (dlMode === 'subito') d.setMinutes(d.getMinutes() + 30);
          else d.setHours(d.getHours() + parseInt(dlMode, 10));
          actualDl = d.toISOString();
        }

        overlay = {
          type: 'claim_confirm',
          reward: r,
          totalCost: totalCost,
          actualDl: actualDl,
          premiumArr: premiumArr
        };
        render();
      }

      function finalizeClaim() {
        var o = overlay;
        if (o.type !== 'claim_confirm') return;
        var pts = myPts();
        if (pts < o.totalCost) { showToast('Punti insufficienti!'); return; }

        S.users[session].pts = pts - o.totalCost;
        S.users[session].lastRewardClaim = new Date().toISOString();
        S.requests.push({
          id: Date.now() + '', by: session,
          name: o.reward.name, emoji: o.reward.emoji || '🎁', desc: o.reward.desc || '',
          requestedAt: new Date().toISOString(),
          mode: 'deadline', deadline: o.actualDl, premium: o.premiumArr, note: '', status: 'pending', cost: o.totalCost
        });
        save(S);
        notifyPartnerNewReward(o.reward.name, o.actualDl);
        overlay = { type: 'claim_success', reward: o.reward };
        render();
      }

      function markDone(rrId) {
        var i = S.requests.findIndex(function (r) { return r.id === rrId; });
        if (i < 0) return;
        S.requests[i].status = 'done_confirm';
        S.requests[i].doneAt = new Date().toISOString();
        save(S);
        notifyRewardDone(S.requests[i]);
        showToast('Segnato! In attesa di conferma da ' + pname(S.requests[i].by) + '…', 4000);
        render();
      }

      function confirmDone(rrId, yes) {
        var i = S.requests.findIndex(function (r) { return r.id === rrId; });
        if (i < 0) return;
        var req = S.requests[i];
        if (yes) {
          req.status = 'done'; req.confirmedAt = new Date().toISOString();
          if (req.unfulfilledPenaltyApplied || req.latePenaltyApplied) {
            showToast('✅ Ricezione confermata!', 4000);
          } else {
            showToast('✅ Messo a registro come ricevuto!', 4000);
          }
        } else {
          if (req.status === 'expired') {
            showToast('Ok, l\'ordine rimane scaduto.', 3000);
            overlay = null; render(); return;
          }
          req.status = 'pending'; delete req.doneAt;
          showToast('Rimandato — il partner dovrà consegnare di nuovo!', 4000);
        }
        save(S); render();
      }

      function declareUnfulfilled(rrId) {
        var i = S.requests.findIndex(function (r) { return r.id === rrId; });
        if (i < 0) return;
        var req = S.requests[i];
        if (!confirm("Dichiarare l'ordine come non evaso? Riceverai un rimborso del 100% e il partner subirà una multa del 150% del valore.")) return;
        var rCost = req.cost || 100;
        var executor = req.by === 'giulia' ? 'stefano' : 'giulia';
        S.users[req.by].pts = (S.users[req.by].pts || 0) + rCost;
        var penalty = Math.floor(rCost * 1.5);
        S.users[executor].pts = Math.max(0, (S.users[executor].pts || 0) - penalty);
        req.status = 'expired';
        req.unfulfilledPenaltyApplied = true;
        req.refundAmt = rCost; req.penaltyAmt = penalty; req.cancelledAt = new Date().toISOString();
        save(S);
        showToast('Ordine segnato come non evaso. Rimborsati ' + rCost + ' pt.', 4000);
        var topic = S.users[executor] && S.users[executor].ntfyTopic;
        if (topic) ntfySend(topic, '🚨 Ordine non evaso annullato!', "Il partner ha dichiarato l'ordine NON EVASO. Multa salata di -" + penalty + " pt registrata.", ['no_entry_sign']);
        render();
      }

      function reportLate(rrId) {
        var i = S.requests.findIndex(function (r) { return r.id === rrId; });
        if (i < 0) return;
        var req = S.requests[i];
        if (!confirm('Segnalare il ritardo di consegna?\n\nRiceverai un rimborso del 30% e al partner verrà addebitata una penale del 50% del valore dell\'ordine.')) return;
        var rCost = req.cost || 100;
        var executor = req.by === 'giulia' ? 'stefano' : 'giulia';
        var refund = Math.floor(rCost * 0.3);
        var penalty = Math.floor(rCost * 0.5);
        S.users[req.by].pts = (S.users[req.by].pts || 0) + refund;
        S.users[executor].pts = Math.max(0, (S.users[executor].pts || 0) - penalty);
        req.status = 'done';
        req.latePenaltyApplied = true;
        req.refundAmt = refund;
        req.penaltyAmt = penalty;
        req.doneAt = req.doneAt || new Date().toISOString();
        req.confirmedAt = new Date().toISOString();
        save(S);
        showToast('Ritardo segnalato. Rimborsati ' + refund + ' pt. Penale ' + penalty + ' pt al partner.', 5000);
        var topic = S.users[executor] && S.users[executor].ntfyTopic;
        if (topic) ntfySend(topic, '⚠️ Ritardo segnalato!', 'Il cliente ha confermato, ma segnalato un ritardo su: ' + req.name + '. Penale di -' + penalty + ' pt addebitata.', ['warning']);
        render();
      }

      function doAdmLogin() {
        var u = (document.getElementById('au') || {}).value || '';
        var p = (document.getElementById('ap') || {}).value || '';
        if (u === 'admin' && p === 'Beggione12') { adminAuthed = true; sessionStorage.setItem('adm_ok', '1'); render(); }
        else { var e = document.getElementById('admerr'); if (e) e.textContent = 'Credenziali errate'; }
      }
      function addQ() {
        var text = ((document.getElementById('qT') || {}).value || '').trim();
        var opts = [0, 1, 2, 3].map(function (i) { return ((document.getElementById('qO' + i) || {}).value || '').trim(); });
        var correct = +((document.getElementById('qC') || {}).value || 0);
        if (!text || opts.some(function (o) { return !o; })) { showToast('Compila domanda e tutte le opzioni'); return; }
        S.questions.push({ id: Date.now() + '', text: text, opts: opts, correct: correct });
        save(S); showToast('Domanda aggiunta!'); render();
      }
      function delQ(id) { S.questions = S.questions.filter(function (q) { return q.id !== id; }); save(S); render(); }
      function addR() {
        var partner = (document.getElementById('rPt') || {}).value || 'giulia';
        var cost = +((document.getElementById('rC') || {}).value || 100);
        var emoji = (document.getElementById('rE') || {}).value || '🎁';
        var name = ((document.getElementById('rN') || {}).value || '').trim();
        var desc = ((document.getElementById('rD') || {}).value || '').trim();
        if (!name || !cost) { showToast('Compila nome e costo'); return; }
        S.rewards.push({ id: Date.now() + '', partner: partner, name: name, desc: desc, emoji: emoji, cost: cost });
        save(S); showToast('Premio aggiunto!'); render();
      }
      function delR(id) { S.rewards = S.rewards.filter(function (r) { return r.id !== id; }); save(S); render(); }
      function adjPts(p, d) { S.users[p].pts = Math.max(0, (S.users[p].pts || 0) + d); save(S); showToast((d > 0 ? '+' : '') + d + ' pt a ' + pname(p)); render(); }
      function doReset() {
        if (confirm('Reset completo? Irreversibile!')) {
          S = clone(BLANK);
          save(S);
          showToast('Reset completato');
          render();
        }
      }

      /* ── RENDER ROOT ── */
      function render() {
        var root = document.getElementById('R');
        if (!root) return;
        if (!session) { root.innerHTML = renderAuth(); return; }
        if (session === 'admin') { root.innerHTML = renderAdmin(); return; }

        root.innerHTML = renderApp();
      }

      /* ── AUTH ── */
      function renderAuth() {
        var u = selU ? S.users[selU] : null;
        var isFirst = u && !u.pwdSet;
        var h = '<div class="auth-wrap"><div class="auth-card">';
        h += '<div class="auth-logo"><span class="auth-gem">🔷</span><h1>Secret Challenge</h1><p>Le tue sfide quotidiane segrete</p></div>';
        h += '<div class="field"><span class="lbl">Chi sei?</span><div class="user-grid">';
        h += '<button class="ubtn' + (selU === 'giulia' ? ' on' : '') + '" data-action="pick-user" data-arg="giulia">🌸 Giulia</button>';
        h += '<button class="ubtn' + (selU === 'stefano' ? ' on' : '') + '" data-action="pick-user" data-arg="stefano">⚡ Stefano</button>';
        h += '</div></div>';
        if (selU) {
          if (isFirst) h += '<div class="note-box">👋 Primo accesso ' + esc(pname(selU)) + '! Ricevi <strong>1000 punti</strong> di benvenuto 🎉</div>';
          h += '<div class="field"><label class="lbl">Password</label><input type="password" id="ipwd" placeholder="' + (isFirst ? 'Scegli una password' : 'Inserisci password') + '"/></div>';
          if (isFirst) h += '<div class="field"><label class="lbl">Conferma password</label><input type="password" id="ipwd2" placeholder="Ripeti la password"/></div>';
          h += '<div id="aerr" class="err"></div>';
          h += '<div class="field"><button class="btn btn-p btn-full" data-action="do-login">' + (isFirst ? 'Imposta e accedi →' : 'Accedi →') + '</button></div>';
        }
        h += '<div style="text-align:right;margin-top:10px"><button data-action="go-admin" style="background:none;border:none;font-size:.72rem;color:var(--muted);cursor:pointer;font-family:sans-serif;padding:4px">Settings</button></div>';
        h += '</div></div>';
        return h;
      }

      /* ── ONBOARDING ── */
      var OB = [
        { icon: '🔷', title: 'Benvenuto/a in Secret Challenge!', body: 'Qui trovi il tuo saldo punti, le attività e le richieste del partner. Inizi con <strong>1000 punti</strong>.' },
        { icon: '⚡', title: 'Domande Flash e Mini-Giochi', body: 'Ogni giorno dalle 15 alle 21 hai <strong>7 attività</strong>: 3 domande flash (+100/-50 pt) e 4 mini-giochi (fino a 250 pt). Appaiono in Home ogni ora!' },
        { icon: '🛍', title: 'Lo Shop', body: 'Nel tab <em>Shop</em> scegli un premio, spendi i punti e dici al partner entro quando o a che ora vuoi riceverlo.' },
        { icon: '📨', title: 'Esegui i premi del partner', body: 'Nel tab <em>Esegui</em> vedi le richieste. Quando finisci, segnalo: il partner dovrà <strong>confermare</strong>.' },
        { icon: '⚠️', title: 'Regola dei 3 giorni', body: 'Devi richiedere <strong>almeno un premio ogni 3 giorni</strong>. Se dimentichi, perdi automaticamente <strong>500 punti</strong>.' },
        { icon: '🚀', title: 'Sei pronto/a!', body: 'Completa le attività di oggi e richiedi il tuo primo premio. Buona fortuna!' }
      ];
      function renderOnboarding() {
        var s = OB[obStep], isLast = obStep === OB.length - 1;
        var dots = OB.map(function (_, i) {
          return '<div class="ob-dot ' + (i === obStep ? 'on' : 'off') + '"></div>';
        }).join('');
        var h = '<div class="overlay center" data-action="close-overlay">';
        h += '<div class="sheet rounded">';
        h += '<div style="font-size:3.5rem;margin-bottom:14px">' + s.icon + '</div>';
        h += '<h2 style="font-size:1.25rem;color:var(--b2);margin-bottom:8px">' + esc(s.title) + '</h2>';
        h += '<p style="font-size:.85rem;color:var(--muted);line-height:1.65;margin-bottom:6px">' + s.body + '</p>';
        h += '<div class="ob-dots">' + dots + '</div>';
        h += '<div style="display:flex;gap:10px;justify-content:center">';
        if (obStep > 0) h += '<button class="btn btn-o btn-sm" data-action="ob-back">← Indietro</button>';
        if (isLast) h += '<button class="btn btn-p" style="min-width:120px" data-action="ob-close">Inizia! 🚀</button>';
        else h += '<button class="btn btn-p" style="min-width:120px" data-action="ob-next">Avanti →</button>';
        h += '</div>';
        if (!isLast) h += '<div style="margin-top:12px"><button data-action="ob-close" style="background:none;border:none;font-size:.75rem;color:var(--muted);cursor:pointer;font-family:sans-serif">Salta la guida</button></div>';
        h += '</div></div>';
        return h;
      }



      /* ── MAIN APP ── */
      function renderApp() {
        var me = session, pt = partner();
        var u = S.users[me], pts = myPts(), ptPts = ptOf(pt);
        var ptOnline = onlineUsers[pt] && (Date.now() - onlineUsers[pt] < 12000);
        var myReqs = S.requests.filter(function (r) { return r.by === me; });
        var toExec = S.requests.filter(function (r) { return r.by !== me && r.status === 'pending'; });
        var toConf = S.requests.filter(function (r) { return r.by === me && r.status === 'done_confirm'; });
        var myRws = S.rewards.filter(function (r) { return r.partner === me || r.partner === 'both'; }).sort(function (a, b) { return (a.cost || 0) - (b.cost || 0); });
        var hasBadge = toExec.length > 0 || toConf.length > 0;
        var page = '';

        if (tab === 'home') {
          page += renderHomeHeader(me, pts, u);

          

          if (toConf.length > 0) {
            page += '<div class="sec-label">🔔 Conferma richiesta (' + toConf.length + ')</div>';
            toConf.forEach(function (rr) { page += renderMyReqCard(rr); });
          }
          if (toExec.length > 0) {
            page += '<div class="sec-label">📨 Da eseguire per ' + esc(pname(pt)) + ' (' + toExec.length + ')</div>';
            toExec.forEach(function (rr) { page += renderExecCard(rr, false); });
          }

          page += renderWellnessWidget(me);
          page += renderFlashSaleWidget();
          page += renderLastOrderWidget(myReqs);
          page += renderGamesCTA();

          if (showHistory) {
            var histOrders = myReqs.filter(function (r) { return r.status === 'done' || r.status === 'expired'; }).slice().reverse();
            if (!histOrders.length) {
              page += '<div class="empty"><span class="empty-ico">🗒️</span><p>Nessun ordine completato o scaduto.</p></div>';
            } else {
              histOrders.forEach(function (rr) { page += renderMyReqCard(rr); });
            }
          }

          page += '<div style="height:20px"></div>';
        }
        else if (tab === 'shop') {
    var hTop = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
    hTop += '<div style="font-size:1.6rem;font-weight:800;color:#1a1f36;font-family:\'Playfair Display\',serif">Shop</div>';
    hTop += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:6px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
    hTop += '</div>';
    page += hTop;

    var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
    var fSalesCount = 0;
    var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
    if (myRewards.length > 0) {
      fSalesCount = Math.min(3, myRewards.length);
    }

    if (fSalesCount > 0) {
      var hrsLeft = 5 - (Math.floor(Date.now() / 3600000) % 5);
      var hBanner = '<div style="background:#1a2a5e;border-radius:16px;padding:20px;display:flex;justify-content:space-between;align-items:center;margin-bottom:24px">';
      hBanner += '<div><div style="font-size:.7rem;font-weight:800;color:#8fa8d8;text-transform:uppercase;margin-bottom:4px">FLASH SALE ATTIVA</div>';
      hBanner += '<div style="font-size:1.05rem;font-weight:800;color:#ffffff;margin-bottom:4px">Sconti fino al -10%</div>';
      hBanner += '<div style="font-size:.7rem;color:#8fa8d8">Scade tra '+hrsLeft+'h — non perdere l\'offerta</div></div>';
      hBanner += '<div style="background:#c04020;border-radius:12px;padding:8px 12px;text-align:center;min-width:70px">';
      hBanner += '<div style="font-size:.65rem;color:#ffd0c0;font-weight:800;text-transform:uppercase;margin-bottom:2px">SCADE TRA</div>';
      hBanner += '<div style="font-size:1.2rem;font-weight:800;color:#ffffff;line-height:1">'+hrsLeft+'h</div></div></div>';
      page += hBanner;
    }

    page += '<div style="font-size:.75rem;font-weight:800;color:#6b7080;text-transform:uppercase;margin-bottom:12px;letter-spacing:.05em">VETRINA PRODOTTI</div>';
    
    if (!myRws.length) {
      page += '<div class="empty"><span class="empty-ico">🛍️</span><p>Nessun prodotto in inventario.<br>Il fornitore li aggiungerà presto!</p></div>';
    } else {
      myRws.forEach(function(r) { page += renderShopItem(r, pts); });
      page += '<div style="text-align:center;font-size:.8rem;color:#b0b4c0;margin-top:24px;margin-bottom:20px">Hai visto tutti i prodotti disponibili</div>';
    }
  }
        else if (tab === 'giochi') {
          var hr = new Date().getHours();
          var hTop = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
          hTop += '<div style="font-size:1.6rem;font-weight:800;color:#1a1f36;font-family:\'Playfair Display\',serif">Giochi</div>';
          hTop += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:6px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
          hTop += '</div>';
          page += hTop;

          var activeHours = [];
          var futureHours = [];
          var pastHours = [];

          ALL_ACTIVITY_HOURS.forEach(function(h) {
            var slotK = new Date().getFullYear() + '-' + new Date().getMonth() + '-' + new Date().getDate() + '-' + h;
            var doneK = 'fq_done_' + session + '_' + slotK;
            var isDone = !!localStorage.getItem(doneK);

            var isQuiz = QUIZ_HOURS.indexOf(h)>=0;
            var sch = GAME_SCHEDULE[h];
            
            var item = { h: h, isDone: isDone, isQuiz: isQuiz, slotK: slotK };
            item.icon = isQuiz ? '⚡' : (sch ? sch.icon : '🎮');
            item.name = isQuiz ? 'Domanda Flash' : (sch ? sch.name : 'Mini-gioco');
            item.desc = isQuiz ? 'Rispondi alla domanda a tempo' : 'Gioca e raddoppia i punti';

            if (h === hr) activeHours.push(item);
            else if (h > hr) futureHours.push(item);
            else pastHours.push(item);
          });

          var renderActiveGameCard = function(ico, title, desc, btnTxt, action, arg) {
            var h = '<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:20px;padding:20px;box-shadow:0 8px 24px rgba(0,0,0,0.06);margin-bottom:20px;display:flex;flex-direction:column;gap:12px">';
            h += '<div style="display:flex;align-items:center;gap:14px">';
            h += '<div style="width:60px;height:60px;background:#eef3fb;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:2.2rem;flex-shrink:0">'+ico+'</div>';
            h += '<div><div style="font-size:1.1rem;font-weight:800;color:#1a1f36;margin-bottom:4px">'+title+'</div>';
            h += '<div style="font-size:.8rem;color:#8a8f9e">'+desc+'</div></div></div>';
            h += '<button style="width:100%;background:#1a2a5e;color:#ffffff;border:none;padding:14px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="'+action+'" data-arg="'+arg+'">'+btnTxt+'</button>';
            h += '</div>';
            return h;
          };

          var renderDisabledGameCard = function(ico, title, statusTxt, isPast) {
            var op = isPast ? '0.6' : '0.8';
            var bg = isPast ? '#f8f9fc' : '#ffffff';
            var h = '<div style="background:'+bg+';border:1px solid #e2e8f0;border-radius:16px;padding:14px;margin-bottom:12px;display:flex;align-items:center;gap:14px;opacity:'+op+'">';
            h += '<div style="width:48px;height:48px;background:#eef3fb;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">'+ico+'</div>';
            h += '<div style="flex:1"><div style="font-size:.95rem;font-weight:700;color:#1a1f36;margin-bottom:4px">'+title+'</div>';
            h += '<div style="font-size:.75rem;color:#8a8f9e;font-weight:600">'+statusTxt+'</div></div>';
            h += '<div style="color:#b0bcd8">' + (isPast ? (statusTxt.indexOf('Completato')>=0?'✅':'⏰') : '🔒') + '</div>';
            h += '</div>';
            return h;
          };

          var hasActive = false;
          if (flashQ && !flashQ.answered && !localStorage.getItem('fq_done_' + session + '_' + flashQ.slotKey)) {
             hasActive = true;
             page += renderActiveGameCard('⚡', 'Domanda Flash', 'Rispondi prima che scada il tempo!', 'Gioca Subito →', 'open-activity', 'flash');
          } else if (miniGame && !miniGame.played && !localStorage.getItem('fq_done_' + session + '_' + miniGame.slotKey)) {
             hasActive = true;
             page += renderActiveGameCard(miniGame.icon, miniGame.name, 'Gioca subito per vincere punti extra!', 'Gioca Subito 🎮', 'open-activity', 'game');
          }

          if (!hasActive && activeHours.length > 0 && !activeHours[0].isDone) {
             // Fallback active item
             var act = activeHours[0];
             page += renderActiveGameCard(act.icon, act.name, act.desc, 'Gioca Subito →', 'open-activity', 'fallback');
          }

          page += '<div style="font-size:.75rem;font-weight:800;color:#6b7080;text-transform:uppercase;margin-top:24px;margin-bottom:12px;letter-spacing:.05em">Prossimi Eventi</div>';
          if (futureHours.length === 0) page += '<div style="font-size:.8rem;color:#8a8f9e;margin-bottom:16px">Nessun evento in programma per oggi.</div>';
          futureHours.forEach(function(item) {
             var diffH = item.h - hr;
             var diffLabel = 'Tra ' + diffH + ' ora/e';
             page += renderDisabledGameCard(item.icon, item.name, diffLabel, false);
          });

          page += '<div style="font-size:.75rem;font-weight:800;color:#6b7080;text-transform:uppercase;margin-top:24px;margin-bottom:12px;letter-spacing:.05em">Storico Oggi</div>';
          var allPast = pastHours.concat();
          if (activeHours.length > 0 && activeHours[0].isDone) allPast.push(activeHours[0]);
          
          if (allPast.length === 0) {
             page += '<div style="font-size:.8rem;color:#8a8f9e;margin-bottom:16px;padding-bottom:20px">Non hai ancora giocato oggi.</div>';
          } else {
             allPast.forEach(function(item) {
                var statusLabel = item.isDone ? 'Completato' : 'Scaduto';
                page += renderDisabledGameCard(item.icon, item.name, statusLabel, true);
             });
             page += '<div style="height:20px"></div>';
          }
        }
        else if (tab === 'execute') {
          window.executeSubTab = window.executeSubTab || 'ricevuti';
          
          var hTop = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
          hTop += '<div style="font-size:1.6rem;font-weight:800;color:#1a1f36;font-family:\'Playfair Display\',serif">Ordini</div>';
          hTop += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:6px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
          hTop += '</div>';
          page += hTop;

          page += '<div style="margin-bottom:24px;background:#e2e5f0;border-radius:12px;padding:6px;display:flex;gap:6px">';
          var isRic = window.executeSubTab === 'ricevuti';
          var namePt = esc(pname(pt));
          
          var stRic = isRic ? 'background:#ffffff;color:#1a1f36;box-shadow:0 2px 8px rgba(0,0,0,0.05)' : 'color:#6b7080;cursor:pointer';
          page += '<div data-action="set-subtab" data-arg="ricevuti" style="flex:1;text-align:center;padding:10px;border-radius:8px;transition:0.2s;'+stRic+'"><div style="font-size:.95rem;font-weight:800">Ricevuti</div><div style="font-size:.75rem;opacity:0.6;margin-top:2px">da ' + namePt + '</div></div>';
          
          var stInv = !isRic ? 'background:#ffffff;color:#1a1f36;box-shadow:0 2px 8px rgba(0,0,0,0.05)' : 'color:#6b7080;cursor:pointer';
          page += '<div data-action="set-subtab" data-arg="inviati" style="flex:1;text-align:center;padding:10px;border-radius:8px;transition:0.2s;'+stInv+'"><div style="font-size:.95rem;font-weight:800">Inviati</div><div style="font-size:.75rem;opacity:0.6;margin-top:2px">a ' + namePt + '</div></div>';
          page += '</div>';

          var list = isRic 
            ? S.requests.filter(function(r) { return r.by !== me; }).slice().reverse()
            : S.requests.filter(function(r) { return r.by === me; }).slice().reverse();

          if (!list.length) {
            page += '<div class="empty" style="margin-top:40px"><span class="empty-ico">📦</span><p style="font-size:.9rem;color:#8a8f9e;line-height:1.5">Nessun ordine presente in questa categoria.</p></div>';
          } else {
            page += '<div style="display:flex;flex-direction:column;gap:12px">';
            list.forEach(function(rr) {
              var s = rr.status;
              var isPending = s === 'pending';
              var isDone = s === 'done' || s === 'done_confirm';
              
              var bgB = isPending ? '#fff8e6' : isDone ? '#e6f7ee' : '#fdf0f0';
              var colB = isPending ? '#a06800' : isDone ? '#1a7a4a' : '#a32d2d';
              var txtB = isPending ? 'In lavorazione' : isDone ? 'Consegnato' : 'Annullato';
              
              var card = '<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;padding:16px;cursor:pointer;transition:all .2s" onclick="document.querySelector(\'[data-arg=\'+esc(rr.id)+\']\').click()">';
              card += '<div style="display:flex;align-items:flex-start;gap:14px;margin-bottom:12px">';
              card += '<div style="width:54px;height:54px;background:#eef3fb;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.8rem;flex-shrink:0">'+(rr.emoji||'🎁')+'</div>';
              card += '<div style="flex:1">';
              card += '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">';
              card += '<div style="font-size:.95rem;font-weight:800;color:#1a1f36;line-height:1.2;max-width:140px">'+esc(rr.name)+'</div>';
              card += '<div style="background:'+bgB+';color:'+colB+';font-size:.65rem;font-weight:800;padding:4px 10px;border-radius:12px;white-space:nowrap">'+txtB+'</div>';
              card += '</div>';
              
              var d = new Date(rr.requestedAt);
              var pad = function(n) { return n < 10 ? '0'+n : n; };
              var dateStr = pad(d.getDate()) + '/' + pad(d.getMonth()+1) + ' · ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
              
              card += '<div style="font-size:.8rem;color:#8a8f9e">'+dateStr+'</div>';
              card += '</div></div>';
              
              card += '<div style="display:flex;justify-content:space-between;align-items:center">';
              card += '<div style="font-size:1rem;font-weight:900;color:#1a1f36"><span style="color:#378add;font-size:.8em">🔷</span> '+(rr.cost||100)+' pt</div>';
              card += '<button style="background:none;border:none;color:#378add;font-size:.85rem;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:4px" data-action="view-order" data-arg="'+esc(rr.id)+'" data-arg2="'+(isRic?'1':'0')+'">Dettaglio <span style="font-size:1.1em">→</span></button>';
              card += '</div></div>';
              page += card;
            });
            page += '</div>';
          }
        }
        else if (tab === 'benessere') {
          page += renderBenessereTab(me, pt);
        }

        var ovHtml = overlay ? renderOverlay() : (showOB ? renderOnboarding() : '');
        var h = '<div class="app">';
        h += '<div class="page' + (tab === 'home' ? ' home-page' : '') + '" ' + (tab === 'home' ? 'style="padding-top:0;display:block"' : '') + '>' + page + '</div>';
        h += '<div class="bnav">';
        h += '<button class="ni' + (tab === 'home' ? ' on' : '') + '" data-action="set-tab" data-arg="home"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg><span>Home</span></button>';
        h += '<button class="ni' + (tab === 'shop' ? ' on' : '') + '" data-action="set-tab" data-arg="shop"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg><span>Shop</span></button>';
        h += '<button class="ni' + (tab === 'giochi' ? ' on' : '') + '" data-action="set-tab" data-arg="giochi"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2" ry="2"></rect><line x1="6" y1="12" x2="10" y2="12"></line><line x1="8" y1="10" x2="8" y2="14"></line><circle cx="15" cy="12" r="1"></circle><circle cx="17" cy="10" r="1"></circle></svg><span>Giochi</span></button>';
        h += '<button class="ni' + (tab === 'execute' ? ' on' : '') + '" data-action="set-tab" data-arg="execute" style="position:relative"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"></polyline><rect x="2" y="7" width="20" height="5"></rect><line x1="12" y1="22" x2="12" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path></svg><span>Ordini</span>' + (hasBadge ? '<div class="ni-dot"></div>' : '') + '</button>';
        h += '<button class="ni' + (tab === 'benessere' ? ' on' : '') + '" data-action="set-tab" data-arg="benessere"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78v0z"></path></svg><span>Benessere</span></button>';
        h += '</div>' + ovHtml + (toast ? '<div class="toast">' + toast + '</div>' : '') + '</div>';
        return h;
      }

      /* ── COMPONENTS ── */
      function renderHomeHeader(me, pts, u) {
        var hr = new Date().getHours();
        var greeting = (hr >= 5 && hr < 17) ? 'Buongiorno' : 'Buonasera';
        var dAgo = u.lastRewardClaim ? daysAgo(u.lastRewardClaim) : 0;

        var h = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
        h += '<div><div style="font-size:.85rem;color:#6b7080;font-weight:600;margin-bottom:2px">' + greeting + '</div>';
        h += '<div style="font-size:1.5rem;font-weight:800;color:#1a1f36;">' + esc(pname(me)) + '</div></div>';
        h += '<div style="display:flex;gap:12px;align-items:center;">';
        h += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:4px"><span style="color:#7eb3f5">🔷</span> ' + pts + ' pt</div>';
        h += '<button style="width:36px;height:36px;border-radius:50%;background:#e2e8f0;border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--b3)" data-action="logout"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button>';
        h += '</div></div>';

        if (!u.lastRewardClaim) {
          h += '<div style="margin-bottom:16px;background:#fff;border:1px solid #e0eaf8;border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.03)" onclick="document.querySelector(\'[data-arg=shop]\').click()">';
          h += '<div style="font-size:2rem;line-height:1">🛍️</div>';
          h += '<div><div style="font-size:.9rem;font-weight:800;color:#1a2a5e;margin-bottom:4px">Benvenuto nello Shop!</div><div style="font-size:.75rem;color:var(--b3);line-height:1.4">Fai il tuo <strong>primo acquisto</strong> per sbloccare l\'analisi clinica.</div></div>';
          h += '</div>';
        } else if (dAgo >= 3) {
          h += '<div style="margin-bottom:16px;background:rgba(231,76,60,0.1);border:1px solid rgba(231,76,60,0.3);border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;" onclick="document.querySelector(\'[data-arg=shop]\').click()">';
          h += '<div style="font-size:2rem;line-height:1">🚨</div>';
          h += '<div><div style="font-size:.9rem;font-weight:800;color:#c0392b;margin-bottom:4px">Penalità Imminente!</div><div style="font-size:.75rem;color:#e74c3c;line-height:1.4">Sfogli lo <strong>Shop</strong> e acquista qualcosa per disinnescare la penalità!</div></div>';
          h += '</div>';
        } else if (dAgo === 2) {
          h += '<div style="margin-bottom:16px;background:rgba(243,156,18,0.1);border:1px dashed rgba(243,156,18,0.4);border-radius:16px;padding:12px;text-align:center;cursor:pointer;font-size:.8rem;color:#d68910;font-weight:700" onclick="document.querySelector(\'[data-arg=shop]\').click()">';
          h += '⏳ Sei a quota 2 giorni senza acquisti. Rimedia prima della penalità!';
          h += '</div>';
        }
        return h;
      }

      function renderFlashSaleWidget() {
        var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
        var myRewards = S.rewards.filter(function (r) { return r.partner === session || r.partner === 'both'; });
        var fSales = [];
        if (myRewards.length > 0) {
          var a = myRewards.slice();
          var seed = epoch;
          for (var i = a.length - 1; i > 0; i--) {
            var x = Math.sin(seed++) * 10000;
            var rNum = x - Math.floor(x);
            var j = Math.floor(rNum * (i + 1));
            var t = a[i]; a[i] = a[j]; a[j] = t;
          }
          fSales = a.slice(0, 3);
        }
        if (!fSales.length) return '';

        var hrsLeft = 5 - (Math.floor(Date.now() / 3600000) % 5);
        var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
        h += '<div style="font-weight:800;color:#1a1f36;font-size:.9rem">Flash Sale</div>';
        h += '<div style="font-size:.7rem;color:#c04020;background:#ffe8e0;font-weight:800;padding:4px 10px;border-radius:12px">Scade tra ' + hrsLeft + 'h</div>';
        h += '</div>';

        h += '<div style="display:flex;gap:12px;overflow-x:auto;padding-bottom:15px;margin-bottom:16px;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;">';
        var fSeed = epoch;
        fSales.forEach(function (fs) {
          var fx = Math.sin(fSeed++) * 10000;
          var dscPct = (fx - Math.floor(fx)) > 0.5 ? 0.10 : 0.05;
          var dscCost = Math.floor(fs.cost * (1 - dscPct));
          var descText = fs.desc || 'Premio in sconto da non perdere!';

          h += '<div style="flex:0 0 160px;scroll-snap-align:start;background:#ffffff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;position:relative;box-shadow:0 6px 12px rgba(0,0,0,0.03);display:flex;flex-direction:column;min-height:220px;" data-action="open-claim" data-arg="' + fs.id + '" data-arg2="' + dscCost + '">';
          h += '<div style="position:absolute;top:12px;right:12px;background:#c04020;color:#fff;font-size:.75rem;font-weight:800;padding:3px 8px;border-radius:8px">-' + (dscPct * 100) + '%</div>';
          h += '<div style="font-size:2rem;margin-bottom:10px">' + (fs.emoji || '🎁') + '</div>';
          h += '<div style="font-size:.85rem;font-weight:800;color:#1a1f36;margin-bottom:4px;line-height:1.2;flex-shrink:0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(fs.name) + '</div>';
          h += '<div style="font-size:.7rem;color:#b0b4c0;line-height:1.3;margin-bottom:10px;flex:1;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical">' + esc(descText) + '</div>';
          h += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px">';
          h += '<div style="font-size:1.1rem;font-weight:900;color:#1a1f36"><span style="color:#378add">🔷</span> ' + dscCost + '</div>';
          h += '<div style="font-size:.7rem;color:#b0b4c0;text-decoration:line-through">' + fs.cost + '</div>';
          h += '</div>';
          h += '<button style="width:100%;background:#1a2a5e;color:white;border:none;padding:10px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;pointer-events:none">Acquista ora</button>';
          h += '</div>';
        });
        h += '</div>';
        return h;
      }

      function renderLastOrderWidget(myReqs) {
        var allMe = myReqs.slice().reverse();
        if (allMe.length === 0) return '';
        var lr = allMe[0];

        var s = lr.status;
        var bc = s === 'pending' ? 'badge-wait' : s === 'done' ? 'badge-ok' : s === 'done_confirm' ? 'badge-conf' : 'badge-exp';

        var bt = s === 'pending' ? '⏳ Lavorazione' : s === 'done' ? '✅ Consegnato' : s === 'done_confirm' ? '🔔 Conferma' : '⏰ Scaduto';
        var badgeStyleText = '';
        if (s === 'done') {
          badgeStyleText = 'background:#e6f7ee;color:#1a7a4a;border:none;padding:4px 10px;border-radius:12px;font-size:.65rem;font-weight:700;';
        } else {
          badgeStyleText = 'font-size:.65rem;padding:3px 8px;';
        }

        var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;margin-bottom:12px">';
        h += '<div style="font-weight:800;color:#1a1f36;font-size:.9rem">Ultimo ordine</div>';
        h += '<button style="background:none;border:none;color:#378add;font-size:.75rem;font-weight:700;cursor:pointer" data-action="set-tab" data-arg="execute">Storico →</button>';
        h += '</div>';

        h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
        h += '<div style="display:flex;gap:14px;align-items:center;margin-bottom:16px">';
        h += '<div style="width:48px;height:48px;background:#eef3fb;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">' + (lr.emoji || '🎁') + '</div>';
        h += '<div style="flex:1;overflow:hidden">';
        h += '<div style="font-size:.85rem;font-weight:800;color:#1a1f36;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(lr.name) + '</div>';
        h += '<div style="font-size:.7rem;color:var(--muted);margin-bottom:6px">' + fmtDt(lr.requestedAt) + '</div>';
        h += '<span class="ar-badge ' + bc + '" style="' + badgeStyleText + '">' + bt + '</span>';
        h += '</div>';
        h += '</div>';
        h += '<button style="width:100%;background:#f4f6fc;color:#1a2a5e;border:none;padding:12px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;cursor:pointer" data-action="view-order" data-arg="' + esc(lr.id) + '" data-arg2="0">Vedi dettaglio ordine →</button>';
        h += '</div>';
        return h;
      }

      function renderGamesCTA() {
        var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
        h += '<div style="font-weight:800;color:#1a1f36;font-size:.9rem">Mini-giochi e quiz</div>';
        h += '<div style="font-size:.7rem;color:#6c3fc4;background:#f0eaff;font-weight:800;padding:4px 10px;border-radius:12px">Novità</div>';
        h += '</div>';

        h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:20px;position:relative;overflow:hidden;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
        h += '<div style="position:absolute;top:-40px;right:-40px;width:150px;height:150px;background:#f4f0ff;border-radius:50%;z-index:0"></div>';
        h += '<div style="position:relative;z-index:1">';
        h += '<div style="font-size:1.8rem;margin-bottom:12px">🎮</div>';
        h += '<div style="font-size:.95rem;font-weight:800;color:#1a1f36;margin-bottom:6px">Mini-giochi e quiz</div>';
        h += '<div style="font-size:.75rem;color:var(--muted);line-height:1.4;margin-bottom:16px">Gioca ai divertenti mini-giochi, rispondi ai quiz e accumula punti extra da spendere nello shop.</div>';
        h += '<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">';
        h += '<button style="background:#1a2a5e;color:white;border:none;padding:10px 16px;border-radius:12px;font-size:.8rem;font-weight:700;cursor:pointer" onclick="showToast(\'In arrivo prossimamente!\')">Scopri i giochi →</button>';
        h += '<div style="font-size:.75rem;color:#6c3fc4;font-weight:800;background:#f4f0ff;padding:6px 10px;border-radius:10px">✦ +pt bonus</div>';
        h += '</div></div></div>';
        return h;
      }

      function getActivityCountToday() {
        var count = 0;
        ALL_ACTIVITY_HOURS.forEach(function (h) {
          var slotKey = new Date().getFullYear() + '-' + new Date().getMonth() + '-' + new Date().getDate() + '-' + h;
          if (localStorage.getItem('fq_done_' + session + '_' + slotKey) === 'answered') count++;
        });
        return count;
      }

      function getLifetimeIntimacyCount() {
        return S.requests.filter(function (r) { return r.status === 'done'; }).length;
      }

      function getWeeklyIntimacyStats(me) {
        var stats = { me: 0, pt: 0, total: 0 };
        var now = new Date();
        S.requests.forEach(function (r) {
          if (r.status === 'done' || r.status === 'done_confirm') {
            var dStr = r.confirmedAt || r.doneAt || r.ts;
            if (dStr) {
              var diffDays = (now - new Date(dStr)) / (1000 * 60 * 60 * 24);
              if (diffDays <= 7) {
                if (r.by === me) stats.me++;
                else stats.pt++;
                stats.total++;
              }
            }
          }
        });
        return stats;
      }

      function getExtendedBenessereStats(me) {
        var now = new Date();
        var reqs = S.requests.filter(function (r) { return r.status === 'done' || r.status === 'done_confirm'; });

        var wCount = 0, mCount = 0, prevMCount = 0;
        var myCount = 0, ptCount = 0;
        var items = {};
        var weeksMap = {};

        reqs.forEach(function (r) {
          var dStr = r.confirmedAt || r.doneAt || r.ts;
          if (!dStr) return;
          var d = new Date(dStr);
          var diffDays = (now - d) / (1000 * 60 * 60 * 24);

          if (diffDays <= 7) {
            wCount++;
            if (r.by === me) myCount++; else ptCount++;
          }
          if (diffDays <= 30) mCount++;
          else if (diffDays <= 60) prevMCount++;

          var wIdx = Math.floor(diffDays / 7);
          weeksMap[wIdx] = (weeksMap[wIdx] || 0) + 1;

          items[r.rewardName || 'Varie'] = true;
        });

        var streak = 0;
        if (!weeksMap[0] && weeksMap[1]) {
          for (var j = 1; j < 52; j++) {
            if (weeksMap[j] > 0) streak++; else break;
          }
        } else if (weeksMap[0]) {
          for (var i = 0; i < 52; i++) {
            if (weeksMap[i] > 0) streak++;
            else break;
          }
        }

        var trend = mCount - prevMCount;
        var variety = Object.keys(items).length;

        return {
          w: wCount, m: mCount, prevM: prevMCount,
          my: myCount, pt: ptCount,
          streak: streak,
          trend: trend,
          variety: variety,
          total: reqs.length
        };
      }

      function renderBenessereTab(me, pt) {
        var xStats = getExtendedBenessereStats(me);
        var wCount = xStats.w;
        var mCount = xStats.m;
        var totalCount = xStats.total;

        var evalColor, evalTitle, phaseDesc;
        var trendStr = '';

        if (xStats.trend > 0) trendStr = '📈 In crescita vs mese scorso';
        else if (xStats.trend < 0) trendStr = '📉 In calo vs mese scorso';
        else trendStr = '⚖️ Frequenza stabile';

        if (wCount === 0 && xStats.streak === 0) {
          evalColor = '#ffb6c1';
          evalTitle = 'Fase: Riscoperta 🌱';
          phaseDesc = 'Ogni periodo di pausa è un\'opportunità straordinaria per sorprendersi a vicenda da zero e creare un impatto emotivo ancora più forte.';
        } else if (wCount >= 2 && xStats.streak >= 2) {
          evalColor = '#88ffb0';
          evalTitle = 'Fase: Luna di Miele Attiva 🍯';
          phaseDesc = 'Siete in perfetta sintonia ritmica! Continuate a mixare i regali nello Shop per mantenere questa incredibile energia e passione ad altissimi livelli.';
        } else {
          evalColor = '#ffcc66';
          evalTitle = 'Fase: Consolidamento 🤝';
          phaseDesc = 'State costruendo fondamenta chimiche molto stabili. Usate l\'app per variare la routine, basta una piccolissima sorpresa per svoltare la serata!';
        }

        var h = '<div class="head" style="margin-bottom:15px"><h2>Benessere di Coppia</h2><p>Dati e insight scientifici sulle vostre affinità</p></div>';

        h += '<div class="sec-label">📊 Metriche di Costanza</div>';
        h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">';

        h += '<div style="background:var(--surface);border-radius:16px;padding:16px;border:1px solid #e0eaf8;text-align:center">';
        h += '<div style="font-size:2.2rem;font-weight:800;color:var(--b3);line-height:1;margin-bottom:4px;font-family:\'Playfair Display\',serif">' + mCount + '</div>';
        h += '<div style="font-size:.7rem;font-weight:700;color:var(--muted);text-transform:uppercase">Ordini 30 Giorni</div>';
        h += '<div style="font-size:.65rem;color:' + (xStats.trend < 0 ? 'var(--muted)' : 'var(--green)') + ';margin-top:6px">' + trendStr + '</div>';
        h += '</div>';

        h += '<div style="background:var(--surface);border-radius:16px;padding:16px;border:1px solid #e0eaf8;text-align:center">';
        h += '<div style="font-size:2.2rem;font-weight:800;color:var(--b3);line-height:1;margin-bottom:4px;font-family:\'Playfair Display\',serif">' + xStats.streak + '<span style="font-size:1rem;color:var(--muted);font-family:\'DM Sans\',sans-serif"> sett.</span></div>';
        h += '<div style="font-size:.7rem;font-weight:700;color:var(--muted);text-transform:uppercase">Streak Consecutivi</div>';
        var aboveAvg = xStats.streak > 2;
        h += '<div style="font-size:.65rem;color:' + (aboveAvg ? 'var(--green)' : 'var(--b4)') + ';margin-top:6px">' + (aboveAvg ? 'Sopra la media (+2 sett)' : 'Media coppie simili: 2 sett.') + '</div>';
        h += '</div>';
        h += '</div>';

        h += '<div style="margin-bottom:24px;background:linear-gradient(135deg,#8a2846,#4a152e);border-radius:24px;padding:24px;color:white;position:relative;overflow:hidden;box-shadow:0 12px 24px rgba(138,40,70,0.15)">';
        h += '<div style="font-size:.7rem;opacity:.8;text-transform:uppercase;letter-spacing:.08em;font-weight:700;margin-bottom:6px">Analisi Emotiva</div>';
        h += '<div style="font-family:\'Playfair Display\',serif;font-size:1.7rem;font-weight:800;color:' + evalColor + ';line-height:1.2;margin-bottom:10px">' + evalTitle + '</div>';
        h += '<div style="font-size:.85rem;opacity:.95;line-height:1.45;margin-bottom:18px">' + phaseDesc + '</div>';
        h += '<div style="background:rgba(255,150,180,0.15);padding:12px 14px;border-radius:14px;font-size:.75rem;display:flex;align-items:center;gap:12px">';
        h += '<span style="font-size:1.6rem">🎯</span> <span style="line-height:1.4"><strong>Sfida di questa settimana:</strong><br/>' + (xStats.variety < 3 ? 'La routine ha preso piede. Osate acquistando un premio completamente esotico che non avete mai provato!' : 'Avete un\'ottima varietà! Provate a piazzare un ordine nel momento più imprevedibile della giornata.') + '</span>';
        h += '</div>';
        h += '</div>';

        var mood = (xStats.streak >= 2) ? 'Radioso ✨' : ((wCount >= 1) ? 'In Miglioramento 🍃' : 'In cerca di stimoli 💭');
        var sleep = (wCount >= 2) ? 'Profondo (stima 85%) 💤' : 'Variabile (stima 70%) 🛌';
        var stress = (mCount >= 4) ? 'Basso, in rilascio 🧘' : 'In moderato accumulo 🔋';

        h += '<div class="sec-label">🧠 Impatto Fisiologico e Sonno (AI est.)</div>';
        h += '<div style="background:#fff;border-radius:16px;padding:16px 20px;margin-bottom:24px;border:1px solid #e0eaf8">';

        h += '<div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #f0f4f8;padding-bottom:14px;margin-bottom:14px">';
        h += '<div style="font-size:.85rem;font-weight:600;color:var(--b3)"><span style="margin-right:8px;font-size:1.1rem">🎭</span>Umore di Coppia</div>';
        h += '<div style="font-size:.8rem;color:var(--b5);font-weight:700">' + mood + '</div>';
        h += '</div>';

        h += '<div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #f0f4f8;padding-bottom:14px;margin-bottom:14px">';
        h += '<div style="font-size:.85rem;font-weight:600;color:var(--b3)"><span style="margin-right:8px;font-size:1.1rem">⌚</span>Qualità Sonno REM</div>';
        h += '<div style="font-size:.8rem;color:var(--b5);font-weight:700">' + sleep + '</div>';
        h += '</div>';

        h += '<div style="display:flex;justify-content:space-between;align-items:center">';
        h += '<div style="font-size:.85rem;font-weight:600;color:var(--b3)"><span style="margin-right:8px;font-size:1.1rem">📉</span>Livello Cortisolo</div>';
        h += '<div style="font-size:.8rem;color:var(--b5);font-weight:700">' + stress + '</div>';
        h += '</div>';
        h += '</div>';

        var alignPct = 0;
        var minPart = 0, maxPart = 1;
        if (totalCount > 0) {
          minPart = Math.min(xStats.my, xStats.pt);
          maxPart = Math.max(xStats.my, xStats.pt, 1);
          alignPct = Math.round((minPart / maxPart) * 100);
        }

        var alignText = '';
        if (totalCount === 0) alignText = 'Siete all\'inizio della vostra avventura. Scoprite la gioia di sorprendervi.';
        else if (alignPct >= 80) alignText = 'Sincronizzazione perfetta! Ognuno dà esattamente ciò che riceve dall\'altro.';
        else if (alignPct >= 40) alignText = 'Ottima dinamica, ma sembra che uno dei due giochi più in attacco! Chi riequilibrerà i ruoli?';
        else alignText = 'Dinamica sbilanciata. L\'amore è reciprocità: sorprendi il tuo partner per ringraziarlo!';

        h += '<div class="sec-label">💞 Bilancio Relazionale ("Iniziative")</div>';
        h += '<div style="background:#fff;border-radius:18px;padding:20px;margin-bottom:24px;border:1px solid #e0eaf8">';

        h += '<div style="display:flex;align-items:center;gap:18px;margin-bottom:18px">';
        h += '<div style="width:68px;height:68px;flex-shrink:0;border-radius:50%;background:conic-gradient(var(--b4) ' + alignPct + '%, var(--surface) 0);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,0.05)">';
        h += '<div style="width:54px;height:54px;background:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:800;color:var(--b3)">' + alignPct + '%</div>';
        h += '</div>';
        h += '<div style="flex:1">';
        h += '<div style="font-size:.9rem;font-weight:800;color:var(--b3);margin-bottom:4px">Indice Allineamento</div>';
        h += '<div style="font-size:.72rem;color:var(--muted);line-height:1.45">' + alignText + '</div>';
        h += '</div>';
        h += '</div>';

        h += '<div style="background:linear-gradient(to right, rgba(235,240,255,0.8), rgba(240,230,250,0.8));border-radius:14px;padding:14px;display:flex;justify-content:space-between;align-items:center;border:1px solid #e2dcf4">';
        h += '<div style="font-size:.75rem;color:var(--b3);font-weight:700">Traguardo in corso</div>';
        var nextTarget = (Math.floor(xStats.total / 10) + 1) * 10;
        var left = nextTarget - xStats.total;
        if (xStats.total === 0) h += '<div style="font-size:.75rem;color:var(--purple);font-weight:800">1° ordine insieme! 🔥</div>';
        else h += '<div style="font-size:.75rem;color:var(--purple);font-weight:800">Mancano ' + left + ' ai ' + nextTarget + ' ordini!</div>';
        h += '</div>';

        h += '</div>';

        var myW = 0, ptW = 0;
        var now = new Date();
        S.requests.forEach(function (r) {
          if (r.status === 'done' || r.status === 'done_confirm') {
            var dStr = r.confirmedAt || r.doneAt || r.ts;
            if (dStr) {
              if ((now - new Date(dStr)) / 86400000 <= 7) {
                if (r.by === me) myW++; else ptW++;
              }
            }
          }
        });

        var thresholds = [0, 3, 5, 7, 10, 14];
        var myLvlId = 0, ptLvlId = 0;
        for (var i = 5; i >= 0; i--) if (myW >= thresholds[i]) { myLvlId = i; break; }
        for (var i = 5; i >= 0; i--) if (ptW >= thresholds[i]) { ptLvlId = i; break; }

        var lvls = [
          { id: 0, name: 'Esplorazione', range: '0-2 ordini/settimana', sub: 'Inizia il viaggio', icon: '☁️', color: '#95a5a6', bg: '#f4f6f7', badges: [{ t: 'Sblocca Lv 1 con 3 ordini', c: '#f4f6f7', tc: '#7f8c8d', bc: '#d0d0d0' }], prog: 0 },
          { id: 1, name: 'Germoglio', range: '3-4 ordini/settimana', sub: '≈ 1 ogni 2 giorni', icon: '🌱', color: '#2ecc71', bg: '#edfbf3', badges: [{ t: 'Soglia minima', c: '#edfbf3', tc: '#1a9e50', bc: '#a9dfbf' }, { t: 'Streak 1+ settimana', c: '#edfbf3', tc: '#1a9e50', bc: '#a9dfbf' }, { t: 'Varietà bassa', c: '#f0f4f8', tc: '#4a6080', bc: '#d0daf0' }], prog: 20 },
          { id: 2, name: 'Scintilla', range: '5-6 ordini/settimana', sub: 'quasi 1 al giorno', icon: '⚡', color: '#8b5cf6', bg: '#f5f0ff', badges: [{ t: 'Sopra la media', c: '#f5f0ff', tc: '#6d28d9', bc: '#d7bde2' }, { t: 'Streak 2+ settimane', c: '#f5f0ff', tc: '#6d28d9', bc: '#d7bde2' }, { t: 'IgA in crescita', c: '#edfbf3', tc: '#1a9e50', bc: '#a9dfbf' }], prog: 40 },
          { id: 3, name: 'Fiamma', range: '7-9 ordini/settimana', sub: '1 al giorno o più', icon: '🔥', color: '#f39c12', bg: '#fdf3e6', badges: [{ t: 'Top 20% coppie IT', c: '#fdf3e6', tc: '#b9770e', bc: '#f5cba7' }, { t: 'Streak 4+ settimane', c: '#fdf3e6', tc: '#b9770e', bc: '#f5cba7' }, { t: 'Cortisolo ridotto', c: '#f5f0ff', tc: '#6d28d9', bc: '#d7bde2' }], prog: 60 },
          { id: 4, name: 'Cristallo', range: '10-13 ordini/settimana', sub: 'media 1,5/giorno', icon: '💎', color: '#e74c3c', bg: '#fdedec', badges: [{ t: 'Top 10% coppie IT', c: '#fdedec', tc: '#c0392b', bc: '#f5b7b1' }, { t: 'Streak 8+ settimane', c: '#fdedec', tc: '#c0392b', bc: '#f5b7b1' }, { t: 'Varietà alta', c: '#fdf3e6', tc: '#b9770e', bc: '#f5cba7' }], prog: 80 },
          { id: 5, name: 'Leggenda', range: '14+ ordini/settimana', sub: '2+ al giorno', icon: '👑', color: '#3a5ca8', bg: '#f0f5ff', badges: [{ t: 'Top 5% coppie IT', c: '#f0f5ff', tc: '#1e3060', bc: '#a9cce3' }, { t: 'Ossitocina massima', c: '#edfbf3', tc: '#1a9e50', bc: '#a9dfbf' }, { t: 'Streak 12+ settimane', c: '#fdf3e6', tc: '#b9770e', bc: '#f5cba7' }, { t: 'Varietà premium', c: '#fdedec', tc: '#c0392b', bc: '#f5b7b1' }], prog: 100 }
        ];

        h += '<div class="lvl-wrap">';
        h += '<div class="sec-label" style="text-transform:uppercase;color:var(--muted)">Il Tuo Livello di Attività</div>';

        var lMe = lvls[myLvlId];
        h += '<div class="lvl-card active">';
        h += '<div class="lvl-header"><div class="lvl-icon" style="color:' + lMe.color + ';border:2px solid ' + lMe.color + ';background:' + lMe.bg + '">' + lMe.icon + '</div>';
        h += '<div class="lvl-info"><div class="lvl-title">Livello ' + (lMe.id > 0 ? lMe.id : 'base') + ' — ' + lMe.name + '</div><div class="lvl-sub">' + lMe.range + ' · ' + lMe.sub + '</div>';
        h += '<div class="lvl-badges">';
        lMe.badges.forEach(function (b) {
          h += '<span class="lvl-badge" style="background:' + b.c + ';color:' + b.tc + ';border-color:' + b.bc + '">' + b.t + '</span>';
        });
        h += '</div></div></div>';

        if (myLvlId < 5) {
          var nextL = lvls[myLvlId + 1];
          var left = thresholds[myLvlId + 1] - myW;
          var pct = Math.round(((myW - thresholds[myLvlId]) / (thresholds[myLvlId + 1] - thresholds[myLvlId])) * 100);
          if (myLvlId === 0) pct = Math.round((myW / 3) * 100);
          h += '<div class="lvl-prog-track" style="margin-bottom:8px;height:6px"><div class="lvl-prog-fill" style="width:' + pct + '%;background:' + lMe.color + '"></div></div>';
          h += '<div style="font-size:.78rem;color:var(--b4);text-align:right">🚀 Fai altri <strong>' + left + ' ' + (left == 1 ? 'ordine' : 'ordini') + '</strong> per sbloccare <strong>Lv ' + (myLvlId + 1) + ' ' + nextL.name + '</strong>!</div>';
        } else {
          h += '<div class="lvl-prog-track" style="margin-bottom:8px;height:6px"><div class="lvl-prog-fill" style="width:100%;background:' + lMe.color + '"></div></div>';
          h += '<div style="font-size:.78rem;color:var(--b4);text-align:right">Hai raggiunto il livello massimo! 👑</div>';
        }
        h += '</div>';

        h += '<div class="sec-label" style="text-transform:uppercase;color:var(--muted);margin-top:20px">Livello di ' + esc(pname(pt)) + '</div>';
        var lPt = lvls[ptLvlId];
        h += '<div class="lvl-card" style="opacity:0.95">';
        h += '<div class="lvl-header" style="margin-bottom:8px"><div class="lvl-icon" style="color:' + lPt.color + ';border:2px solid ' + lPt.color + ';background:' + lPt.bg + '">' + lPt.icon + '</div>';
        h += '<div class="lvl-info"><div class="lvl-title">Livello ' + (lPt.id > 0 ? lPt.id : 'base') + ' — ' + lPt.name + '</div><div class="lvl-sub" style="margin-bottom:4px">' + lPt.range + '</div>';
        h += '<div class="lvl-badges">';
        lPt.badges.forEach(function (b) {
          h += '<span class="lvl-badge" style="background:' + b.c + ';color:' + b.tc + ';border-color:' + b.bc + '">' + b.t + '</span>';
        });
        h += '</div></div></div>';

        if (ptLvlId < 5) {
          var ptPct = Math.round(((ptW - thresholds[ptLvlId]) / (thresholds[ptLvlId + 1] - thresholds[ptLvlId])) * 100);
          if (ptLvlId === 0) ptPct = Math.round((ptW / 3) * 100);
          h += '<div class="lvl-prog-track"><div class="lvl-prog-fill" style="width:' + ptPct + '%;background:' + lPt.color + '"></div></div>';
        } else {
          h += '<div class="lvl-prog-track"><div class="lvl-prog-fill" style="width:100%;background:' + lPt.color + '"></div></div>';
        }
        h += '</div>';

        h += '</div>';

        var month = new Date().getMonth();
        var seasonText = '';
        if (month >= 2 && month <= 4) seasonText = '🌸 <strong>Primavera Rivelata:</strong> Le energie si risvegliano naturalmente, ottimo momento per alzare i battiti ed esplorare nuove sfaccettature della coppia.';
        else if (month >= 5 && month <= 7) seasonText = '☀️ <strong>Calore Estivo:</strong> Le alte temperature serali possono indurre inerzia fisiologica. Sfruttate le fresche mattinate del weekend!';
        else if (month >= 8 && month <= 10) seasonText = '🍂 <strong>Autunno Romantico:</strong> Con i primi freddi, la ricerca neurologica di calore umano e coccole si impenna. Assecondate questo istinto formidabile.';
        else seasonText = '❄️ <strong>Rifugio Invernale:</strong> Il sistema immunitario viene provato. È scientificamente provato che i momenti di vicinanza creano i perfetti anticorpi emotivi e fisici.';

        h += '<div style="text-align:center;padding:10px 20px 30px">';
        h += '<div style="font-size:.7rem;color:var(--muted);letter-spacing:.06em;text-transform:uppercase;font-weight:700;margin-bottom:10px">Insight Stagionale del Mese</div>';
        h += '<div style="font-size:.78rem;color:var(--b4);line-height:1.5">' + seasonText + '</div>';
        h += '</div>';

        return h;
      }

      function renderMandatoryAlert() {
        return '<div class="mandatory-alert"><h4>⚠️ Fai un nuovo ordine!</h4><p>Sono passati 3+ giorni dall\'ultimo acquisto. Se non spendi i tuoi punti oggi, perdi 500 punti per inattività commerciale.<br>Vai allo <strong>Shop</strong>.</p></div>';
      }

      /* Pure DOM toggle — no render(), no scroll jump */
      function toggleAcc(idx, triggerEl) {
        var card = triggerEl;
        while (card && !card.classList.contains('card')) card = card.parentElement;
        if (!card) return;
        var rows = card.querySelectorAll('.acc-row');
        rows.forEach(function (row, i) {
          if (i === idx) {
            row.classList.toggle('open');
          } else {
            row.classList.remove('open'); // close others
          }
        });
      }

      function renderWellnessWidget(me) {
        var xStats = getExtendedBenessereStats(me);
        var streak = xStats.streak;
        var mCount = xStats.m;

        var thresholds = [0, 3, 5, 7, 10, 14];
        var lvls = ['Esplorazione', 'Germoglio', 'Scintilla', 'Fiamma', 'Cristallo', 'Leggenda'];
        var myW = xStats.w;
        var lvlId = 0;
        for (var i = 5; i >= 0; i--) if (myW >= thresholds[i]) { lvlId = i; break; }

        var nextLvlText = lvlId < 5 ? lvls[lvlId + 1] : 'Max';
        var progVal = lvlId < 5 ? (myW - thresholds[lvlId]) : 1;
        var progMax = lvlId < 5 ? (thresholds[lvlId + 1] - thresholds[lvlId]) : 1;
        if (lvlId === 0) { progVal = myW; progMax = 3; }
        var pct = Math.floor((progVal / progMax) * 100);

        var subText = lvlId === 0 ? 'Ottimo Inizio, continuate così!' : (lvlId > 2 ? 'Siete in perfetta sintonia! 🔥' : 'Avete un bel ritmo, continuate così!');

        var h = '<div style="background:#1a2a5e;border-radius:20px;padding:20px;color:white;margin-bottom:24px;box-shadow:0 12px 24px rgba(26,42,94,0.2)">';
        h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">';
        h += '<span style="font-size:.7rem;font-weight:700;color:#8fa8d8;letter-spacing:.05em">IL TUO PROGRESSO</span>';
        h += '<span style="font-size:.7rem;background:rgba(255,255,255,0.10);padding:4px 10px;border-radius:12px;font-weight:600;color:white">' + xStats.w + '/sett.</span>';
        h += '</div>';
        h += '<div style="font-size:1.05rem;font-weight:800;color:#e8edf8;font-family:\'Playfair Display\',serif;margin-bottom:20px">' + subText + '</div>';

        h += '<div style="display:flex;gap:10px;margin-bottom:20px">';
        h += '<div style="flex:1;background:rgba(255,255,255,0.07);border-radius:12px;padding:12px;text-align:center">';
        h += '<div style="font-size:1.2rem;font-weight:800;color:white;margin-bottom:4px">' + streak + '</div>';
        h += '<div style="font-size:.65rem;color:#8fa8d8;line-height:1.2">Streak<br>sett.</div>';
        h += '</div>';
        h += '<div style="flex:1;background:rgba(255,255,255,0.07);border-radius:12px;padding:12px;text-align:center">';
        h += '<div style="font-size:1.2rem;font-weight:800;color:#7ee8b0;margin-bottom:4px">' + mCount + '</div>';
        h += '<div style="font-size:.65rem;color:#8fa8d8;line-height:1.2">Ordini<br>30G</div>';
        h += '</div>';
        h += '<div style="flex:1;background:rgba(255,255,255,0.07);border-radius:12px;padding:12px;text-align:center">';
        h += '<div style="font-size:1.2rem;font-weight:800;color:#f8c97a;margin-bottom:4px">Lv ' + lvlId + '</div>';
        h += '<div style="font-size:.65rem;color:#8fa8d8;line-height:1.2">Livello<br>attuale</div>';
        h += '</div>';
        h += '</div>';

        h += '<div style="display:flex;justify-content:space-between;align-items:center;font-size:.75rem;color:#8fa8d8;margin-bottom:8px">';
        h += '<span>Prossimo livello: <strong style="color:white">' + nextLvlText + '</strong></span>';
        h += '<span>' + progVal + '/' + progMax + '</span>';
        h += '</div>';
        h += '<div style="height:6px;background:rgba(255,255,255,0.15);border-radius:3px;margin-bottom:16px;overflow:hidden"><div style="height:100%;width:' + pct + '%;background:#7eb3f5;border-radius:3px"></div></div>';
        h += '<div style="text-align:right"><button style="background:none;border:none;color:#7eb3f5;font-size:.75rem;font-weight:700;font-family:sans-serif;cursor:pointer" data-action="set-tab" data-arg="benessere">Analisi completa →</button></div>';

        h += '</div>';
        return h;
      }

      function getFlashSaleInfo(itemId) {
  var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
  var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
  var fSales = [];
  if (myRewards.length > 0) {
    var a = myRewards.slice();
    var seed = epoch;
    for (var i = a.length - 1; i > 0; i--) {
      var x = Math.sin(seed++) * 10000;
      var rNum = x - Math.floor(x);
      var j = Math.floor(rNum * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    fSales = a.slice(0, 3);
  }
  var idx = fSales.findIndex(function(fs){ return fs.id === itemId; });
  if (idx === -1) return null;
  var fSeed = epoch + idx;
  var fx = Math.sin(fSeed) * 10000;
  return (fx - Math.floor(fx)) > 0.5 ? 0.10 : 0.05;
}

function renderShopItem(r, pts) {
  var dscPct = typeof getFlashSaleInfo === "function" ? getFlashSaleInfo(r.id) : null;
  var finalCost = dscPct ? Math.floor(r.cost * (1 - dscPct)) : r.cost;
  var canAfford = pts >= finalCost;
  
  var borderCol = dscPct ? '#f0c8be' : '#e2e8f0';
  var iconBg = dscPct ? '#fff0ec' : '#eef3fb';
  
  var h = '<div style="background:#ffffff;border:1px solid '+borderCol+';border-radius:16px;padding:16px;margin-bottom:12px;display:flex;gap:14px;align-items:center;position:relative">';
  if (dscPct) {
    h += '<div style="position:absolute;top:12px;right:12px;background:#c04020;color:#ffffff;font-size:.7rem;font-weight:800;padding:3px 8px;border-radius:8px">-'+(dscPct*100)+'%</div>';
  }
  h += '<div style="width:54px;height:54px;background:'+iconBg+';border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.8rem;flex-shrink:0">'+(r.emoji||'🛍️')+'</div>';
  h += '<div style="flex:1">';
  h += '<div style="font-size:1.05rem;font-weight:800;color:#1a1f36;margin-bottom:4px">'+esc(r.name)+'</div>';
  if (r.desc) h += '<div style="font-size:.75rem;color:#8a8f9e;line-height:1.4;margin-bottom:10px">'+esc(r.desc)+'</div>';
  
  h += '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px">';
  h += '<div style="display:flex;align-items:center;gap:6px">';
  h += '<div style="font-size:1.05rem;font-weight:900;color:#1a1f36"><span style="color:#378add">🔷</span> '+finalCost+' pt</div>';
  if (dscPct) {
    h += '<div style="font-size:.7rem;color:#b0b4c0;text-decoration:line-through">'+r.cost+'</div>';
  }
  h += '</div>';
  
  if (canAfford) {
    h += '<button style="background:#1a2a5e;color:#ffffff;border:none;padding:8px 16px;border-radius:10px;font-size:.8rem;font-weight:700;cursor:pointer" data-action="open-claim" data-arg="'+esc(r.id)+'" '+(dscPct?'data-arg2="'+finalCost+'"':'')+'>Acquista</button>';
  } else {
    h += '<button style="background:#f0f2f8;color:#a0a8be;border:none;padding:8px 16px;border-radius:10px;font-size:.8rem;font-weight:700;cursor:not-allowed" disabled>Fondi errati</button>';
  }
  h += '</div>';
  h += '</div>';
  h += '</div>';
  return h;
}

      function renderMyReqCard(rr) {
        var s = rr.status;
        var bc = s === 'pending' ? 'badge-wait' : s === 'done' ? 'badge-ok' : s === 'done_confirm' ? 'badge-conf' : 'badge-exp';
        var bt = s === 'pending' ? '⏳ In Lavorazione' : s === 'done' ? '✅ Consegnato' : s === 'done_confirm' ? '🔔 Conferma Ricezione' : '⏰ Scaduto / Annullato';
        var cc = s === 'done_confirm' ? 'ar-card purple' : s === 'done' || s === 'expired' ? 'ar-card grey' : 'ar-card gold';
        var h = '<div class="' + cc + '" style="border:1px solid rgba(0,0,0,0.05)">';
        h += '<div class="ar-header"><div class="ar-title" style="font-weight:700">📦 Ordine ' + (rr.emoji || '') + ' ' + esc(rr.name) + '</div><span class="ar-badge ' + bc + '">' + bt + '</span></div>';
        if (s === 'pending') {
          if (rr.mode === 'deadline' && rr.deadline) h += '<div class="countdown" style="color:#8b5e00">⏱ Consegna stimata tra ' + countdown(rr.deadline) + '</div>';
          else if (rr.mode === 'time' && rr.deadline) h += '<div class="countdown" style="color:#8b5e00">🕐 Consegna schedulata alle ' + fmtTime(rr.deadline) + '</div>';

        }
        var premiumList = rr.premium && rr.premium.length > 0 ? rr.premium
          : (rr.note && rr.note.indexOf('[PREMIUM:') === 0 ? rr.note.replace('[PREMIUM: ', '').replace(']', '').split(', ') : []);
        var plainNote = (!premiumList.length && rr.note) ? rr.note : '';
        if (premiumList.length > 0) {
          h += '<div style="margin-top:10px;padding:10px;background:#fcfaff;border-radius:8px;border:1px dashed #d4c0f8">';
          h += '<div style="font-size:.7rem;font-weight:800;color:var(--purple);margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em">✨ Opzioni Premium:</div>';
          h += '<ul style="margin:0 0 0 18px;padding:0;font-size:.75rem;color:#5b21b6;line-height:1.4">';
          premiumList.forEach(function (p) { h += '<li style="margin-bottom:3px">' + esc(p.trim()) + '</li>'; });
          h += '</ul></div>';
        }
        if (plainNote) h += '<div style="font-size:.75rem;color:#8b6000;margin-top:5px;font-style:italic">Note: "' + esc(plainNote) + '"</div>';
        h += '<div style="font-size:.72rem;color:var(--muted);margin-top:4px">Data acquisto: ' + fmtDt(rr.requestedAt) + '</div>';
        h += '<div style="margin-top:10px;text-align:right"><button style="background:none;border:none;font-size:.75rem;font-weight:700;color:var(--b5);cursor:pointer;font-family:sans-serif;padding:4px 0" data-action="view-order" data-arg="' + esc(rr.id) + '" data-arg2="0">Dettagli ordine →</button></div>';

        if (s === 'pending' || s === 'done_confirm') {
          var confirmTitle = s === 'done_confirm' ? 'Il partner ha segnato come completato. Confermi?' : 'Segnala come è andata a finire:';
          h += '<div class="confirm-box" style="margin-top:10px;background:#fcfaff;border-radius:10px;padding:14px;border:1px solid #d4c0f8;box-shadow:inset 0 4px 10px rgba(139,92,246,0.05)">';
          h += '<p style="font-weight:800;margin-bottom:12px;font-size:.85rem;color:var(--purple);text-align:center;">' + confirmTitle + '</p>';
          h += '<div style="display:flex;flex-direction:column;gap:6px">';
          h += '<button class="btn btn-s btn-sm" style="width:100%;justify-content:center" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="yes">✅ Ricevuto (Nessuna penale)</button>';
          h += '<button class="btn btn-sm" style="width:100%;background:linear-gradient(135deg,#f39c12,#e67e22);color:white;font-weight:700;justify-content:center" data-action="report-late" data-arg="' + esc(rr.id) + '">⏰ Ricevuto in Ritardo (Penale partner -50%)</button>';
          h += '<button class="btn btn-d btn-sm" style="width:100%;justify-content:center" data-action="declare-unfulfilled" data-arg="' + esc(rr.id) + '">🚨 Non Ricevuto (Penale partner -150%)</button>';
          if (s === 'done_confirm') {
            h += '<button class="btn btn-o btn-sm" style="width:100%;justify-content:center;margin-top:4px" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="no">❌ Non Eseguito (Rimanda in attesa)</button>';
          }
          h += '</div></div>';
        } else if (s === 'expired') {
          h += '<div class="confirm-box" style="margin-top:10px;background:rgba(231,76,60,0.06);border-radius:10px;padding:12px;border:1px solid rgba(231,76,60,0.25)">';
          h += '<p style="font-weight:600;margin-bottom:10px;font-size:.8rem;color:var(--red);text-align:center">Questo ordine è annullato. Se il partner lo ha ultimato, puoi chiuderlo in pace qui.</p>';
          h += '<button class="btn btn-s btn-sm" style="width:100%;justify-content:center" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="yes">✅ Alla fine è stato consegnato</button>';
          h += '</div>';
        }
        h += '</div>';
        return h;
      }

      function renderExecCard(rr, showBtn) {
        var h = '<div class="ar-card purple" style="border:1px solid #d8b4e2;background:#faf5fc">';
        h += '<div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px;border-bottom:1px dashed #d8b4e2;padding-bottom:8px">';
        h += '<h4 style="font-family:\'DM Sans\',sans-serif;color:var(--purple);font-size:.9rem;font-weight:700">📦 Ordine #' + rr.id.substring(rr.length > 5 ? rr.length - 5 : 0) + '</h4>';
        h += '<span style="font-size:.65rem;color:#885bb5;font-weight:600;text-transform:uppercase;background:#eaddf2;padding:2px 6px;border-radius:4px">Da Spedire</span>';
        h += '</div>';
        h += '<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">';
        h += '<div style="font-size:2rem;background:#fff;padding:8px;border-radius:10px;box-shadow:0 2px 4px rgba(0,0,0,0.05)">' + (rr.emoji || '🛍️') + '</div>';
        h += '<div><div style="font-weight:700;color:var(--b3);font-size:1.05rem">' + esc(rr.name) + '</div><div style="font-size:.7rem;color:var(--muted)">Cliente: ' + esc(pname(rr.by)) + '</div></div>';
        h += '</div>';

        var rw = S.rewards.find(function (r) { return r.name === rr.name; });
        var orderDesc = rr.desc || (rw ? rw.desc : '');
        if (orderDesc) {
          h += '<div style="margin-bottom:12px;padding:10px;background:rgba(255,255,255,0.6);border-left:3px solid #d8b4e2;border-radius:0 8px 8px 0;font-size:.78rem;color:#5b21b6;line-height:1.4"><strong style="display:block;margin-bottom:2px;font-size:.7rem;text-transform:uppercase;color:#8b5cf6">📝 Descrizione/Note:</strong>' + esc(orderDesc) + '</div>';
        }
        var timeLabel = rr.mode === 'time' ? 'Orario di Consegna:' : 'Consegna Entro il:';
        var timeVal = rr.mode === 'time' ? fmtTime(rr.deadline) : fmtDt(rr.deadline);
        h += '<div style="background:#fff;padding:10px;border-radius:8px;margin-bottom:10px">';
        if (rr.deadline) {
          h += '<div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:.75rem;color:var(--muted)">' + timeLabel + '</span><strong style="font-size:.75rem;color:var(--purple)">' + timeVal + '</strong></div>';
          h += '<div style="display:flex;justify-content:space-between"><span style="font-size:.75rem;color:var(--muted)">Tempo Rimanente:</span><strong style="font-size:.75rem;color:#d32f2f">⏱ ' + countdown(rr.deadline) + '</strong></div>';
          h += '<div style="margin-top:8px;padding-top:8px;border-top:1px solid #f0f0f0">';
          h += '<div style="font-size:.7rem;color:#d32f2f;font-weight:700;margin-bottom:2px">⚠️ Attenzione alle Penali:</div>';
          h += '<ul style="margin:0 0 0 16px;padding:0;font-size:.68rem;color:#b74b4b;line-height:1.4">';
          h += '<li style="margin-bottom:2px"><strong>Ritardo:</strong> Multa del 50% del valore ordine.</li>';
          h += '<li><strong>Inadempienza (> 2h):</strong> Annullamento e Multa del 150%.</li>';
          h += '</ul></div>';
        } else {
          h += '<div style="font-size:.75rem;color:var(--muted)">Entro 30 minuti</div>';
        }
        h += '</div>';
        var premiumList2 = rr.premium && rr.premium.length > 0 ? rr.premium
          : (rr.note && rr.note.indexOf('[PREMIUM:') === 0 ? rr.note.replace('[PREMIUM: ', '').replace(']', '').split(', ') : []);
        var plainNote2 = (!premiumList2.length && rr.note) ? rr.note : '';
        if (plainNote2) h += '<div style="font-size:.75rem;color:#6040a0;margin-bottom:12px;padding:8px;background:rgba(139,94,0,0.05);border-left:3px solid #d8b4e2;font-style:italic">Note: "' + esc(plainNote2) + '"</div>';
        // Pulsante 'Contrassegna Consegnato' rimosso — è il cliente a confermare la ricezione
        h += '<div style="margin-top:10px;text-align:right"><button style="background:none;border:none;font-size:.75rem;font-weight:700;color:var(--b5);cursor:pointer;font-family:sans-serif;padding:4px 0" data-action="view-order" data-arg="' + esc(rr.id) + '" data-arg2="1">Dettagli ordine →</button></div>';
        h += '</div>';
        return h;
      }

      window.updateClaimTotal = function () {
        var sub = document.getElementById('sheetSub');
        if (!sub) return;
        var base = parseInt(sub.getAttribute('data-base'), 10) || 0;
        var extra = 0;
        var sel = document.getElementById('claimDL');
        if (sel && sel.value === 'subito') extra += 100;
        if (sel && sel.value === '1') extra += 50;

        var cbBenda = document.getElementById('cbBenda');
        var boxBenda = document.getElementById('boxBenda');
        if (cbBenda && boxBenda) boxBenda.style.display = cbBenda.checked ? 'block' : 'none';

        var cbManette = document.getElementById('cbManette');
        var boxManette = document.getElementById('boxManette');
        if (cbManette && boxManette) boxManette.style.display = cbManette.checked ? 'block' : 'none';

        var cbVieni = document.getElementById('cbVieni');
        var boxVieni = document.getElementById('boxVieni');
        if (cbVieni && boxVieni) boxVieni.style.display = cbVieni.checked ? 'block' : 'none';

        var cbx = document.querySelectorAll('#premiumOptions input[type="checkbox"]:checked');
        for (var i = 0; i < cbx.length; i++) extra += parseInt(cbx[i].value, 10);
        document.getElementById('claimTotal').innerHTML = '🔷 ' + (base + extra) + ' pt';
      };

      function renderOverlay() {
        if (!overlay) return '';
        if (overlay.type === 'reward_nudge') return renderRewardNudgeOverlay();
        if (overlay.type === 'claim_confirm') return renderClaimConfirmOverlay();
        if (overlay.type === 'claim_success') return renderClaimSuccessOverlay();
        if (overlay.type === 'order_detail') return renderOrderDetailOverlay();
        if (overlay.type === 'activity') {
          if (flashQ) return '<div class="overlay center"><div class="sheet rounded" style="overflow:hidden;padding:0">' + renderFlashQuestion() + '</div></div>';
          if (miniGame) return '<div class="overlay center"><div class="sheet rounded" style="overflow:hidden;padding:0">' + renderMiniGame() + '</div></div>';
          return '';
        }
        if (overlay.type !== 'claim') return '';
        var r = overlay.reward;
        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);padding-top:10vh" data-action="close-overlay">';
        h += '<div class="sheet" style="background:#ffffff;padding:24px 20px 32px;"><div class="sheet-handle" style="background:#d0d4e0;width:40px;height:4px;border-radius:2px;margin:0 auto 20px"></div>';
        h += '<h2 style="font-family:\'Inter\',sans-serif;font-size:1.6rem;color:#1a1f36;font-weight:800;margin-bottom:8px">Piazza un ordine</h2>';
        h += '<p style="font-size:.85rem;color:#8a8f9e;margin-bottom:24px;display:flex;align-items:center;gap:6px">' + (r.emoji || '👀') + ' <strong style="color:#1a1f36">' + esc(r.name) + '</strong> &nbsp;<span style="color:#d0d4e0">|</span>&nbsp; Base: <span style="color:#378add">🔷</span> <strong style="color:#1a1f36">' + r.cost + ' pt</strong></p>';
        h += '<div class="field"><label style="display:block;font-size:.7rem;font-weight:800;color:#378add;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">DETTAGLI DI CONSEGNA</label>';
        h += '<select id="claimDL" onchange="updateClaimTotal()" style="width:100%;padding:14px;border-radius:12px;border:1px solid #d0d4e0;background:#ffffff;color:#1a1f36;font-family:inherit;font-size:.95rem;outline:none;-webkit-appearance:none;appearance:none;background-image:url(\'data:image/svg+xml;charset=US-ASCII,%3Csvg%20width%3D%2212%22%20height%3D%228%22%20viewBox%3D%220%200%2012%208%22%20fill%3D%22none%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cpath%20d%3D%22M1%201.5L6%206.5L11%201.5%22%20stroke%3D%22%238a8f9e%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22/%3E%3C/svg%3E\');background-repeat:no-repeat;background-position:right 14px center;cursor:pointer">';
        h += '<option value="" disabled selected>Seleziona ora di consegna</option>';
        h += '<option value="subito">Subito (Ord. Prioritario, +100 pt)</option>';
        h += '<option value="1">Entro 1 ora (Ord. Prioritario, +50 pt)</option>';
        h += '<option value="2">Entro 2 ore</option>';
        h += '<option value="3">Entro 3 ore</option>';
        h += '<option value="4">Entro 4 ore</option>';
        h += '<option value="5">Entro 5 ore</option>';
        h += '</select></div>';
        
        h += '<div class="field" style="margin-top:24px"><label style="display:block;font-size:.7rem;font-weight:800;color:#378add;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">OPZIONI PREMIUM</label><div style="display:flex;flex-direction:column;gap:10px" id="premiumOptions">';
        
        var usrName = pname(session);
        var lblStyle = 'display:flex;align-items:center;justify-content:flex-start;gap:12px;font-size:.95rem;background:#ffffff;border:1px solid #d0d4e0;border-radius:12px;padding:16px 14px;cursor:pointer;color:#1a1f36;font-weight:500;transition:all .2s ease;margin:0';
        var cbStyle = 'width:20px;height:20px;margin:0;accent-color:#1a2a5e;cursor:pointer;border:1px solid #d0d4e0;border-radius:4px';
        var subBoxWrapper = 'display:none;margin-top:4px;margin-bottom:12px;padding:14px;background:#f0f4fb;border:1px solid #d0d4e0;border-radius:12px';
        var subTitleStyle = 'font-size:.75rem;color:#8a8f9e;text-transform:uppercase;letter-spacing:.05em;font-weight:800;margin-bottom:10px';
        var subRowStyle = 'display:flex;align-items:center;gap:12px;font-size:.9rem;cursor:pointer;font-weight:600;color:#1a1f36;padding:6px 0';

        var mkOpt = function(id, val, text, dataOpt) {
          var s = '<label style="' + lblStyle + '"><input id="'+id+'" name="'+id+'" type="checkbox" value="'+val+'" data-opt="'+dataOpt+'" onchange="updateClaimTotal()" style="' + cbStyle + '"><span style="flex:1">'+text+'</span><span class="pt-text" style="color:#378add;font-size:.9rem;font-weight:700">+'+val+' pt</span></label>';
          return s;
        };

        h += mkOpt('cbBenda', 50, 'Utilizzo benda', 'Utilizzo benda');
        h += '<div id="boxBenda" style="' + subBoxWrapper + '">';
        h += '<div style="' + subTitleStyle + '">Chi indossa la benda?</div>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optBenda" value="Tu" checked style="' + cbStyle + '"> Tu</label>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optBenda" value="Il partner" style="' + cbStyle + '"> Il partner</label>';
        h += '</div>';

        h += mkOpt('cbManette', 50, 'Utilizzo manette', 'Utilizzo manette');
        h += '<div id="boxManette" style="' + subBoxWrapper + '">';
        h += '<div style="' + subTitleStyle + '">Chi indossa le manette?</div>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optManette" value="Tu" checked style="' + cbStyle + '"> Tu</label>';
        h += '<label style="' + subRowStyle + '"><input type="radio" name="optManette" value="Il partner" style="' + cbStyle + '"> Il partner</label>';
        h += '</div>';

        h += mkOpt('cbPosizione', 50, 'Posizione a tua scelta', 'Posizione a tua scelta');
        h += mkOpt('cbInsieme', 100, 'Fai venire il partner insieme a te', 'Fai venire il partner insieme a te');

        if (usrName === 'Stefano') {
          h += mkOpt('cbVieni', 50, 'Vieni dove vuoi tu', 'Vieni');
          h += '<div id="boxVieni" style="display:none;margin-top:4px;margin-bottom:12px">';
          h += '<input type="text" id="txtVieni" placeholder="Specifica dove..." style="width:100%;padding:14px;border-radius:12px;border:1px solid #d0d4e0;font-size:.95rem;font-family:inherit;background:#ffffff;color:#1a1f36;outline:none">';
          h += '</div>';
        }
        h += '</div></div>';

        h += '<div style="background:#f0f4fb;padding:16px;border-radius:12px;margin-top:24px;margin-bottom:24px;display:flex;justify-content:space-between;align-items:center;border:1px dashed #b0bcd8">';
        h += '<span style="font-size:.95rem;font-weight:700;color:#1a2a5e">Totale ordine</span>';
        h += '<span id="claimTotal" style="font-size:1.3rem;font-weight:800;color:#1a2a5e"><span style="color:#378add">🔷</span> ' + r.cost + ' pt</span>';
        h += '</div>';
        h += '<div style="display:flex;gap:12px">';
        h += '<button style="flex:1;background:#ffffff;color:#1a1f36;border:1px solid #d0d4e0;padding:14px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="cancel-overlay">Indietro</button>';
        h += '<button style="flex:2;background:#1a2a5e;color:#ffffff;border:none;padding:14px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="prepare-claim">Conferma ordine <span style="font-size:1.1em;vertical-align:bottom">→</span></button>';
        h += '</div></div></div>';
        setTimeout(window.updateClaimTotal, 10);
        return h;
      }

      /* ── ORDER DETAIL OVERLAY ── */
      function renderOrderDetailOverlay() {
        var ov = overlay;
        var rr = S.requests.filter(function (r) { return r.id === ov.id; })[0];
        if (!rr) return '';
        var isExec = ov.isExec;
        var me = session;
        var pt = partner(me);
        var costVal = rr.cost || 100;
        
        var buyer = rr.by === me ? me : pt;
        
        var d = new Date(rr.requestedAt);
        var pad = function(n) { return n < 10 ? '0'+n : n; };
        var reqDate = pad(d.getDate()) + '/' + pad(d.getMonth()+1) + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes());

        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);display:flex;align-items:flex-end;justify-content:center;padding-top:40px" data-action="close-overlay">';
        h += '<div class="sheet" style="background:#ffffff;padding:24px 20px 0px;border-radius:24px 24px 0 0;width:100%;max-width:500px;max-height:90vh;overflow-y:auto;display:flex;flex-direction:column">';
        h += '<div class="sheet-handle" style="background:#d0d4e0;width:40px;height:4px;border-radius:2px;margin:0 auto 20px;flex-shrink:0"></div>';
        
        h += '<div style="background:#f8faff;border-radius:12px;padding:16px;margin-bottom:16px">';
        h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
        h += '<span style="font-size:.85rem;color:#8a8f9e;font-weight:500">Acquistato da</span>';
        h += '<span style="font-size:.9rem;color:#1a1f36;font-weight:700">' + esc(pname(buyer)) + '</span>';
        h += '</div>';
        h += '<div style="display:flex;justify-content:space-between;align-items:center">';
        h += '<span style="font-size:.85rem;color:#8a8f9e;font-weight:500">Data ordine</span>';
        h += '<span style="font-size:.9rem;color:#1a1f36;font-weight:700">' + reqDate + '</span>';
        h += '</div></div>';

        var dlStr = "";
        if (rr.deadline) {
            var dlD = new Date(rr.deadline);
            dlStr = pad(dlD.getDate()) + '/' + pad(dlD.getMonth()+1) + ', ' + pad(dlD.getHours()) + ':' + pad(dlD.getMinutes());
        }
        var dlLabel = rr.deadline ? (rr.status === 'pending' ? dlStr : dlStr) : 'Prima possibile';
        if (rr.status === 'done' || rr.status === 'done_confirm' || rr.status === 'expired') dlLabel = dlStr || "-";
        
        h += '<div style="display:flex;gap:12px;margin-bottom:24px">';
        h += '<div style="flex:1;background:#1a2a5e;border-radius:16px;padding:24px 16px;text-align:center;box-shadow:0 8px 16px rgba(26,42,94,0.15)">';
        h += '<div style="font-size:1.3rem;font-weight:800;color:#ffffff;margin-bottom:6px"><span style="color:#7eb3f5;font-size:.8em">🔷</span> ' + costVal + '</div>';
        h += '<div style="font-size:.65rem;color:#c8d4ea;font-weight:700;text-transform:uppercase;letter-spacing:.05em">PUNTI SPESI</div>';
        h += '</div>';
        h += '<div style="flex:1;background:#f0f4fb;border-radius:16px;padding:24px 16px;text-align:center">';
        h += '<div style="font-size:1.15rem;font-weight:800;color:#1a1f36;margin-bottom:6px">' + dlLabel + '</div>';
        h += '<div style="font-size:.65rem;color:#8a8f9e;font-weight:700;text-transform:uppercase;letter-spacing:.05em">CONSEGNA ENTRO</div>';
        h += '</div></div>';

        h += '<div style="margin-bottom:24px">';
        h += '<div style="font-size:.7rem;font-weight:800;color:#378add;text-transform:uppercase;letter-spacing:.05em;margin-bottom:16px">CRONOLOGIA</div>';
        var timeline = [];
        timeline.push({ dot: '#1a2a5e', label: 'Ordine effettuato', val: reqDate });
        if (rr.doneAt) {
            var lD = new Date(rr.doneAt);
            timeline.push({ dot: '#1a7a4a', label: 'Consegnato (da ' + esc(pname(rr.by === me ? pt : me)) + ')', val: pad(lD.getDate()) + '/' + pad(lD.getMonth()+1) + ', ' + pad(lD.getHours()) + ':' + pad(lD.getMinutes()) });
        }
        if (rr.confirmedAt) {
            var cD = new Date(rr.confirmedAt);
            timeline.push({ dot: '#1a7a4a', label: 'Ricezione confermata', val: pad(cD.getDate()) + '/' + pad(cD.getMonth()+1) + ', ' + pad(cD.getHours()) + ':' + pad(cD.getMinutes()) });
        }
        if (rr.cancelledAt) {
            var cnD = new Date(rr.cancelledAt);
            timeline.push({ dot: '#a32d2d', label: 'Annullato / Non evaso', val: pad(cnD.getDate()) + '/' + pad(cnD.getMonth()+1) + ', ' + pad(cnD.getHours()) + ':' + pad(cnD.getMinutes()) });
        }
        
        h += '<div style="position:relative;padding-left:4px">';
        timeline.forEach(function (t, i) {
          h += '<div style="display:flex;align-items:flex-start;gap:16px;margin-bottom:' + (i < timeline.length - 1 ? '16px' : '0') + '">';
          h += '<div style="width:10px;height:10px;border-radius:50%;background:' + t.dot + ';margin-top:4px;flex-shrink:0;box-shadow:0 0 0 4px #ffffff"></div>';
          h += '<div><div style="font-size:.95rem;font-weight:700;color:#1a1f36;margin-bottom:4px">' + t.label + '</div><div style="font-size:.8rem;color:#8a8f9e">' + t.val + '</div></div>';
          h += '</div>';
        h += '</div></div>';

        h += '<div style="margin-bottom:24px">';
        h += '<div style="font-size:.7rem;font-weight:800;color:#8a8f9e;text-transform:uppercase;letter-spacing:.05em;margin-bottom:12px">PRODOTTO ORDINATO</div>';
        h += '<div style="display:flex;align-items:center;gap:16px;background:#f8faff;padding:16px;border-radius:16px;border:1px solid #e0eaf8">';
        h += '<div style="font-size:2.2rem;line-height:1">' + esc(rr.emoji || '🎁') + '</div>';
        h += '<div><div style="font-size:1.05rem;font-weight:800;color:#1a1f36;margin-bottom:4px;font-family:\\'Playfair Display\\',serif">' + esc(rr.name) + '</div>';
        if (rr.desc) {
          h += '<div style="font-size:.8rem;color:#8a8f9e;line-height:1.4">' + esc(rr.desc) + '</div>';
        }
        h += '</div></div></div>';

        var premiumList = rr.premium && rr.premium.length > 0 ? rr.premium : (rr.note && rr.note.indexOf('[PREMIUM:') === 0 ? rr.note.replace('[PREMIUM: ', '').replace(']', '').split(', ') : []);
        if (premiumList.length > 0) {
          h += '<div style="margin-bottom:24px;padding:16px;background:#ffffff;border-radius:16px;border:1.5px dashed #b0bcd8">';
          h += '<div style="font-size:.7rem;font-weight:800;color:#9b51e0;text-transform:uppercase;letter-spacing:.05em;margin-bottom:14px">OPZIONI PREMIUM</div>';
          premiumList.forEach(function (p) {
            h += '<div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:10px;font-size:.9rem;color:#1a1f36;font-weight:500">';
            h += '<div style="width:6px;height:6px;border-radius:50%;background:#9b51e0;margin-top:6px;flex-shrink:0"></div>';
            h += '<div style="line-height:1.4">' + esc(p.trim()) + '</div></div>';
          });
          h += '</div>';
        }

        if (rr.latePenaltyApplied || rr.unfulfilledPenaltyApplied) {
          var pLabel = rr.latePenaltyApplied ? 'PENALE RITARDO APPLICATA' : 'PENALE INADEMPIENZA APPLICATA';
          h += '<div style="margin-bottom:24px;padding:16px;background:#fdf5f0;border-radius:16px;border:1px solid #f5c0bc">';
          h += '<div style="font-size:.7rem;font-weight:800;color:#c04020;text-transform:uppercase;letter-spacing:.05em;margin-bottom:12px">' + pLabel + '</div>';
          h += '<div style="display:flex;justify-content:space-between;font-size:.9rem;margin-bottom:8px"><span style="color:#8a8f9e;font-weight:600">Rimborso cliente</span><span style="color:#1a7a4a;font-weight:800">+' + rr.refundAmt + ' pt</span></div>';
          h += '<div style="display:flex;justify-content:space-between;font-size:.9rem"><span style="color:#8a8f9e;font-weight:600">Penale esecutore</span><span style="color:#c04020;font-weight:800">-' + rr.penaltyAmt + ' pt</span></div>';
          h += '</div>';
        }

        var doneCount = S.requests.filter(function(r){return r.status==='done';}).length;
        var isDone = rr.status === 'done';
        var basePct = Math.min(15 + Math.floor(doneCount * 1.5), 35);
        var igaPct = isDone ? basePct : Math.max(basePct - 8, 4);
        var cortPct = isDone ? Math.round(basePct * 0.9) : Math.max(Math.round(basePct * 0.5), 3);
        var syncPct = isDone ? Math.round(basePct * 0.7) : Math.max(Math.round(basePct * 0.35), 2);
        var oxPct = isDone ? Math.round(basePct * 0.8) : Math.max(Math.round(basePct * 0.4), 2);

        h += '<div style="margin-bottom:32px;background:#1a2a5e;border-radius:16px;padding:24px;color:white">';
        h += '<div style="font-size:.65rem;color:#8fa8d8;text-transform:uppercase;letter-spacing:.05em;font-weight:800;margin-bottom:12px">IMPATTO SUL BENESSERE DI COPPIA</div>';
        h += '<div style="font-size:.9rem;color:#e8edf8;margin-bottom:24px;line-height:1.4;font-weight:500">' + (isDone ? 'Questo ordine ha contribuito ai tuoi indicatori di benessere nella settimana in corso.' : 'Indicatori stimati attivi da quando hai effettuato l\'ordine.') + '</div>';

        var metrics = [
          { label: 'Scudo immunitario (IgA)', pct: igaPct, color: '#7ee8b0', barBg: 'rgba(255,255,255,0.15)' },
          { label: 'Riduzione cortisolo', pct: cortPct, color: '#7ee8b0', barBg: 'rgba(255,255,255,0.15)' },
          { label: 'Sincronizzazione coppia', pct: syncPct, color: '#f8c97a', barBg: 'rgba(255,255,255,0.15)' },
          { label: 'Rilascio ossitocina', pct: oxPct, color: '#f8c97a', barBg: 'rgba(255,255,255,0.15)' }
        ];
        metrics.forEach(function (m) {
          h += '<div style="margin-bottom:16px">';
          h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="font-size:.85rem;font-weight:600;color:#c8d4ea">' + m.label + '</span><span style="font-size:.85rem;font-weight:800;color:' + m.color + '">+' + m.pct + '%</span></div>';
          h += '<div style="height:4px;background:' + m.barBg + ';border-radius:4px;overflow:hidden"><div style="height:100%;width:' + m.pct + '%;background:' + m.color + ';border-radius:4px"></div></div>';
          h += '</div>';
        });
        h += '</div>';

        h += '<div style="position:sticky;bottom:0;background:#ffffff;padding-top:10px;padding-bottom:30px;display:flex;flex-direction:column;gap:10px;border-top:1px solid rgba(0,0,0,0.03)">';
        
        if (rr.by === pt) { 
          if (rr.status === 'pending') {
            h += '<button style="flex:1;background:#1a2a5e;color:#fff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;align-items:center;cursor:pointer" data-action="mark-done" data-arg="' + esc(rr.id) + '">Segna come Consegnato 📦</button>';
          }
        } else { 
          if (rr.status === 'done_confirm') {
            h += '<button style="background:#1a7a4a;color:#fff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;align-items:center;cursor:pointer" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="yes">Conferma Ricezione ✅</button>';
            h += '<div style="display:flex;gap:10px">';
            h += '<button style="flex:1;background:#fff5f0;color:#c04020;border:1px solid #f5c0bc;padding:12px;border-radius:12px;font-size:.9rem;font-weight:700;cursor:pointer" data-action="report-late" data-arg="' + esc(rr.id) + '">In Ritardo</button>';
            h += '<button style="flex:1;background:#fff5f0;color:#a32d2d;border:1px solid #f5c0bc;padding:12px;border-radius:12px;font-size:.9rem;font-weight:700;cursor:pointer" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="no">Non Eseguito</button>';
            h += '</div>';
          } else if (rr.status === 'pending' && Date.now() > new Date(rr.deadline||0).getTime() + 600000) {
            h += '<button style="background:#fdf0f0;color:#a32d2d;border:1px solid #f5c0bc;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;cursor:pointer" data-action="declare-unfulfilled" data-arg="' + esc(rr.id) + '">Dichiara Inadempienza 🚨</button>';
          } else if (rr.status === 'expired') {
             h += '<button style="background:#e6f7ee;color:#1a7a4a;border:1px solid #a3e6be;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;cursor:pointer" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="yes">Alla fine consegnato ✅</button>';
          }
        }
        
        h += '<button style="background:#ffffff;color:#1a1f36;border:1px solid #d0d4e0;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;align-items:center;cursor:pointer" data-action="cancel-overlay">← Chiudi dettaglio</button>';
        h += '</div>';
        h += '</div></div>';
        return h;
      }


      function renderRewardNudgeOverlay() {
        var o = overlay;
        var h = '<div class="overlay center" data-action="close-overlay">';
        h += '<div class="sheet rounded" style="background:linear-gradient(135deg,#0e1933,#1a1050)">';
        h += '<div style="font-size:3rem;margin-bottom:12px">🛍️</div>';
        h += '<h2 style="color:#c4b5fd;font-size:1.2rem;margin-bottom:8px">Promozione terminata. Effettuare acquisti?</h2>';
        h += '<p style="font-size:.84rem;color:rgba(196,181,253,.75);margin-bottom:20px;line-height:1.55">';
        h += 'Hai accumulato <strong style="color:#c4b5fd">🔷 ' + o.pts + ' pt</strong> nel portafoglio e ci sono ' + o.count + ' ' + (o.count === 1 ? 'ordine sbloccato' : 'ordini sbloccati') + '.<br>Passa allo shop!';
        h += '</p>';
        h += '<div style="display:flex;gap:10px;justify-content:center">';
        h += '<button class="btn btn-o btn-sm" data-action="fq-skip-claim" style="color:rgba(255,255,255,.4);border-color:rgba(255,255,255,.15)">Non ora</button>';
        h += '<button class="btn btn-gold" data-action="fq-claim">Vai ai premi 🎁</button>';
        h += '</div></div></div>';
        return h;
      }

      function renderClaimConfirmOverlay() {
        var o = overlay;
        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);display:flex;align-items:center;justify-content:center;padding:24px" data-action="close-overlay">';
        h += '<div class="sheet" style="background:#ffffff;padding:32px 24px;border-radius:24px;text-align:center;width:100%;max-width:380px;box-shadow:0 10px 30px rgba(15,20,45,0.15)">';
        h += '<div style="font-size:2.8rem;margin-bottom:12px;line-height:1">👀</div>';
        h += '<h2 style="color:#1a1f36;font-size:1.4rem;font-weight:800;margin-bottom:8px">Riepilogo ordine</h2>';
        h += '<p style="font-size:.9rem;color:#8a8f9e;margin-bottom:24px;font-weight:500">Stai per acquistare <strong style="color:#1a1f36;font-weight:700">' + esc(o.reward.name) + '</strong></p>';

        h += '<div style="background:#f0f4fb;border-radius:16px;padding:20px;text-align:left;margin-bottom:24px">';
        h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem"><span style="color:#8a8f9e;font-weight:500">Costo base</span><span style="font-weight:700;color:#1a1f36"><span style="color:#378add">🔷</span> ' + o.reward.cost + ' pt</span></div>';
        if (o.premiumArr && o.premiumArr.length > 0) {
          o.premiumArr.forEach(function (p) { 
            var ptMatch = p.match(/\(\+([0-9]+)\s*pt\)/i);
            var cleanText = p.replace(/\(\+([0-9]+)\s*pt\)/i, '').trim();
            if (ptMatch) {
                h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem"><span style="color:#8a8f9e;font-weight:500">' + esc(cleanText) + '</span><span style="font-weight:700;color:#1a1f36"><span style="color:#378add">🔷</span> +' + ptMatch[1].replace(/\D/g,'') + ' pt</span></div>';
            } else {
                h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem"><span style="color:#8a8f9e;font-weight:500">' + esc(p) + '</span></div>';
            }
          });
        }
        h += '<div style="border-top:1px dashed #b0bcd8;margin:16px 0"></div>';
        h += '<div style="display:flex;justify-content:space-between;align-items:center"><span style="font-size:1rem;font-weight:700;color:#1a2a5e">Totale finale</span><span style="font-size:1.3rem;font-weight:800;color:#1a2a5e"><span style="color:#378add">🔷</span> ' + o.totalCost + ' pt</span></div>';
        h += '</div>';

        var finalBal = myPts() - o.totalCost;
        h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding:0 8px">';
        h += '<span style="font-size:.85rem;color:#8a8f9e;font-weight:500">Saldo disponibile</span>';
        h += '<span style="font-size:.85rem;font-weight:700;color:#8a8f9e"><span style="color:#378add">🔷</span> ' + myPts() + ' pt <span style="margin:0 4px">→</span> <strong style="color:#1a7a4a">' + finalBal + ' pt</strong></span>';
        h += '</div>';

        h += '<div style="display:flex;gap:12px">';
        h += '<button style="flex:1;background:#ffffff;color:#1a1f36;border:1px solid #d0d4e0;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="cancel-overlay">Annulla</button>';
        h += '<button style="flex:1.5;background:#1a2a5e;color:#ffffff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="finalize-claim">Acquista ora <span style="font-size:1.1em;vertical-align:bottom">→</span></button>';
        h += '</div></div></div>';
        return h;
      }

      function renderClaimSuccessOverlay() {
        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);display:flex;align-items:center;justify-content:center;padding:24px">';
        h += '<div class="sheet" style="background:#ffffff;padding:40px 24px 32px;border-radius:24px;text-align:center;width:100%;max-width:340px;box-shadow:0 14px 40px rgba(15,20,45,0.2)">';
        h += '<div style="font-size:4rem;margin-bottom:20px;line-height:1">✅</div>';
        h += '<h2 style="color:#1a1f36;font-size:1.6rem;font-weight:800;margin-bottom:12px">Ordine Acquisito!</h2>';
        h += '<p style="font-size:.95rem;color:#8a8f9e;margin-bottom:32px;line-height:1.5;font-weight:500">Il tuo ordine per <strong style="color:#1a1f36">' + esc(overlay.reward.name) + '</strong> è andato a buon fine. Il partner riceverà la notifica!</p>';
        h += '<button style="width:100%;background:#1a2a5e;color:#ffffff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;cursor:pointer" data-action="close-success">Chiudi questa finestra</button>';
        h += '</div></div>';
        return h;
      }

      /* ── ADMIN ── */
      function renderAdmin() {
        if (!adminAuthed) {
          var h = '<div class="auth-wrap"><div class="auth-card">';
          h += '<div class="auth-logo"><span class="auth-gem">⚙️</span><h1>Settings</h1><p>Pannello di amministrazione</p></div>';
          h += '<div class="field"><label class="lbl">Username</label><input type="text" id="au"/></div>';
          h += '<div class="field"><label class="lbl">Password</label><input type="password" id="ap"/></div>';
          h += '<div id="admerr" class="err"></div>';
          h += '<button class="btn btn-p btn-full" data-action="do-adm-login">Accedi →</button>';
          h += '<div style="text-align:center;margin-top:12px"><button data-action="logout" style="background:none;border:none;font-size:.75rem;color:var(--muted);cursor:pointer;font-family:sans-serif">← Torna al login</button></div>';
          h += '</div></div>';
          return h;
        }
        var qs = S.questions, rs = S.rewards, reqs = S.requests;
        var onlineList = Object.keys(onlineUsers).filter(function (u) { return Date.now() - onlineUsers[u] < 12000; });
        var body = '';

        if (adminTab === 'quiz') {
          body += '<div class="acard"><h3>➕ Nuova domanda</h3>';
          body += '<div class="af" style="margin-bottom:11px"><label>Domanda</label><textarea id="qT" placeholder="Es. Qual è la capitale della Francia?"></textarea></div>';
          body += '<div class="agrid" style="margin-bottom:11px">';
          for (var i = 0; i < 4; i++) body += '<div class="af"><label>Opzione ' + (i + 1) + '</label><input id="qO' + i + '" placeholder="Risposta ' + (i + 1) + '"/></div>';
          body += '</div><div class="af" style="margin-bottom:14px"><label>Risposta corretta</label><select id="qC">';
          for (var j = 0; j < 4; j++) body += '<option value="' + j + '">Opzione ' + (j + 1) + '</option>';
          body += '</select></div><button class="abtn grn" data-action="add-q">+ Aggiungi domanda</button></div>';
          body += '<div class="acard"><h3>📚 Domande (' + qs.length + ')</h3><div class="alist">';
          if (!qs.length) body += '<div style="color:#4a6080;font-size:.8rem">Nessuna domanda.</div>';
          else qs.forEach(function (q) {
            body += '<div class="aitem"><div><h4>' + esc(q.text) + '</h4><p>' + q.opts.map(function (o, i) { return (i === q.correct ? '✅' : '○') + ' ' + esc(o); }).join(' · ') + '</p></div>';
            body += '<button class="adel" data-action="del-q" data-arg="' + esc(q.id) + '">🗑</button></div>';
          });
          body += '</div></div>';
        }

        else if (adminTab === 'rewards') {
          body += '<div class="acard"><h3>➕ Nuovo premio</h3><div class="agrid">';
          body += '<div class="af"><label>Per</label><select id="rPt"><option value="giulia">🌸 Giulia</option><option value="stefano">⚡ Stefano</option><option value="both">👫 Entrambi</option></select></div>';
          body += '<div class="af"><label>Costo (pt)</label><input type="number" id="rC" value="100" min="1"/></div>';
          body += '<div class="af"><label>Emoji</label><input id="rE" value="🎁"/></div>';
          body += '<div class="af"><label>Nome</label><input id="rN" placeholder="Es. Cena romantica"/></div>';
          body += '<div class="af" style="grid-column:span 2"><label>Descrizione</label><input id="rD" placeholder="Cosa include..."/></div>';
          body += '</div><div style="margin-top:13px"><button class="abtn gold" data-action="add-r">+ Aggiungi premio</button></div></div>';
          body += '<div class="acard"><h3>🎁 Premi (' + rs.length + ')</h3><div class="alist">';
          if (!rs.length) body += '<div style="color:#4a6080;font-size:.8rem">Nessun premio.</div>';
          else rs.forEach(function (r) {
            body += '<div class="aitem"><div><h4>' + (r.emoji || '🎁') + ' ' + esc(r.name) + '</h4><p><span class="chip ' + (r.partner === 'both' ? 'cb' : r.partner === 'giulia' ? 'cg' : 'cs') + '">' + r.partner + '</span> · 🔷 ' + r.cost + ' pt' + (r.desc ? ' · ' + esc(r.desc) : '') + '</p></div>';
            body += '<button class="adel" data-action="del-r" data-arg="' + esc(r.id) + '">🗑</button></div>';
          });
          body += '</div></div>';
        }

        else if (adminTab === 'stats') {
          var gPts = ptOf('giulia'), sPts = ptOf('stefano');
          var gQ = S.users.giulia.quizToday && S.users.giulia.quizToday.date === todayKey() ? 'Fatto' : '—';
          var sQ = S.users.stefano.quizToday && S.users.stefano.quizToday.date === todayKey() ? 'Fatto' : '—';
          body += '<div class="acard"><h3>📊 Bilanci</h3><div class="astats">';
          body += '<div class="astat"><div class="v">🔷 ' + gPts + '</div><div class="l">Punti Giulia</div></div>';
          body += '<div class="astat"><div class="v">🔷 ' + sPts + '</div><div class="l">Punti Stefano</div></div>';
          body += '<div class="astat"><div class="v">' + gQ + '</div><div class="l">Quiz Giulia oggi</div></div>';
          body += '<div class="astat"><div class="v">' + sQ + '</div><div class="l">Quiz Stefano oggi</div></div>';
          body += '<div class="astat"><div class="v">' + qs.length + '</div><div class="l">Domande quiz</div></div>';
          body += '<div class="astat"><div class="v">' + reqs.filter(function (r) { return r.status === 'pending'; }).length + '</div><div class="l">Premi in attesa</div></div>';
          body += '</div></div>';
          body += '<div class="acard"><h3>✏️ Modifica punti</h3>';
          ['giulia', 'stefano'].forEach(function (p) {
            body += '<div style="display:flex;align-items:center;gap:7px;margin-bottom:9px;flex-wrap:wrap">';
            body += '<span style="width:90px;font-size:.82rem;font-weight:600;color:var(--b8)">' + pname(p) + ' (' + ptOf(p) + ')</span>';
            [[100, '+100'], [-100, '-100'], [500, '+500'], [-500, '-500']].forEach(function (pair) {
              body += '<button class="abtn" style="padding:6px 10px" data-action="adj-pts" data-arg="' + p + '" data-arg2="' + pair[0] + '">' + pair[1] + '</button>';
            });
            body += '</div>';
          });
          body += '</div>';
          body += '<div class="acard"><h3>📨 Ultime richieste</h3><div class="alist">';
          reqs.slice().reverse().slice(0, 8).forEach(function (rr) {
            body += '<div class="aitem"><div><h4>' + (rr.emoji || '🎁') + ' ' + esc(rr.name) + '</h4><p><span class="chip ' + (rr.by === 'giulia' ? 'cg' : 'cs') + '">' + pname(rr.by) + '</span> · ' + fmtDt(rr.requestedAt) + ' · ' + rr.status + '</p></div></div>';
          });
          if (!reqs.length) body += '<div style="color:#4a6080;font-size:.8rem">Nessuna richiesta.</div>';
          body += '</div></div>';
          body += '<div class="acard"><h3 style="color:#d08080">⚠️ Zona pericolosa</h3><p style="color:#4a6080;font-size:.8rem;margin-bottom:9px">Reset completo. Irreversibile.</p>';
          body += '<button class="reset-btn" data-action="do-reset">Reset completo</button></div>';

          // ntfy topics
          body += '<div class="acard"><h3>📲 Topic ntfy (notifiche push)</h3>';
          body += '<p style="color:#4a6080;font-size:.78rem;margin-bottom:14px">Ogni utente deve iscriversi al proprio topic nell\'app <strong>ntfy</strong> (iOS/Android). Tocca per copiare.</p>';
          ['giulia', 'stefano'].forEach(function (p) {
            var topic = S.users[p] && S.users[p].ntfyTopic;
            var icon = p === 'giulia' ? '🌸' : '⚡';
            if (topic) {
              body += '<div style="margin-bottom:10px">';
              body += '<div style="font-size:.72rem;color:#5a7090;font-weight:600;margin-bottom:5px;text-transform:uppercase;letter-spacing:.06em">' + icon + ' ' + pname(p) + '</div>';
              body += '<div style="display:flex;gap:8px;align-items:center">';
              body += '<code style="background:#070d1f;border:1px solid #162448;color:#7aa0e8;border-radius:7px;padding:8px 11px;font-size:.75rem;flex:1;word-break:break-all">' + esc(topic) + '</code>';
              body += '<button class="abtn" style="padding:8px 12px;flex-shrink:0" data-action="copy-topic" data-arg="' + esc(topic) + '">📋 Copia</button>';
              body += '</div>';
              body += '<div style="margin-top:5px;font-size:.72rem;color:#3a6080">ntfy.sh/' + esc(topic) + '</div>';
              body += '</div>';
            } else {
              body += '<div style="color:#4a6080;font-size:.78rem;margin-bottom:8px">' + icon + ' ' + pname(p) + ': topic non ancora generato (utente deve fare il primo accesso)</div>';
            }
          });
          body += '<div style="margin-top:12px;padding:10px 12px;background:#070d1f;border-radius:8px;border:1px solid #162448">';
          body += '<div style="font-size:.72rem;color:#5a7090;font-weight:600;margin-bottom:6px">📅 Reminder quiz (cron-job.org)</div>';
          body += '<p style="font-size:.72rem;color:#4a6080;line-height:1.5">Crea 2 job su <strong style="color:#7aa0e8">cron-job.org</strong> con questi parametri:<br>• Method: POST &nbsp;·&nbsp; Schedule: ogni giorno ore 10:00<br>• URL: <code style="color:#7aa0e8">https://ntfy.sh/[topic-utente]</code><br>• Header <code style="color:#7aa0e8">Title</code>: 🧠 Quiz del giorno!<br>• Body: Hai il quiz da completare oggi!</p>';
          body += '</div></div>';
        }

        var h = '<div class="adm-wrap">';
        h += '<div class="adm-top">';
        h += svgSettings();
        h += '<h1>Settings</h1>';
        h += '<div class="sync-pill"><span class="sdot"></span>Live' + (onlineList.length ? (' · ' + onlineList.map(function (u) { return u === 'giulia' ? '🌸' : '⚡'; }).join('')) : '') + '</div>';
        h += '<button data-action="adm-logout" style="background:none;border:none;color:#5a7090;cursor:pointer;font-size:.75rem;font-family:sans-serif;margin-left:8px">← Esci</button></div>';
        h += '<div class="adm-body">';
        h += '<div class="adm-tabs">';
        h += '<button class="adm-tab' + (adminTab === 'quiz' ? ' on' : '') + '" data-action="set-adm-tab" data-arg="quiz">🧠 Quiz</button>';
        h += '<button class="adm-tab' + (adminTab === 'rewards' ? ' on' : '') + '" data-action="set-adm-tab" data-arg="rewards">🎁 Premi</button>';
        h += '<button class="adm-tab' + (adminTab === 'stats' ? ' on' : '') + '" data-action="set-adm-tab" data-arg="stats">📊 Stats</button>';
        h += '</div>' + body + '</div>';
        if (toast) h += '<div class="toast" style="position:fixed;bottom:20px">' + toast + '</div>';
        h += '</div>';
        return h;
      }

      /* ── SVG ── */
      function svgHome() { return '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><path d="M9 22V12h6v10" fill="none" stroke="currentColor" stroke-width="2"/></svg>'; }
      function svgQuiz() { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17" stroke-width="3"/></svg>'; }
      function svgShop() { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>'; }
      function svgGift() { return '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 12v10H4V12M22 7H2v5h20V7zM12 22V7M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z"/></svg>'; }
      function svgX() { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="18" height="18"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>'; }
      function svgLogout() { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>'; }
      function svgSettings() { return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--b8)"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>'; }

      /* ── INIT ── */
      if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
        try { Notification.requestPermission(); } catch (e) { }
      }

      // Restore 48h session from localStorage
      var _savedSession = loadSession();
      if (_savedSession) { session = _savedSession; }

      // Show loading screen until Firebase responds
      document.getElementById('R').innerHTML = '<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(160deg,#070d1f,#0e1933);flex-direction:column;gap:16px"><div style="font-size:3rem">🔷</div><div style="color:#b0c8f8;font-family:sans-serif;font-size:.9rem">Connessione in corso...</div></div>';

      /* ── FIREBASE LISTENERS (after all functions defined) ── */
      db.ref(DB_REF).on('value', function (snapshot) {
        var data = snapshot.val();
        if (data) {
          S = {
            users: data.users || clone(BLANK).users,
            questions: objToArr(data.questions),
            rewards: objToArr(data.rewards),
            requests: objToArr(data.requests)
          };
        }
        if (!fbReady) {
          fbReady = true;
          render(); // first load — always safe
          return;
        }
        // Ignore echoes from our own writes
        if (_writing) return;
        // Remote update from partner device — schedule a safe re-render
        scheduleRemoteRender();
      });

      db.ref('sc_presence').on('value', function (snap) {
        onlineUsers = {};
        var data = snap.val() || {};
        Object.keys(data).forEach(function (u) {
          if (data[u] && data[u].online) onlineUsers[u] = data[u].t;
        });
        // Update only the presence text node — no full re-render
        if (session && session !== 'admin' && fbReady) {
          var heroSub = document.querySelector('.bal-sub');
          if (heroSub) {
            var pt = session === 'giulia' ? 'stefano' : 'giulia';
            var ptPts = ptOf(pt);
            var ptOnline = onlineUsers[pt] && (Date.now() - onlineUsers[pt] < 12000);
            heroSub.textContent = pname(pt) + ': ' + ptPts + ' pt  ·  ' + (ptOnline ? '🟢 online' : '⬤ offline');
          }
        }
      });

      setInterval(function () {
        announcePresence();
        checkTick();
        checkPenaltyWarning();
        checkFlashQuestion();
      }, 10000);

      function svgHeart() { return '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>'; }

    })();