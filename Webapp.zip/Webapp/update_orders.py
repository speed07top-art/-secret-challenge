import re
import sys

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Update `else if (tab === 'execute') {` block
new_execute_tab = """else if (tab === 'execute') {
          window.executeSubTab = window.executeSubTab || 'ricevuti';
          
          var hTop = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
          hTop += '<div style="font-size:1.6rem;font-weight:800;color:#1a1f36;font-family:\\'Playfair Display\\',serif">Ordini</div>';
          hTop += '<div class="pts-badge" style="background:#1a2a5e;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:6px"><span style="color:#7eb3f5">🔷</span> '+pts+' pt</div>';
          hTop += '</div>';
          page += hTop;

          page += '<div style="margin-bottom:24px;background:#e2e5f0;border-radius:12px;padding:6px;display:flex;gap:6px">';
          var isRic = window.executeSubTab === 'ricevuti';
          var namePt = esc(pname(pt));
          
          var stRic = isRic ? 'background:#ffffff;color:#1a1f36;box-shadow:0 2px 8px rgba(0,0,0,0.05)' : 'color:#6b7080;cursor:pointer';
          page += '<div onclick="window.executeSubTab=\\'ricevuti\\';render()" style="flex:1;text-align:center;padding:10px;border-radius:8px;transition:0.2s;'+stRic+'"><div style="font-size:.95rem;font-weight:800">Ricevuti</div><div style="font-size:.75rem;opacity:0.6;margin-top:2px">da ' + namePt + '</div></div>';
          
          var stInv = !isRic ? 'background:#ffffff;color:#1a1f36;box-shadow:0 2px 8px rgba(0,0,0,0.05)' : 'color:#6b7080;cursor:pointer';
          page += '<div onclick="window.executeSubTab=\\'inviati\\';render()" style="flex:1;text-align:center;padding:10px;border-radius:8px;transition:0.2s;'+stInv+'"><div style="font-size:.95rem;font-weight:800">Inviati</div><div style="font-size:.75rem;opacity:0.6;margin-top:2px">a ' + namePt + '</div></div>';
          page += '</div>';

          var list = isRic 
            ? S.requests.filter(function(r) { return r.by !== me; }).slice().reverse()
            : S.requests.filter(function(r) { return r.by === me; }).slice().reverse();

          if (!list.length) {
            page += '<div class="empty" style="margin-top:40px"><span class="empty-ico">📦</span><p style="font-size:.9rem;color:#8a8f9e;line-height:1.5">Nessun ordine presente in questa categoria.</p></div>';
          } else {
            page += '<div style="display:flex;flex-direction:column;gap:12px">';
            list.forEach(function(rr) {
              var s = rr.status;
              var isPending = s === 'pending';
              var isDone = s === 'done' || s === 'done_confirm';
              
              var bgB = isPending ? '#fff8e6' : isDone ? '#e6f7ee' : '#fdf0f0';
              var colB = isPending ? '#a06800' : isDone ? '#1a7a4a' : '#a32d2d';
              var txtB = isPending ? 'In lavorazione' : isDone ? 'Consegnato' : 'Annullato';
              
              var card = '<div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:16px;padding:16px;cursor:pointer;transition:all .2s" onclick="document.querySelector(\\'[data-arg=\\'+esc(rr.id)+\\']\\').click()">';
              card += '<div style="display:flex;align-items:flex-start;gap:14px;margin-bottom:12px">';
              card += '<div style="width:54px;height:54px;background:#eef3fb;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.8rem;flex-shrink:0">'+(rr.emoji||'🎁')+'</div>';
              card += '<div style="flex:1">';
              card += '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px">';
              card += '<div style="font-size:.95rem;font-weight:800;color:#1a1f36;line-height:1.2;max-width:140px">'+esc(rr.name)+'</div>';
              card += '<div style="background:'+bgB+';color:'+colB+';font-size:.65rem;font-weight:800;padding:4px 10px;border-radius:12px;white-space:nowrap">'+txtB+'</div>';
              card += '</div>';
              
              var d = new Date(rr.requestedAt);
              var pad = function(n) { return n < 10 ? '0'+n : n; };
              var dateStr = pad(d.getDate()) + '/' + pad(d.getMonth()+1) + ' · ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
              
              card += '<div style="font-size:.8rem;color:#8a8f9e">'+dateStr+'</div>';
              card += '</div></div>';
              
              card += '<div style="display:flex;justify-content:space-between;align-items:center">';
              card += '<div style="font-size:1rem;font-weight:900;color:#1a1f36"><span style="color:#378add;font-size:.8em">🔷</span> '+(rr.cost||100)+' pt</div>';
              card += '<button style="background:none;border:none;color:#378add;font-size:.85rem;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:4px" data-action="view-order" data-arg="'+esc(rr.id)+'" data-arg2="'+(isRic?'1':'0')+'">Dettaglio <span style="font-size:1.1em">→</span></button>';
              card += '</div></div>';
              page += card;
            });
            page += '</div>';
          }
        }"""

content = re.sub(
    r'else\s+if\s*\(\s*tab\s*===\s*[\'"]execute[\'"]\s*\)\s*\{.*?\}\s*else\s+if\s*\(\s*tab\s*===\s*[\'"]benessere[\'"]', 
    lambda m: new_execute_tab + "\n        else if (tab === 'benessere'", 
    content, 
    flags=re.DOTALL
)

# 2. Rewrite `renderOrderDetailOverlay`
new_detail = """function renderOrderDetailOverlay() {
        var ov = overlay;
        var rr = S.requests.filter(function (r) { return r.id === ov.id; })[0];
        if (!rr) return '';
        var isExec = ov.isExec;
        var me = session;
        var pt = partner(me);
        var costVal = rr.cost || 100;
        
        var buyer = rr.by === me ? me : pt;
        
        var d = new Date(rr.requestedAt);
        var pad = function(n) { return n < 10 ? '0'+n : n; };
        var reqDate = pad(d.getDate()) + '/' + pad(d.getMonth()+1) + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes());

        var h = '<div class="overlay" style="background:rgba(15,20,45,0.55);display:flex;align-items:flex-end;justify-content:center;padding-top:40px" data-action="close-overlay">';
        h += '<div class="sheet" style="background:#ffffff;padding:24px 20px 0px;border-radius:24px 24px 0 0;width:100%;max-width:500px;max-height:90vh;overflow-y:auto;display:flex;flex-direction:column">';
        h += '<div class="sheet-handle" style="background:#d0d4e0;width:40px;height:4px;border-radius:2px;margin:0 auto 20px;flex-shrink:0"></div>';
        
        h += '<div style="background:#f8faff;border-radius:12px;padding:16px;margin-bottom:16px">';
        h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
        h += '<span style="font-size:.85rem;color:#8a8f9e;font-weight:500">Acquistato da</span>';
        h += '<span style="font-size:.9rem;color:#1a1f36;font-weight:700">' + esc(pname(buyer)) + '</span>';
        h += '</div>';
        h += '<div style="display:flex;justify-content:space-between;align-items:center">';
        h += '<span style="font-size:.85rem;color:#8a8f9e;font-weight:500">Data ordine</span>';
        h += '<span style="font-size:.9rem;color:#1a1f36;font-weight:700">' + reqDate + '</span>';
        h += '</div></div>';

        var dlStr = "";
        if (rr.deadline) {
            var dlD = new Date(rr.deadline);
            dlStr = pad(dlD.getDate()) + '/' + pad(dlD.getMonth()+1) + ', ' + pad(dlD.getHours()) + ':' + pad(dlD.getMinutes());
        }
        var dlLabel = rr.deadline ? (rr.status === 'pending' ? dlStr : dlStr) : 'Prima possibile';
        if (rr.status === 'done' || rr.status === 'done_confirm' || rr.status === 'expired') dlLabel = dlStr || "-";
        
        h += '<div style="display:flex;gap:12px;margin-bottom:24px">';
        h += '<div style="flex:1;background:#1a2a5e;border-radius:16px;padding:24px 16px;text-align:center;box-shadow:0 8px 16px rgba(26,42,94,0.15)">';
        h += '<div style="font-size:1.3rem;font-weight:800;color:#ffffff;margin-bottom:6px"><span style="color:#7eb3f5;font-size:.8em">🔷</span> ' + costVal + '</div>';
        h += '<div style="font-size:.65rem;color:#c8d4ea;font-weight:700;text-transform:uppercase;letter-spacing:.05em">PUNTI SPESI</div>';
        h += '</div>';
        h += '<div style="flex:1;background:#f0f4fb;border-radius:16px;padding:24px 16px;text-align:center">';
        h += '<div style="font-size:1.15rem;font-weight:800;color:#1a1f36;margin-bottom:6px">' + dlLabel + '</div>';
        h += '<div style="font-size:.65rem;color:#8a8f9e;font-weight:700;text-transform:uppercase;letter-spacing:.05em">CONSEGNA ENTRO</div>';
        h += '</div></div>';

        h += '<div style="margin-bottom:24px">';
        h += '<div style="font-size:.7rem;font-weight:800;color:#378add;text-transform:uppercase;letter-spacing:.05em;margin-bottom:16px">CRONOLOGIA</div>';
        var timeline = [];
        timeline.push({ dot: '#1a2a5e', label: 'Ordine effettuato', val: reqDate });
        if (rr.doneAt) {
            var lD = new Date(rr.doneAt);
            timeline.push({ dot: '#1a7a4a', label: 'Consegnato (da ' + esc(pname(rr.by === me ? pt : me)) + ')', val: pad(lD.getDate()) + '/' + pad(lD.getMonth()+1) + ', ' + pad(lD.getHours()) + ':' + pad(lD.getMinutes()) });
        }
        if (rr.confirmedAt) {
            var cD = new Date(rr.confirmedAt);
            timeline.push({ dot: '#1a7a4a', label: 'Ricezione confermata', val: pad(cD.getDate()) + '/' + pad(cD.getMonth()+1) + ', ' + pad(cD.getHours()) + ':' + pad(cD.getMinutes()) });
        }
        if (rr.cancelledAt) {
            var cnD = new Date(rr.cancelledAt);
            timeline.push({ dot: '#a32d2d', label: 'Annullato / Non evaso', val: pad(cnD.getDate()) + '/' + pad(cnD.getMonth()+1) + ', ' + pad(cnD.getHours()) + ':' + pad(cnD.getMinutes()) });
        }
        
        h += '<div style="position:relative;padding-left:4px">';
        timeline.forEach(function (t, i) {
          h += '<div style="display:flex;align-items:flex-start;gap:16px;margin-bottom:' + (i < timeline.length - 1 ? '16px' : '0') + '">';
          h += '<div style="width:10px;height:10px;border-radius:50%;background:' + t.dot + ';margin-top:4px;flex-shrink:0;box-shadow:0 0 0 4px #ffffff"></div>';
          h += '<div><div style="font-size:.95rem;font-weight:700;color:#1a1f36;margin-bottom:4px">' + t.label + '</div><div style="font-size:.8rem;color:#8a8f9e">' + t.val + '</div></div>';
          h += '</div>';
        });
        h += '</div></div>';

        var premiumList = rr.premium && rr.premium.length > 0 ? rr.premium : (rr.note && rr.note.indexOf('[PREMIUM:') === 0 ? rr.note.replace('[PREMIUM: ', '').replace(']', '').split(', ') : []);
        if (premiumList.length > 0) {
          h += '<div style="margin-bottom:24px;padding:16px;background:#ffffff;border-radius:16px;border:1.5px dashed #b0bcd8">';
          h += '<div style="font-size:.7rem;font-weight:800;color:#9b51e0;text-transform:uppercase;letter-spacing:.05em;margin-bottom:14px">OPZIONI PREMIUM</div>';
          premiumList.forEach(function (p) {
            h += '<div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:10px;font-size:.9rem;color:#1a1f36;font-weight:500">';
            h += '<div style="width:6px;height:6px;border-radius:50%;background:#9b51e0;margin-top:6px;flex-shrink:0"></div>';
            h += '<div style="line-height:1.4">' + esc(p.trim()) + '</div></div>';
          });
          h += '</div>';
        }

        if (rr.latePenaltyApplied || rr.unfulfilledPenaltyApplied) {
          var pLabel = rr.latePenaltyApplied ? 'PENALE RITARDO APPLICATA' : 'PENALE INADEMPIENZA APPLICATA';
          h += '<div style="margin-bottom:24px;padding:16px;background:#fdf5f0;border-radius:16px;border:1px solid #f5c0bc">';
          h += '<div style="font-size:.7rem;font-weight:800;color:#c04020;text-transform:uppercase;letter-spacing:.05em;margin-bottom:12px">' + pLabel + '</div>';
          h += '<div style="display:flex;justify-content:space-between;font-size:.9rem;margin-bottom:8px"><span style="color:#8a8f9e;font-weight:600">Rimborso cliente</span><span style="color:#1a7a4a;font-weight:800">+' + rr.refundAmt + ' pt</span></div>';
          h += '<div style="display:flex;justify-content:space-between;font-size:.9rem"><span style="color:#8a8f9e;font-weight:600">Penale esecutore</span><span style="color:#c04020;font-weight:800">-' + rr.penaltyAmt + ' pt</span></div>';
          h += '</div>';
        }

        var doneCount = S.requests.filter(function(r){return r.status==='done';}).length;
        var isDone = rr.status === 'done';
        var basePct = Math.min(15 + Math.floor(doneCount * 1.5), 35);
        var igaPct = isDone ? basePct : Math.max(basePct - 8, 4);
        var cortPct = isDone ? Math.round(basePct * 0.9) : Math.max(Math.round(basePct * 0.5), 3);
        var syncPct = isDone ? Math.round(basePct * 0.7) : Math.max(Math.round(basePct * 0.35), 2);
        var oxPct = isDone ? Math.round(basePct * 0.8) : Math.max(Math.round(basePct * 0.4), 2);

        h += '<div style="margin-bottom:32px;background:#1a2a5e;border-radius:16px;padding:24px;color:white">';
        h += '<div style="font-size:.65rem;color:#8fa8d8;text-transform:uppercase;letter-spacing:.05em;font-weight:800;margin-bottom:12px">IMPATTO SUL BENESSERE DI COPPIA</div>';
        h += '<div style="font-size:.9rem;color:#e8edf8;margin-bottom:24px;line-height:1.4;font-weight:500">' + (isDone ? 'Questo ordine ha contribuito ai tuoi indicatori di benessere nella settimana in corso.' : 'Indicatori stimati attivi da quando hai effettuato l\\'ordine.') + '</div>';

        var metrics = [
          { label: 'Scudo immunitario (IgA)', pct: igaPct, color: '#7ee8b0', barBg: 'rgba(255,255,255,0.15)' },
          { label: 'Riduzione cortisolo', pct: cortPct, color: '#7ee8b0', barBg: 'rgba(255,255,255,0.15)' },
          { label: 'Sincronizzazione coppia', pct: syncPct, color: '#f8c97a', barBg: 'rgba(255,255,255,0.15)' },
          { label: 'Rilascio ossitocina', pct: oxPct, color: '#f8c97a', barBg: 'rgba(255,255,255,0.15)' }
        ];
        metrics.forEach(function (m) {
          h += '<div style="margin-bottom:16px">';
          h += '<div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="font-size:.85rem;font-weight:600;color:#c8d4ea">' + m.label + '</span><span style="font-size:.85rem;font-weight:800;color:' + m.color + '">+' + m.pct + '%</span></div>';
          h += '<div style="height:4px;background:' + m.barBg + ';border-radius:4px;overflow:hidden"><div style="height:100%;width:' + m.pct + '%;background:' + m.color + ';border-radius:4px"></div></div>';
          h += '</div>';
        });
        h += '</div>';

        h += '<div style="position:sticky;bottom:0;background:#ffffff;padding-top:10px;padding-bottom:30px;display:flex;flex-direction:column;gap:10px;border-top:1px solid rgba(0,0,0,0.03)">';
        
        if (rr.by === pt) { 
          if (rr.status === 'pending') {
            h += '<button style="flex:1;background:#1a2a5e;color:#fff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;align-items:center;cursor:pointer" data-action="mark-done" data-arg="' + esc(rr.id) + '">Segna come Consegnato 📦</button>';
          }
        } else { 
          if (rr.status === 'done_confirm') {
            h += '<button style="background:#1a7a4a;color:#fff;border:none;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;align-items:center;cursor:pointer" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="yes">Conferma Ricezione ✅</button>';
            h += '<div style="display:flex;gap:10px">';
            h += '<button style="flex:1;background:#fff5f0;color:#c04020;border:1px solid #f5c0bc;padding:12px;border-radius:12px;font-size:.9rem;font-weight:700;cursor:pointer" data-action="report-late" data-arg="' + esc(rr.id) + '">In Ritardo</button>';
            h += '<button style="flex:1;background:#fff5f0;color:#a32d2d;border:1px solid #f5c0bc;padding:12px;border-radius:12px;font-size:.9rem;font-weight:700;cursor:pointer" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="no">Non Eseguito</button>';
            h += '</div>';
          } else if (rr.status === 'pending' && Date.now() > new Date(rr.deadline||0).getTime() + 600000) {
            h += '<button style="background:#fdf0f0;color:#a32d2d;border:1px solid #f5c0bc;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;cursor:pointer" data-action="declare-unfulfilled" data-arg="' + esc(rr.id) + '">Dichiara Inadempienza 🚨</button>';
          } else if (rr.status === 'expired') {
             h += '<button style="background:#e6f7ee;color:#1a7a4a;border:1px solid #a3e6be;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;cursor:pointer" data-action="confirm-done" data-arg="' + esc(rr.id) + '" data-arg2="yes">Alla fine consegnato ✅</button>';
          }
        }
        
        h += '<button style="background:#ffffff;color:#1a1f36;border:1px solid #d0d4e0;padding:16px;border-radius:12px;font-size:1rem;font-weight:700;display:flex;justify-content:center;align-items:center;cursor:pointer" data-action="cancel-overlay">← Chiudi dettaglio</button>';
        h += '</div>';
        h += '</div></div>';
        return h;
      }"""

content = re.sub(r'function\s+renderOrderDetailOverlay\s*\(\)\s*\{.*?return\s*h;\s*\}', lambda m: new_detail, content, flags=re.DOTALL)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
print("Updated Ordini page and modal successfully!")
