import os

file_path = "/Users/lavoro/Downloads/Webapp/index.html"
with open(file_path, "r", encoding="utf-8") as f:
    orig_content = f.read()

# 1. Update renderWellnessWidget
s_well = orig_content.find("function renderWellnessWidget(me) {")
e_well = orig_content.find("return h;\n}", s_well) + len("return h;\n}")
new_well = """function renderWellnessWidget(me) {
  var xStats = getExtendedBenessereStats(me);
  var streak = xStats.streak;
  var mCount = xStats.m;
  
  var thresholds = [0, 3, 5, 7, 10, 14];
  var lvls = ['Esplorazione','Germoglio','Scintilla','Fiamma','Cristallo','Leggenda'];
  var myW = xStats.w;
  var lvlId = 0;
  for (var i=5; i>=0; i--) if(myW >= thresholds[i]) { lvlId = i; break; }
  
  var nextLvlText = lvlId < 5 ? lvls[lvlId+1] : 'Max';
  var progVal = lvlId < 5 ? (myW - thresholds[lvlId]) : 1;
  var progMax = lvlId < 5 ? (thresholds[lvlId+1] - thresholds[lvlId]) : 1;
  if(lvlId===0) { progVal = myW; progMax = 3; }
  var pct = Math.floor((progVal/progMax)*100);

  var subText = lvlId === 0 ? 'Ottimo Inizio, continuate così!' : (lvlId > 2 ? 'Siete in perfetta sintonia! 🔥' : 'Avete un bel ritmo, continuate così!');

  var h = '<div style="background:#1e293b;border-radius:20px;padding:20px;color:white;margin-bottom:24px;box-shadow:0 12px 24px rgba(30,41,59,0.2)">';
  h += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">';
  h += '<span style="font-size:.7rem;font-weight:700;color:#94a3b8;letter-spacing:.05em">IL TUO PROGRESSO</span>';
  h += '<span style="font-size:.7rem;background:rgba(255,255,255,0.1);padding:4px 10px;border-radius:12px;font-weight:600">'+xStats.w+'/sett.</span>';
  h += '</div>';
  h += '<div style="font-size:1.05rem;font-weight:800;color:white;font-family:\\'Playfair Display\\',serif;margin-bottom:20px">'+subText+'</div>';
  
  h += '<div style="display:flex;gap:10px;margin-bottom:20px">';
  h += '<div style="flex:1;background:rgba(255,255,255,0.06);border-radius:12px;padding:12px;text-align:center">';
  h += '<div style="font-size:1.2rem;font-weight:800;color:white;margin-bottom:4px">'+streak+'</div>';
  h += '<div style="font-size:.65rem;color:#94a3b8;line-height:1.2">Streak<br>sett.</div>';
  h += '</div>';
  h += '<div style="flex:1;background:rgba(255,255,255,0.06);border-radius:12px;padding:12px;text-align:center">';
  h += '<div style="font-size:1.2rem;font-weight:800;color:#38bdf8;margin-bottom:4px">'+mCount+'</div>';
  h += '<div style="font-size:.65rem;color:#94a3b8;line-height:1.2">Ordini<br>30G</div>';
  h += '</div>';
  h += '<div style="flex:1;background:rgba(255,255,255,0.06);border-radius:12px;padding:12px;text-align:center">';
  h += '<div style="font-size:1.2rem;font-weight:800;color:#fbbf24;margin-bottom:4px">Lv '+lvlId+'</div>';
  h += '<div style="font-size:.65rem;color:#94a3b8;line-height:1.2">Livello<br>attuale</div>';
  h += '</div>';
  h += '</div>';

  h += '<div style="display:flex;justify-content:space-between;align-items:center;font-size:.75rem;color:#94a3b8;margin-bottom:8px">';
  h += '<span>Prossimo livello: <strong style="color:white">'+nextLvlText+'</strong></span>';
  h += '<span>'+progVal+'/'+progMax+'</span>';
  h += '</div>';
  h += '<div style="height:6px;background:rgba(255,255,255,0.1);border-radius:3px;margin-bottom:16px;overflow:hidden"><div style="height:100%;width:'+pct+'%;background:#60a5fa;border-radius:3px"></div></div>';
  h += '<div style="text-align:right"><button style="background:none;border:none;color:#60a5fa;font-size:.75rem;font-weight:700;font-family:sans-serif;cursor:pointer" data-action="set-tab" data-arg="benessere">Analisi completa →</button></div>';

  h += '</div>';
  return h;
}"""
content = orig_content[:s_well] + new_well + orig_content[e_well:]

# 2. Update renderHero -> replace with renderHomeHeader + renderFlashSaleWidget + renderLastOrderWidget + renderGamesCTA
s_hero = content.find("function renderHero(pts")
e_hero = content.find("return h;\n}", s_hero) + len("return h;\n}")
new_components = """function renderHomeHeader(me, pts, u) {
  var hr = new Date().getHours();
  var greeting = (hr >= 5 && hr < 17) ? 'Buongiorno' : 'Buonasera';
  var dAgo = u.lastRewardClaim ? daysAgo(u.lastRewardClaim) : 0;
  
  var h = '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0 20px;">';
  h += '<div><div style="font-size:.85rem;color:var(--muted);font-weight:600;margin-bottom:2px">'+greeting+'</div>';
  h += '<div style="font-size:1.5rem;font-weight:800;color:var(--b1);">'+esc(pname(me))+'</div></div>';
  h += '<div style="display:flex;gap:12px;align-items:center;">';
  h += '<div class="pts-badge" style="background:#1e293b;color:white;font-size:.85rem;padding:6px 12px;border-radius:20px;display:flex;align-items:center;gap:4px"><span>🔷</span> '+pts+' pt</div>';
  h += '<button style="width:36px;height:36px;border-radius:50%;background:#e2e8f0;border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--b3)" data-action="logout"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button>';
  h += '</div></div>';

  if (!u.lastRewardClaim) {
    h += '<div style="margin-bottom:16px;background:#fff;border:1px solid #e0eaf8;border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.03)" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '<div style="font-size:2rem;line-height:1">🛍️</div>';
    h += '<div><div style="font-size:.9rem;font-weight:800;color:var(--b2);margin-bottom:4px">Benvenuto nello Shop!</div><div style="font-size:.75rem;color:var(--b3);line-height:1.4">Fai il tuo <strong>primo acquisto</strong> per sbloccare l\\'analisi clinica.</div></div>';
    h += '</div>';
  } else if (dAgo >= 3) {
    h += '<div style="margin-bottom:16px;background:rgba(231,76,60,0.1);border:1px solid rgba(231,76,60,0.3);border-radius:16px;padding:14px;display:flex;align-items:center;gap:14px;cursor:pointer;" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '<div style="font-size:2rem;line-height:1">🚨</div>';
    h += '<div><div style="font-size:.9rem;font-weight:800;color:#c0392b;margin-bottom:4px">Penalità Imminente!</div><div style="font-size:.75rem;color:#e74c3c;line-height:1.4">Sfogli lo <strong>Shop</strong> e acquista qualcosa per disinnescare la penalità!</div></div>';
    h += '</div>';
  } else if (dAgo === 2) {
    h += '<div style="margin-bottom:16px;background:rgba(243,156,18,0.1);border:1px dashed rgba(243,156,18,0.4);border-radius:16px;padding:12px;text-align:center;cursor:pointer;font-size:.8rem;color:#d68910;font-weight:700" onclick="document.querySelector(\\'[data-arg=shop]\\').click()">';
    h += '⏳ Sei a quota 2 giorni senza acquisti. Rimedia prima della penalità!';
    h += '</div>';
  }
  return h;
}

function renderFlashSaleWidget() {
  var epoch = Math.floor(Date.now() / (5 * 3600 * 1000));
  var myRewards = S.rewards.filter(function(r) { return r.partner === session || r.partner === 'both'; });
  var fSales = [];
  if (myRewards.length > 0) {
    var a = myRewards.slice();
    var seed = epoch;
    for (var i = a.length - 1; i > 0; i--) {
      var x = Math.sin(seed++) * 10000;
      var rNum = x - Math.floor(x);
      var j = Math.floor(rNum * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    fSales = a.slice(0, 3);
  }
  if (!fSales.length) return '';

  var hrsLeft = 5 - (Math.floor(Date.now() / 3600000) % 5);
  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:var(--b1);font-size:.9rem">Flash Sale</div>';
  h += '<div style="font-size:.7rem;color:#f36c53;background:#ffece8;font-weight:800;padding:4px 10px;border-radius:12px">Scade tra '+hrsLeft+'h</div>';
  h += '</div>';

  h += '<div style="display:flex;gap:12px;overflow-x:auto;padding-bottom:15px;margin:0 -20px 16px;padding-left:20px;padding-right:20px;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;">';
  var fSeed = epoch;
  fSales.forEach(function(fs) {
    var fx = Math.sin(fSeed++) * 10000;
    var dscPct = (fx - Math.floor(fx)) > 0.5 ? 0.10 : 0.05;
    var dscCost = Math.floor(fs.cost * (1 - dscPct));
    var descText = fs.desc || 'Premio in sconto da non perdere!';
    
    h += '<div style="flex:0 0 160px;scroll-snap-align:start;background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;position:relative;box-shadow:0 6px 12px rgba(0,0,0,0.03);display:flex;flex-direction:column;min-height:220px;" data-action="open-claim" data-arg="'+fs.id+'" data-arg2="'+dscCost+'">';
    h += '<div style="position:absolute;top:12px;right:12px;background:#c0392b;color:#fff;font-size:.75rem;font-weight:800;padding:3px 8px;border-radius:8px">-'+(dscPct*100)+'%</div>';
    h += '<div style="font-size:2rem;margin-bottom:10px">'+(fs.emoji||'🎁')+'</div>';
    h += '<div style="font-size:.85rem;font-weight:800;color:var(--b1);margin-bottom:4px;line-height:1.2;flex-shrink:0;height:40px;overflow:hidden">'+esc(fs.name)+'</div>';
    h += '<div style="font-size:.7rem;color:var(--muted);line-height:1.3;margin-bottom:10px;flex:1;overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical">'+esc(descText)+'</div>';
    h += '<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px">';
    h += '<div style="font-size:1.1rem;font-weight:900;color:var(--b2)">🔷 '+dscCost+'</div>';
    h += '<div style="font-size:.7rem;color:#94a3b8;text-decoration:line-through">'+fs.cost+'</div>';
    h += '</div>';
    h += '<button style="width:100%;background:#1e293b;color:white;border:none;padding:10px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;pointer-events:none">Acquista ora</button>';
    h += '</div>';
  });
  h += '</div>';
  return h;
}

function renderLastOrderWidget(myReqs) {
  var allMe = myReqs.slice().reverse();
  if (allMe.length === 0) return '';
  var lr = allMe[0];

  var s = lr.status;
  var bc = s==='pending'?'badge-wait':s==='done'?'badge-ok':s==='done_confirm'?'badge-conf':'badge-exp';
  var bt = s==='pending'?'⏳ Lavorazione':s==='done'?'✅ Consegnato':s==='done_confirm'?'🔔 Conferma':'⏰ Scaduto';

  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:var(--b1);font-size:.9rem">Ultimo ordine</div>';
  h += '<button style="background:none;border:none;color:#60a5fa;font-size:.75rem;font-weight:700;cursor:pointer" data-action="toggle-history">Storico →</button>';
  h += '</div>';

  h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:16px;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
  h += '<div style="display:flex;gap:14px;align-items:center;margin-bottom:16px">';
  h += '<div style="width:48px;height:48px;background:#f1f5f9;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;flex-shrink:0">'+(lr.emoji||'🎁')+'</div>';
  h += '<div style="flex:1;overflow:hidden">';
  h += '<div style="font-size:.85rem;font-weight:800;color:var(--b1);margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(lr.name)+'</div>';
  h += '<div style="font-size:.7rem;color:var(--muted);margin-bottom:6px">'+fmtDt(lr.requestedAt)+'</div>';
  h += '<span class="ar-badge '+bc+'" style="font-size:.65rem;padding:3px 8px">'+bt+'</span>';
  h += '</div>';
  h += '</div>';
  h += '<button style="width:100%;background:#f8fafc;color:#334155;border:1px solid #e2e8f0;padding:12px;border-radius:12px;font-size:.8rem;font-weight:700;font-family:sans-serif;cursor:pointer" data-action="view-order" data-arg="'+esc(lr.id)+'" data-arg2="0">Vedi dettaglio ordine →</button>';
  h += '</div>';
  return h;
}

function renderGamesCTA() {
  var h = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
  h += '<div style="font-weight:800;color:var(--b1);font-size:.9rem">Giochi e quiz</div>';
  h += '<div style="font-size:.7rem;color:#8b5cf6;background:#f5f3ff;font-weight:800;padding:4px 10px;border-radius:12px">Novità</div>';
  h += '</div>';

  h += '<div style="background:#fff;border-radius:20px;border:1px solid #e2e8f0;padding:20px;position:relative;overflow:hidden;box-shadow:0 6px 12px rgba(0,0,0,0.03);margin-bottom:24px">';
  h += '<div style="position:absolute;top:-40px;right:-40px;width:150px;height:150px;background:#f5f3ff;border-radius:50%;z-index:0"></div>';
  h += '<div style="position:relative;z-index:1">';
  h += '<div style="font-size:1.8rem;margin-bottom:12px">🎮</div>';
  h += '<div style="font-size:.95rem;font-weight:800;color:var(--b1);margin-bottom:6px">Sfide e quiz di coppia</div>';
  h += '<div style="font-size:.75rem;color:var(--muted);line-height:1.4;margin-bottom:16px">Gioca insieme, rispondi ai quiz e accumula punti extra da spendere nello shop.</div>';
  h += '<div style="display:flex;gap:12px;align-items:center">';
  h += '<button style="background:#1e293b;color:white;border:none;padding:10px 16px;border-radius:12px;font-size:.8rem;font-weight:700;cursor:pointer" onclick="showToast(\\'In arrivo prossimamente!\\')">Scopri i giochi →</button>';
  h += '<div style="font-size:.75rem;color:#8b5cf6;font-weight:800;background:#f5f3ff;padding:6px 10px;border-radius:10px">✦ +pt bonus</div>';
  h += '</div></div></div>';
  return h;
}"""
content = content[:s_hero] + new_components + content[e_hero:]

# 3. Update renderApp
s_app = content.find("function renderApp() {")
e_app = content.find("return h;\n}", s_app) + len("return h;\n}")
new_app = """function renderApp() {
  var me = session, pt = partner();
  var u = S.users[me], pts = myPts(), ptPts = ptOf(pt);
  var ptOnline = onlineUsers[pt] && (Date.now() - onlineUsers[pt] < 12000);
  var myReqs = S.requests.filter(function(r){return r.by===me;});
  var toExec = S.requests.filter(function(r){return r.by!==me && r.status==='pending';});
  var toConf = S.requests.filter(function(r){return r.by===me && r.status==='done_confirm';});
  var myRws = S.rewards.filter(function(r){return r.partner===me||r.partner==='both';}).sort(function(a,b){return (a.cost||0) - (b.cost||0);});
  var hasBadge = toExec.length > 0 || toConf.length > 0;
  var page = '';

  if (tab === 'home') {
    page += renderHomeHeader(me, pts, u);
    
    if (flashQ && !overlay) {
      page += '<button class="btn btn-full" style="background:linear-gradient(135deg,#1e3060,#2d4b9e);color:white;padding:14px;border-radius:14px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 6px 16px rgba(30,48,160,0.25)" data-action="open-activity">';
      page += '<div style="text-align:left"><div style="font-size:.68rem;opacity:.7;text-transform:uppercase;font-weight:700;margin-bottom:2px">⚡ Domanda Flash in corso</div><div style="font-size:.9rem;font-weight:700">'+esc(flashQ.q.text.substring(0,40))+(flashQ.q.text.length>40?'…':'')+'</div></div>';
      page += '<div style="font-size:1.4rem;opacity:.8">▶</div></button>';
    } else if (miniGame && !overlay) {
      page += '<button class="btn btn-full" style="background:linear-gradient(135deg,#1e3060,#2d4b9e);color:white;padding:14px;border-radius:14px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 6px 16px rgba(30,48,160,0.25)" data-action="open-activity">';
      page += '<div style="text-align:left"><div style="font-size:.68rem;opacity:.7;text-transform:uppercase;font-weight:700;margin-bottom:2px">'+miniGame.icon+' Mini-Gioco disponibile</div><div style="font-size:.9rem;font-weight:700">'+esc(miniGame.name)+'</div></div>';
      page += '<div style="font-size:1.4rem;opacity:.8">▶</div></button>';
    }
    
    if (toConf.length > 0) {
      page += '<div class="sec-label">🔔 Conferma richiesta ('+toConf.length+')</div>';
      toConf.forEach(function(rr) { page += renderMyReqCard(rr); });
    }
    if (toExec.length > 0) {
      page += '<div class="sec-label">📨 Da eseguire per '+esc(pname(pt))+' ('+toExec.length+')</div>';
      toExec.forEach(function(rr) { page += renderExecCard(rr, false); });
    }

    page += renderWellnessWidget(me);
    page += renderFlashSaleWidget();
    page += renderLastOrderWidget(myReqs);
    page += renderGamesCTA();

    if (showHistory) {
      var histOrders = myReqs.filter(function(r){ return r.status==='done' || r.status==='expired'; }).slice().reverse();
      if (!histOrders.length) {
        page += '<div class="empty"><span class="empty-ico">🗒️</span><p>Nessun ordine completato o scaduto.</p></div>';
      } else {
        histOrders.forEach(function(rr) { page += renderMyReqCard(rr); });
      }
    }
    
    page += '<div style="height:20px"></div>';
  }
  else if (tab === 'shop') {
    var pendingMine = myReqs.filter(function(r){return r.status==='pending';});
    if (pendingMine.length) {
      page += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">';
      page += '<div class="sec-label" style="margin-bottom:0">⏳ I miei ordini in viaggio</div>';
      page += '<div class="pts-badge" style="font-size:.78rem">🔷 '+pts+' pt</div></div>';
      pendingMine.forEach(function(rr) { page += renderMyReqCard(rr); });
      page += '<div style="height:12px"></div>';
      page += '<div class="sec-label" style="margin-bottom:4px">🛍 Vetrina Prodotti</div>';
    } else {
      page += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">';
      page += '<div class="sec-label" style="margin-bottom:0">🛍 Vetrina Prodotti</div>';
      page += '<div class="pts-badge" style="font-size:.78rem">🔷 '+pts+' pt</div></div>';
    }
    
    if (!myRws.length) page += '<div class="empty"><span class="empty-ico">🛍️</span><p>Nessun prodotto in inventario.<br>Il fornitore li aggiungerà presto!</p></div>';
    else myRws.forEach(function(r) { page += renderShopItem(r, pts); });
    
    var dAgo = u.lastRewardClaim ? daysAgo(u.lastRewardClaim) : 0;
    if (dAgo >= 3) page += renderMandatoryAlert();
  }
  else if (tab === 'execute') {
    page += '<div class="sec-label">📥 Nuovi ordini da evadere per '+esc(pname(pt))+'</div>';
    if (!toExec.length) page += '<div class="empty"><span class="empty-ico">📦</span><p>Nessuna spedizione pendente.<br>'+esc(pname(pt))+' non ha effettuato ordini.</p></div>';
    else toExec.forEach(function(rr) { page += renderExecCard(rr, true); });
    var hist = S.requests.filter(function(r){return r.by!==me && r.status!=='pending';}).slice().reverse().slice(0,5);
    if (hist.length) {
      page += '<div class="sec-label" style="margin-top:4px">📋 Storico Spedizioni</div>';
      hist.forEach(function(rr) {
        var bc = rr.status==='done'?'badge-ok':rr.status==='done_confirm'?'badge-conf':'badge-exp';
        var bt = rr.status==='done'?'✅ Consegnato':rr.status==='done_confirm'?'🔔 In attesa':'⏰ Scaduto / Annullato';
        page += '<div class="ar-card grey"><div class="ar-header"><div class="ar-title">📦 Ordine #'+rr.id.substring(rr.id.length-5)+' — '+esc(rr.name)+'</div><span class="ar-badge '+bc+'">'+bt+'</span></div>';
        page += '<div style="font-size:.72rem;color:var(--muted)">Effettuato il '+fmtDt(rr.requestedAt)+'</div></div>';
      });
    }
  }
  else if (tab === 'benessere') {
    page += renderBenessereTab(me, pt);
  }

  var ovHtml = overlay ? renderOverlay() : (showOB ? renderOnboarding() : '');
  var h = '<div class="app">';
  if (tab !== 'home') {
    h += '<div class="topbar"><span class="topbar-name">'+esc(pname(me))+'</span>';
    h += '<div class="pts-badge">🔷 '+pts+' pt</div>';
    h += '<button class="icon-btn" data-action="logout"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg></button></div>';
  }
  h += '<div class="page'+(tab==='home'?' home-page':'')+'" '+(tab==='home'?'style="padding-top:0"':'')+'>'+page+'</div>';
  h += '<div class="bnav">';
  h += '<button class="ni'+(tab==='home'?' on':'')+'" data-action="set-tab" data-arg="home"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg><span>Home</span></button>';
  h += '<button class="ni'+(tab==='shop'?' on':'')+'" data-action="set-tab" data-arg="shop"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg><span>Shop</span></button>';
  h += '<button class="ni'+(tab==='execute'?' on':'')+'" data-action="set-tab" data-arg="execute" style="position:relative"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"></polyline><rect x="2" y="7" width="20" height="5"></rect><line x1="12" y1="22" x2="12" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path></svg><span>Ordini</span>'+(hasBadge?'<div class="ni-dot"></div>':'')+'</button>';
  h += '<button class="ni'+(tab==='benessere'?' on':'')+'" data-action="set-tab" data-arg="benessere"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78v0z"></path></svg><span>Benessere</span></button>';
  h += '</div>'+ovHtml+(toast?'<div class="toast">'+toast+'</div>':'')+'</div>';
  return h;
}"""
content = content[:s_app] + new_app + content[e_app:]

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)
